<?php
$con = mysqli_connect("localhost", "username", "password", "database") or die(mysqli_error($con));
