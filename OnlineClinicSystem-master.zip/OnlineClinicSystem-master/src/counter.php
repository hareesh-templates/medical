<section id="counterSection">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="counter-area">
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="counter-box">
                            <div class="counter-no counter">
                                200
                            </div>
                            <div class="counter-label">Doctors</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="counter-box">
                            <div class="counter-no counter">
                                300
                            </div>
                            <div class="counter-label">Clinic Rooms</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="counter-box">
                            <div class="counter-no counter">
                                350
                            </div>
                            <div class="counter-label">Awards</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="counter-box">
                            <div class="counter-no counter">
                                450
                            </div>
                            <div class="counter-label">Happy Patients</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
