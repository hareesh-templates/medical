<?php
/*****************************************************************
*        DO NOT REMOVE                                           *
*        =============                                           *
*VetClinic Management Software                                   *
*Copyrighted 2015-2016 by Michael Avila                          *
*Distributed under the terms of the GNU General Public License   *
*This program is distributed in the hope that it will be useful, *
* but WITHOUT ANY WARRANTY; without even the implied warranty of *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
*****************************************************************/
/*
Company Preferences Sequence 1
	1 computer name
	2 email address
	3 domain
	4 
Company Preferences Sequence 2
	1 logon background color
	2 menu background color
	3 help background color
	4 other bacground color
	5 
Company Preferences Sequence 3
	1 reload
	2 state
	3 auto sales price
	4 time zone
	5
Company Preferences Sequence 4
     1 installed procedures | default procedures
     2 
     3
     4
     5
Company Preferences Sequence 5
*/
?>