The Rapla project uses the following libraries from other software-projects:

Library:----------from:----------------License------Get the source from:

ant               Apache Foundation   Apache 2.0      ant.apache.org
avalon-jars       Apache Foundation   Apache 2.0      avalon.apache.org
commons-jars      Apache Foundation   Apache 2.0      commons.apache.org
itext             iText Software      LGPL 2.0        github.com/ymasory/
cl-leak-prevent   mjiderhamn          Apache 2.0      https://github.com/mjiderhamn/classloader-leak-prevention  
ical4j            Micronode           ical4j (BSD)    build.mnode.org/projects/ical4j/
jetty             Eclipse Foundation  Apache 2.0      www.eclipse.org/jetty/
mailapi           Oracle              GPL 2.0         java.net/projects/javamail           
servlet-api       Apache              Apache 2.0      svn.apache.org/repos/asf/tomcat/tc7.0.x/trunk/java/javax/servlet/
supercvs          Kasper              Apache 2.0      supercsv.sourceforge.net
service wrapper   tanukisoftware      GPL 2.0         wrapper.tanukisoftware.com 

Most icons were taken from the eclipse project (www.eclipse.org) which are licensed under
the eclipse public license 1.1
Some icons were taken from
- wm-icons.sourceforge.net (GPL LICENSE)

Look for the full license texts in the legal folder of the rapla distribution.
