# 2008 feb 26
# /bin/cat initdb.sql | /usr/bin/mysql -u username --password='password' -h localhost --force
create database across;
use across;

--
drop table if exists userinfo;
create table userinfo
(
  id int not null primary key auto_increment,
  last_insert_datetimestamp datetime,
  last_update_datetimestamp datetime,
  userid varchar(64) not null,
  userpass varchar(64),
  status_flag varchar(16)
);
insert into userinfo (id, last_insert_datetimestamp, last_update_datetimestamp, userid, userpass, status_flag) values
('', now(), now(), 'demo', 'demo', '');
select * from userinfo;

--
drop table if exists branch;
create table branch
(
  id int not null primary key auto_increment,
  last_insert_datetimestamp datetime,
  last_update_datetimestamp datetime,
  branch_name varchar(128),
  address varchar(256),
  status_flag varchar(16)
);
insert into branch (id, last_insert_datetimestamp, last_update_datetimestamp, branch_name, address, status_flag) values
('', now(), now(), 'MediNet Clinic 1', '1 Kowloon Street Kowloon Hong Kong', ''),
('', now(), now(), 'MediNet Clinic 2', '2 Hong Kong Road Hong Kong Island Hong Kong', ''),
('', now(), now(), 'MediNet Clinic 3', '3 New Territories Avenue New Territories Hong Kong', ''),
select * from branch;

--
drop table if exists appointment;
create table appointment
(
  id int not null primary key auto_increment,
  last_insert_datetimestamp datetime,
  last_update_datetimestamp datetime,
  branch_id int not null,
  time_slot datetime not null,
  status_flag varchar(16),
  unique key (branch_id, time_slot)
);
insert into appointment (id, last_insert_datetimestamp, last_update_datetimestamp, branch_id, time_slot, status_flag) values
('', now(), now(), '1', now(), ''),
('', now(), now(), '3', now(), ''),
('', now(), now(), '2', now(), '');
select * from appointment;

