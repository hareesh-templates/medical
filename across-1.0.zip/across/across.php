<?php
# 2008 feb 24
class across
{
  function __construct
  (
  )
  {
    return;
  }

  function setmodule
  (
  )
  {
    extract($_REQUEST);
    if ($module == '')
    {
      $module = 'defaultmodule';
    }
    if ($module != '')
    {
      include_once(sprintf("%s.inc", $module));
      eval('$obj = new '.$module.'();');
      printf("%s", $obj->getresponse());
    }
    return;
  }
}
$o = new across();
$o->setmodule();
?>
