<?php
# 2008 feb 26
header("Location: /across/across.php");
?>
