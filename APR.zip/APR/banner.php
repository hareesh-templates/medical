					<img src="img/dr.jpg">
<div class="login_sign_up">
		<a rel="tooltip"  data-placement="left" title="Click Here to Login" id="login" href="login.php"  class="btn btn-info btn-large"><i class="icon-signin icon-large"></i>&nbsp;Login</a>
		<p><a rel="tooltip"  data-placement="bottom" title="Click Here to Sign UP" id="signup" href="signup.php">Not a Member? Sign Up Now</a></p>
</div>
				    <div id="myCarousel" class="carousel slide">
							<ol class="carousel-indicators">
							<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel" data-slide-to="1"></li>
							<li data-target="#myCarousel" data-slide-to="2"></li>
							</ol>
							<!-- Carousel items -->
							<div class="carousel-inner">
							<div class="active item">
							<img src="img/slide.jpg">
								<div class="carousel-caption"><h3>Schedule Your Appointment Online</h3></div>
								</div>
							<div class="item">…</div>
							<div class="item">…</div>
							</div>
							<!-- Carousel nav -->
							<a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
							<a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
					</div>