<div class="container">   
   <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
        <p><a>Copyright � 2021 Reverside Medical Hospital. All Rightsreserved at CampCodes</a></p>
      </div>
      </div>
    </footer>
</div>
</body>
</html>