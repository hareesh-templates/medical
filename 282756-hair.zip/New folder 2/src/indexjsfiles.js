const $ = require('./assets/js/bootstrap.min.js');
import 'owl.carousel';

require('./assets/js/bootstrap.bundle.min.js');
require('./assets/js/bootstrap-datepicker.min.js');
require('./assets/js/slick.js');
require('./assets/js/aos.js');
require('./assets/js/magnific-popup.min.js');
require('./assets/js/script.js');



