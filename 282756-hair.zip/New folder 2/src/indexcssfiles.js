require('./assets/css/bootstrap.min.css');
import 'owl.carousel/dist/assets/owl.carousel.css';
require('./assets/css/aos.css');
require('./assets/css/slick.css');
require('./assets/css/slick-theme.css');
require('./assets/css/bootstrap-datepicker.min.css');
require('./assets/css/magnific-popup.css');
require('./assets/css/styles.css');
