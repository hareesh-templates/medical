-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2019 at 05:11 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id8650063_suarezclinicdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` text,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `username`, `password`, `status`) VALUES
(14, 'adrian', 'mercurio', 'admerc@yahoo.com', '0ed2afb07e501419e6f497b12e4ebe07', 'ADMIN'),
(16, 'jude', 'suarez', 'jude@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'ADMIN'),
(26, 'angel jude', 'suarez', 'judereyes16@yahoo.com', '202cb962ac59075b964b07152d234b70', 'CLIENT'),
(28, 'james', 'pakwan', 'pakwan@yahoo.com', '202cb962ac59075b964b07152d234b70', 'ADMIN'),
(29, 'jane', 'jude', 'jude@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'CLIENT'),
(30, 'arc', 'cal', 'arccal@yahoo.com', '202cb962ac59075b964b07152d234b70', 'CLIENT'),
(31, 'jude', 'reyes', 'jude@gmail.com', '202cb962ac59075b964b07152d234b70', 'CLIENT'),
(32, 'jude', 'reyes', 'jude@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'CLIENT'),
(33, 'june', 'july', 'august@yahoo.com', '202cb962ac59075b964b07152d234b70', 'CLIENT'),
(34, 'james', 'yap', 'james@gmail.com', '202cb962ac59075b964b07152d234b70', 'CLIENT');

-- --------------------------------------------------------

--
-- Table structure for table `checkup_details`
--

CREATE TABLE `checkup_details` (
  `checkdetails_id` int(11) NOT NULL,
  `check_id` int(11) NOT NULL,
  `med_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkup_details`
--

INSERT INTO `checkup_details` (`checkdetails_id`, `check_id`, `med_id`) VALUES
(366, 1015, 5),
(367, 1015, 6),
(368, 1032, 1),
(369, 1032, 2),
(370, 1032, 3),
(371, 1012, 11),
(372, 1018, 16),
(373, 1022, 20),
(374, 1033, 18),
(375, 1037, 4),
(376, 1038, 5),
(377, 1039, 7),
(378, 1039, 8),
(379, 1039, 9),
(380, 1005, 10),
(381, 1040, 21),
(382, 1001, 12),
(383, 1014, 42),
(384, 1014, 43),
(385, 1014, 44),
(386, 1035, 45),
(387, 1035, 46),
(388, 1035, 47),
(389, 1042, 22),
(390, 1042, 23),
(391, 1042, 24),
(392, 1042, 25),
(393, 1042, 26),
(394, 1043, 63),
(395, 1044, 13),
(396, 1044, 14),
(397, 1044, 15);

-- --------------------------------------------------------

--
-- Table structure for table `check_up`
--

CREATE TABLE `check_up` (
  `check_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `complains` text NOT NULL,
  `findings` text NOT NULL,
  `date` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `check_up`
--

INSERT INTO `check_up` (`check_id`, `patient_id`, `complains`, `findings`, `date`, `status`) VALUES
(1001, 201805, 'body pain', 'unrelax', '2018-07-21', 'COMPLETE'),
(1003, 201803, 'toothache', 'N/A', '2018-07-06', 'ONGOING'),
(1004, 201819, 'fainting', 'N/A', '2018-07-03', 'ONGOING'),
(1005, 201813, 'wound', 'open wound', '2018-07-25', 'COMPLETE'),
(1006, 201818, 'wound', 'N/A', '2018-07-28', 'ONGOING'),
(1007, 201807, 'stomach ache', 'N/A', '2018-08-03', 'ONGOING'),
(1008, 201806, 'nape ache', 'N/A', '2018-07-05', 'ONGOING'),
(1009, 201814, 'swollen', 'N/A', '2018-07-24', 'ONGOING'),
(1010, 201816, 'ambot', 'N/A', '2018-07-15', 'ONGOING'),
(1011, 201804, 'stomachache', 'N/A', '2018-07-04', 'ONGOING'),
(1012, 201808, 'napeache', 'high blood', '2018-07-27', 'COMPLETE'),
(1013, 201810, 'cold', 'N/A', '2018-07-02', 'ONGOING'),
(1014, 201809, 'headache', 'fever', '2018-07-25', 'COMPLETE'),
(1015, 201802, 'sneezing', 'cold', '2018-08-01', 'COMPLETE'),
(1016, 201815, 'cought', 'N/A', '2018-07-13', 'ONGOING'),
(1017, 201822, 'wound', 'N/A', '2018-09-17', 'ONGOING'),
(1018, 201823, 'stomach ache', 'lbm', '2018-09-17', 'COMPLETE'),
(1021, 201829, 'stomachache', 'N/A', '2019-01-01', 'ONGOING'),
(1022, 201830, 'stomach ache', 'lbm', '2019-01-01', 'COMPLETE'),
(1024, 201831, 'cold', 'N/A', '2018-07-09', 'ONGOING'),
(1025, 201841, 'cold', 'N/A', '2019-01-25', 'ONGOING'),
(1027, 201837, 'napeache', 'N/A', '2019-01-26', 'ONGOING'),
(1028, 201843, 'stomach ache', 'N/A', '2019-02-01', 'ONGOING'),
(1031, 201843, 'cold', 'N/A', '2019-02-05', 'ONGOING'),
(1032, 201801, 'cold', 'fever', '2019-02-02', 'COMPLETE'),
(1033, 201842, 'stomach ache', 'acid', '2019-02-09', 'COMPLETE'),
(1034, 201835, 'stomach ache', 'N/A', '2019-02-09', 'ONGOING'),
(1035, 201834, 'head ache', 'fever', '2019-02-09', 'COMPLETE'),
(1037, 201844, 'backpain', 'overfatigue', '2019-02-12', 'COMPLETE'),
(1038, 201845, 'headache', 'fever', '2019-02-13', 'COMPLETE'),
(1039, 201843, 'wound', 'opent wound', '2019-02-14', 'COMPLETE'),
(1040, 201844, 'nanaeh', 'morsnak', '2019-02-19', 'COMPLETE'),
(1041, 201847, 'cold', 'N/A', '2019-03-05', 'ONGOING'),
(1042, 201848, 'naas', 'nanaeh', '2019-03-05', 'COMPLETE'),
(1043, 201849, 'wound', 'open wound', '2019-03-08', 'COMPLETE'),
(1044, 201850, 'headache', 'highblood', '2019-03-15', 'COMPLETE'),
(1045, 201853, 'headache', 'N/A', '2019-03-18', 'ONGOING'),
(1046, 201854, 'wound', 'N/A', '2019-03-17', 'ONGOING'),
(1047, 201853, 'cold', 'N/A', '2019-03-17', 'ONGOING'),
(1048, 201847, 'cold', 'N/A', '2019-03-25', 'ONGOING'),
(1049, 201852, 'nanaeh', 'N/A', '2019-03-17', 'ONGOING'),
(1050, 201856, 'headache', 'N/A', '2019-03-18', 'ONGOING'),
(1051, 201857, 'headache', 'N/A', '2019-04-01', 'ONGOING');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `user` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `user`, `pass`) VALUES
(1, 'jude', 'jude');

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `equip_id` int(11) NOT NULL,
  `equip_name` varchar(64) NOT NULL,
  `requested_date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equip_id`, `equip_name`, `requested_date`) VALUES
(1, 'oxygen', '2017-06-10'),
(2, 'nebulizer', '2017-06-10'),
(3, 'stetoscope', '2017-06-10'),
(4, 'hospital bed', '2017-06-10'),
(5, 'long board', '2017-06-10'),
(6, 'medicine kit', '2017-06-10'),
(7, 'blood preasure', '2017-06-10'),
(8, 'wheel chair', '2017-06-10'),
(9, 'arm sling', '2017-06-10'),
(10, 'weighing scale', '2017-06-10'),
(11, 'dental kit', '2017-06-10'),
(12, 'medical scissor', '2017-06-10'),
(13, 'first aid kit', '2017-06-10'),
(14, 'elstic bandage', '2017-06-10'),
(15, 'gauze', '2017-06-10'),
(16, 'cotton', '2016-11-21'),
(17, 'ice bag', '2017-12-01'),
(18, 'bandaid', '2018-09-09'),
(19, 'thermometer', '2019-01-07');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `med_id` int(11) NOT NULL,
  `med_name` varchar(64) NOT NULL,
  `quantity` int(11) NOT NULL,
  `onhand` int(11) NOT NULL,
  `prescription` text,
  `expiry_date` varchar(30) NOT NULL,
  `requested_date` varchar(30) NOT NULL,
  `meduqid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`med_id`, `med_name`, `quantity`, `onhand`, `prescription`, `expiry_date`, `requested_date`, `meduqid`) VALUES
(1, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-09-09', '10005'),
(2, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-09-09', '10005'),
(3, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-09-09', '10005'),
(4, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-09-09', '10005'),
(5, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-09-09', '10005'),
(6, 'betadine', 1, 0, 'openwound', '2020-12-20', '2018-09-09', 'bet10006'),
(7, 'betadine', 1, 0, 'openwound', '2020-12-20', '2018-09-09', 'bet10006'),
(8, 'betadine', 1, 0, 'openwound', '2020-12-20', '2018-09-09', 'bet10006'),
(9, 'betadine', 1, 0, 'openwound', '2020-12-20', '2018-09-09', 'bet10006'),
(10, 'betadine', 1, 0, 'openwound', '2020-12-20', '2018-09-09', 'bet10006'),
(11, 'neoblock', 1, 0, 'highblood', '2020-02-17', '2018-09-09', 'neo10007'),
(12, 'neoblock', 1, 0, 'highblood', '2020-02-17', '2018-09-09', 'neo10007'),
(13, 'neoblock', 1, 0, 'highblood', '2020-02-17', '2018-09-09', 'neo10007'),
(14, 'neoblock', 1, 0, 'highblood', '2020-02-17', '2018-09-09', 'neo10007'),
(15, 'neoblock', 1, 0, 'highblood', '2020-02-17', '2018-09-09', 'neo10007'),
(16, 'loperamide', 1, 0, 'lbm', '2023-12-09', '2019-02-06', 'lop10008'),
(17, 'loperamide', 1, 1, 'lbm', '2019-12-09', '2019-02-06', 'lop10008'),
(18, 'loperamide', 1, 0, 'lbm', '2023-12-09', '2019-02-06', 'lop10008'),
(19, 'loperamide', 1, 1, 'lbm', '2023-12-09', '2019-02-06', 'lop10008'),
(20, 'loperamide', 1, 0, 'lbm', '2023-12-09', '2019-02-06', 'lop10008'),
(21, 'bioflu', 1, 0, 'headache', '2020-02-17', '2018-12-10', '10005'),
(22, 'Diatabs', 1, 0, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(23, 'Diatabs', 1, 0, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(24, 'Diatabs', 1, 0, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(25, 'Diatabs', 1, 0, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(26, 'Diatabs', 1, 0, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(27, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(28, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(29, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(30, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(31, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(32, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(33, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(34, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(35, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(36, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(37, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(38, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(39, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(40, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(41, 'Diatabs', 1, 1, 'LBM', '2019-03-14', '2019-03-15', '10010'),
(42, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(43, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(44, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(45, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(46, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(47, 'rexidol', 1, 0, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(48, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(49, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(50, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(51, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(52, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(53, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(54, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(55, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(56, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(57, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(58, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(59, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(60, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(61, 'rexidol', 1, 1, 'headache', '2019-12-31', '2019-03-01', 'rexidol11111'),
(62, 'tae', 1, 1, 'na', '2019-03-06', '2019-03-07', '9090'),
(63, 'tae', 1, 0, 'na', '2019-03-06', '2019-03-07', '9090'),
(64, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(65, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(66, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(67, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(68, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(69, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(70, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(71, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(72, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(73, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(74, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(75, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(76, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(77, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(78, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(79, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(80, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(81, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(82, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40'),
(83, 'Tempra', 1, 1, 'headache,fever', '2022-01-31', '2019-04-01', 'tempra40');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `not_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `patient_type` varchar(64) NOT NULL,
  `age` int(2) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `fname`, `lname`, `patient_type`, `age`, `address`) VALUES
(201801, 'Angel', 'manaay', 'STUDENT', 20, 'kabankalan city'),
(201802, 'Ken', 'dimagiba', 'STUDENT', 22, 'binalbagan'),
(201803, 'Arnulfo', 'laklaro', 'STUDENT', 21, 'saraet'),
(201804, 'James', 'delima', 'STUDENT', 22, 'himamaylan city'),
(201805, 'Albert', 'tayco', 'STUDENT', 25, 'himamaylan city'),
(201806, 'Dianne', 'dela cruz', 'FACULTY', 30, 'binalbagan'),
(201807, 'Dane', 'david', 'FACULTY', 28, 'isabela'),
(201808, 'Jose', 'reyes', 'FACULTY', 35, 'isabela'),
(201809, 'June', 'villanueva', 'FACULTY', 35, 'bacolod city'),
(201810, 'Stephen', 'mambato', 'FACULTY', 37, 'binalbagan'),
(201811, 'Marlon', 'pitanggo', 'STAFF', 40, 'hinigaran'),
(201812, 'Raymund', 'moreno', 'STAFF', 34, 'su-ay'),
(201813, 'Carlo', 'maestricampo', 'STAFF', 30, 'himamaylan city'),
(201814, 'Gino', 'chavez', 'STAFF', 25, 'saraet'),
(201815, 'Mark', 'pandez', 'STAFF', 35, 'hinigaran'),
(201816, 'grace', 'romero', 'STUDENT', 20, 'nabalian'),
(201817, 'juda', 'yuka', 'STUDENT', 21, 'binangonan'),
(201818, 'criselda', 'dimagiba', 'STUDENT', 15, 'himamaylan city'),
(201819, 'Caloy', 'Babyboy', 'STAFF', 19, 'Philippines'),
(201820, 'eliza', 'baldez', 'STAFF', 40, 'bactolan'),
(201821, 'james', 'penion', 'STUDENT', 22, 'caradio-an'),
(201822, 'leny', 'balidio', 'STUDENT', 25, 'canmoros'),
(201823, 'jessa', 'lima', 'STUDENT', 23, 'purok tumpok brgy. wa'),
(201829, 'thirdy', 'rebollosa', 'STUDENT', 21, 'sara-et'),
(201830, 'elijah', 'galero', 'STUDENT', 21, 'isabela'),
(201831, 'niko', 'curaza', 'STUDENT', 22, 'aguisan'),
(201834, 'wen', 'rejano', 'STUDENT', 20, 'mambato'),
(201835, 'zed', 'fuck', 'STUDENT', 21, 'kabankalan city'),
(201837, 'fox', 'ong', 'FACULTY', 22, 'kabankalan city'),
(201841, 'jolito', 'borero', 'STAFF', 25, 'himamaylan'),
(201842, 'leny', 'balidio', 'STUDENT', 24, 'canmuros'),
(201843, 'adrian', 'mercurio', 'STUDENT', 21, 'suay'),
(201844, 'Shoen', 'Mhalacai', 'STUDENT', 25, 'newyork'),
(201845, 'jonathan', 'barabara', 'STAFF', 25, 'USA'),
(201846, 'adrian', 'merc', 'STUDENT', 21, 'Bacolod'),
(201847, 'arc', 'cal', 'FACULTY', 20, 'isabela'),
(201848, 'arc', 'cal', 'STUDENT', 25, 'japan'),
(201849, 'wenadel', 'rejano', 'STUDENT', 20, 'mambato'),
(201850, 'kenth', 'fuck', 'STAFF', 32, 'isabela'),
(201851, 'marvin', 'tayco', 'STUDENT', 25, 'manila'),
(201852, 'marvin', 'tayco', 'STUDENT', 25, 'manila'),
(201853, 'marvin', 'tayco', 'STUDENT', 25, 'manila'),
(201854, 'Adrian', 'Mercurio', 'STAFF', 20, 'Suay'),
(201855, 'Shoen', 'Mercurio', 'STUDENT', 25, 'isabela'),
(201856, 'joe', 'devance', 'STUDENT', 21, 'USA'),
(201857, 'june', 'july', 'STUDENT', 22, 'mambato'),
(201858, 'james', 'yap', 'FACULTY', 25, 'Suay');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkup_details`
--
ALTER TABLE `checkup_details`
  ADD PRIMARY KEY (`checkdetails_id`),
  ADD KEY `check_id` (`check_id`),
  ADD KEY `med_id` (`med_id`);

--
-- Indexes for table `check_up`
--
ALTER TABLE `check_up`
  ADD PRIMARY KEY (`check_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`equip_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`not_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `checkup_details`
--
ALTER TABLE `checkup_details`
  MODIFY `checkdetails_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=398;

--
-- AUTO_INCREMENT for table `check_up`
--
ALTER TABLE `check_up`
  MODIFY `check_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1052;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
  MODIFY `equip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `med_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `not_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201859;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checkup_details`
--
ALTER TABLE `checkup_details`
  ADD CONSTRAINT `checkup_details_ibfk_1` FOREIGN KEY (`check_id`) REFERENCES `check_up` (`check_id`),
  ADD CONSTRAINT `checkup_details_ibfk_2` FOREIGN KEY (`med_id`) REFERENCES `medicines` (`med_id`);

--
-- Constraints for table `check_up`
--
ALTER TABLE `check_up`
  ADD CONSTRAINT `FK_check_up_patients` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
