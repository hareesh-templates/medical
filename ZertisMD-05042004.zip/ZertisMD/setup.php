<?
//error_reporting(E_ALL);

require 'config.inc.php';

define('SKIN', 'zertis_md/');
define('PROGRAM', 'Zertis Medical Solutions');

//session_name(BASE_URL . PROGRAM);

$ICONURL = BASE_URL . 'templates/' . SKIN . 'res/img/icons';

// php function runs checks on install location and changes path for graphics accordingly
define('INTERFACE_DIR', BASE_URL .'interface/');
define('IMAGE_DIR', BASE_URL .'templates/' . SKIN . 'graphics/');
define('JMENU', BASE_URL . 'java-menu/');
define('MODULE_DIR', BASE_DIR . '/' . 'modules/');
define('MODULE_URL', BASE_URL . 'modules/');
define('SOURCES_DIR', BASE_DIR . '/' . 'sources/');
define('SOURCES_URL', BASE_URL . '/' . 'sources/');
define('CAL_DIR', BASE_DIR . '/' . 'calendar/');
define('CAL_URL', BASE_URL . '/' . 'calendar');
define('LIB_DIR', BASE_DIR . '/lib');
include_once(BASE_DIR . '/templates/' . SKIN . 'base.css.php');
require_once(LIB_DIR . '/plugins/functions.Zertis_temp.php');

//Check Access Level Funtion
include(SOURCES_DIR . '/access_c/control.php');
// Create Log Function
include_once(SOURCES_DIR . '/logs/generator.php');

$NOW = date("l, F jS - Y");

////////////////////////////////////////////////////////////////////////////////
// Smarty
require 'smarty/Smarty.class.php';

function GetSmarty() {
	global $URL, $temp_dir, $NOW;
	$smarty = new Smarty;
	$temp_dir = BASE_DIR . '/templates/' . SKIN;
	$smarty->template_dir = $temp_dir;
	$smarty->assign('title', 'Zertis, Managment System (c) 2004 Zertis Technologies LLC');
	$smarty->assign('MENU_CALL', MENU_CALL);
	$smarty->assign('PROGRAM', PROGRAM);
	$smarty->assign('NOW', $NOW);
	$smarty->assign('JMENU', JMENU);
	$smarty->assign('IMAGE_DIR', IMAGE_DIR);
	$smarty->assign('MODULE_DIR', MODULE_DIR);
	$smarty->assign('SOURCES_URL', SOURCES_URL);
	$smarty->compile_dir = BASE_DIR . '/templates_c';
	$smarty->cache_dir = BASE_DIR . '/cache';
	$smarty->caching = false;
	return $smarty;
}



/* Do some path modification */
ini_set('include_path', ini_get('include_path') . ':' . LIB_DIR . '/adodb');

/***********************************************************
ADODB
0 = assoc lowercase field names. $rs->fields['orderid']
1 = assoc uppercase field names. $rs->fields['ORDERID']
2 = use native-case field names. $rs->fields['OrderID'] -- this is the default since ADOdb 2.90
*/

define('ADODB_ASSOC_CASE', 2);
define('DEBUG', 0);
require 'adodb.inc.php';

$ADODB_CACHE_DIR = BASE_DIR . "/adodb_cache";

$_db = NULL;
function dbconnect() {
	global $_db;
	if(!$_db) {
		$db = &ADONewConnection(DB_TYPE);
		$db->SetFetchMode(ADODB_FETCH_ASSOC);
		$db->debug = DEBUG;
		$db->Connect(DB_SERVER, DB_USER, DB_PASSWD, DB_DB);
		$_db =& $db;
		return $db;
	} else {
		return $_db;
	}
	
}


/***********************************************************
 Global Utility
*/

function RequireLogin() {
	global $_SESSION, $HTTP_SERVER_VARS;
	if(!array_key_exists('UserID', $_SESSION) || !$_SESSION['UserID']) {
		/* In the event that a user is logged out
		by the server restarting, or session being killed
		for whatever reason, but the browser is still open.
		When clicking on a link, or clicking logout, they are still
		directed to the proper location, for all frames, the login window
		XXX This is not necessarily true since the entire application uses frames
		*/
		echo '
				<script language="Javascript">
				<!--
				top.location="' . BASE_URL. 'interface/login.php?refer=' . $HTTP_SERVER_VARS[REQUEST_URI] . '";
				-->
				</script>
				';
		die();
	}
}

function FormValue($field) {
	if(array_key_exists($field, $_POST))
		return $_POST[$field];
	if(array_key_exists($field, $_GET))
		return $_GET[$field];
	return '';
}

function req($fld) { return @$_REQUEST[$fld]; }

function Redirect($url) {
	header("Location: $url");
}

/**************************************************************
 * Some Good Date Functions
 */

function iso2ts ($iso, $hour=3, $min=0, $sec=0) {
  $d = substr($iso, 8, 2);
  $m = substr($iso, 5, 2);
  $y = substr($iso, 0, 4);
  return mktime($hour, $min, $sec, $m, $d, $y);
}

function iso2dmy   ($iso) { return ts2dmy(iso2ts($iso));   }
function iso2mdy   ($iso) { return ts2mdy(iso2ts($iso));   }
function iso2short ($iso) { return ts2short(iso2ts($iso)); }
function iso2long  ($iso) { return ts2long(iso2ts($iso));  }

function ts2iso    ($ts) { return date("Y-M-d", $ts);  }
function ts2dmy    ($ts) { return date("d/m/Y", $ts);  }
function ts2mdy    ($ts) { return date("m/d/Y", $ts);  }
function ts2short  ($ts) { return date("d M y", $ts);  }
function ts2long   ($ts) { return date("jS F Y", $ts); }

require 'page_template.php';

$notify = '<script language="JavaScript">function Secret() {	alert("Written by Zertis Technologies L.L.C.\r\nCopyright 2004"); }</script>
<div class="Zertis"><a href="javascript:Secret()" accesskey="Z" target="_self"></a></div>';

function tabs($tabs, $active, $link=1, $addlink=''){
	/* $tabs = array(array('display', 'url')) */
	/* transposed from Jamie's perl */
	$IMGURL = IMAGE_DIR;
	print <<<EOF
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="Tabs" bgcolor="#FFFFFF">
<tr>
<td nowrap="nowrap" background="$IMGURL/1.gif"><table width="30"><tr><td></td></tr></table></td>
EOF;

	$pt = NULL;
	foreach($tabs as $t) {
	    if ($t[0] == $active) {
	        # Currently selected
	        $n = $t == $tabs[0] ? "2.gif" : "10.gif";
	        print "<td><img src=\"$IMGURL/$n\" height=\"25\" alt=\"\"/></td>\n";
	        if (!$link) {
	            # Cannot click on
	            print "<td nowrap background=\"$IMGURL/3.gif\" valign=\"bottom\"><div class=\"TabActive\">$t[0]</div></td>\n";
	            }
	        else {
	            # Can click on
	            print "<td nowrap background=\"$IMGURL/3.gif\" valign=\"bottom\"><a href=\"$t[1]$addlink\" class=\"TabActive\">$t[0]</a></td>\n";
	            }
		} else {
	        # Not currently selected
	        if($t == $tabs[0]) {
	        	$n = "8.gif";
	        } else {
	        	$n = $pt[0] == $active ? "4.gif" : "6.gif";
	        }
	        print "<td><img src=\"$IMGURL/$n\" height=\"25\" alt=\"\"/></td>\n";
	        print "<td nowrap background=\"$IMGURL/5.gif\" valign=\"bottom\"><div class=\"TabInactive\"><a href=\"$t[1]$addlink\" class=\"TabInactive\">$t[0]</a></div></td>\n";
        }
		$pt = $t;
    }

	if($active == $tabs[count($tabs)-1][0]) {
    	print "<td><img src=\"$IMGURL/11.gif\" width=\"21\" height=\"25\" alt=\"\" /></td>\n";
    } else {
    	print "<td><img src=\"$IMGURL/7.gif\" width=\"21\" height=\"25\" alt=\"\" /></td>\n";
    }
	print <<<EOF
<td nowrap="nowrap" background="$IMGURL/1.gif" width="95%">
</td>
</tr>
</table>
EOF;
}
?>
