<?
session_start();
include('../../setup.php');
RequireLogin();

if ( !isset ( $_REQUEST[keywords]) || !isset ($_REQUEST[search_type]))
	echo "<br /><br /><br /><h1>Search ERROR:</h1><br />
			You did not enter anything to search for.";
else {

  $db = &dbconnect();
  $SQL = "SELECT link FROM Searchable_Tables WHERE id = '$_REQUEST[search_type]'";
  $record = $db->GetRow("$SQL");
  $db->Close();

	if(!$record)
		echo "No Module was installed to search in.";
	else {
		$link = BASE_URL . $record[link];
		header("Location: " . $link . "?keywords=" . $_REQUEST[keywords]);
	}
}

?>
