<?php
//Perform Search

session_start();
require_once('../../setup.php');
RequireLogin();
include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . '/classes/SmartPager.class.php');



	$search_for 	= $_REQUEST[search_for];
	$search_type	= $_REQUEST[search_type];

//echo $search_for.'<br />'.$search_type;

	$db =& dbconnect();

	$tables = $db->GetAll("SELECT table_name, title, description, link FROM Searchable_Tables WHERE search='1'");

	$i = 0;
	//$SQL_array = array();
	foreach($tables as $table) {

		$rs = $db->Execute("SELECT * FROM $table[table_name]");
		$begin = array_keys($rs->fields);
 		$compile = "SELECT ";
 		$compile .= "CONCAT($table[title]) AS title, ";
 		$compile .= ($table[description] == NULL ? "" : "CONCAT($table[description]) AS description, ");
 		$compile .= "CONCAT('$table[link]') AS link ";
 		$compile .= "FROM " . "\n";
 		$compile .= "$table[table_name] ";
 		$compile .= "WHERE " . "\n";
 		foreach (array_keys($rs->fields) as $field) {
 		$compile .= "$field ";
 		$compile .= "LIKE ";
 		$compile .= "'%$search_for%' OR ";
 		$compile .= "\n";
 		}
 		$compile = substr ($compile, 0, strlen($compile) - 4);
 		$compile .= "\n";
 		$SQL_array[] = $compile;
 		$i++;
	}

	$db->Disconnect();
	echo '   ';
	echo '<div align="left"><pre>';
	print_r($SQL_array);
	echo '</pre>';
	echo '<br />';



$data_fields = array(

"search" 	=> array(
		"sql" => "select * from Clients WHERE $search_type LIKE '%%$search_for%%' ",
		"sql_vars" => array("search_for", "search_type"),
		"default_sort" => array("Client_Id", "DESC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "button_edit.png", "Title" => "Edit this Client", "Target" => "../../modules/clients/client_index.php?link=client_specs.php")
								),

		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact 1"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
		)
	)

);


page_header("Search");
echo '<h1>Search</h1>';

if($search_for) {
	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields[search], &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';

	echo "<h2>Searching For: $_REQUEST[search_for]</h2>";

	echo $pager->Render($rows_per_page);
	$db->Disconnect();
}
$CSS = CSS();
?>
<html>
<head>
<?=$CSS?>
</head>
<body>
<table align="center"><tr>
		<td nowrap="nowrap" align="right"><img src="graphics/qsearch.gif" alt="Search: " /> </td>
<form action="search_build.php" target='_Self' method="post">
		<td align="center"><input type="text" style="font-size: .8em; width: 190px" name="find" value="<?=$_REQUEST[search_for]?>" onFocus="this.value=''" /></td></tr>
		<tr><td colspan="2" align="center"><br /><input type="submit" value="Search" /></td></form>
</tr></table>

<?



echo page_footer();



?>
</body>
</html>