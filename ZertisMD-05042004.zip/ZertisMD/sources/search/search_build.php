<?
session_start();
include('../../setup.php');
RequireLogin();

$arg = str_replace('/search_build.php', '', $_SERVER['REQUEST_URI']);

if($_POST['find']) {

    if(is_numeric($_POST['keywords'])) {
     $search_type = 'Client_Id';
    }
	else {
	 $search_type = 'Client_Name';
	}
	$keywords = $_POST['keywords'];


header ("location: $arg/search.php?keywords=$keywords&search_type=$search_type");
}
else
	header ("location: $arg/search.php");
?>