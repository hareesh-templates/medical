<?

include_once('../setup.php');
RequireLogin();



function make_dropdown ($sel='') {

  $db = &dbconnect();
  $SQL = "SELECT * FROM Searchable_Tables";
  $records = $db->GetAll("$SQL");
  $db->Close();

  // id
  // title
  // description
  // link

	$a = "<select name=\"search_type\">\n";
		foreach ($records as $record) {
		 $a .= "<option title=\"$record[description]\" value=\"$record[id]\"";
		 $a .= ($sel == $record[id] ? " SELECTED" : "");
		 $a .= ">$record[title]</option>\n";
		}
	$a .= "</select>";
	return $a;
}

function make_search () {
	if ( isset ($_REQUEST[search_type]))
		$sel =  $_REQUEST[search_type];
	else
		$sel = '';
	$dropdown = make_dropdown($sel);
return <<< EOR
<table border="0" cellspacing="0" cellpadding="2" style="margin:0px; padding:0px;">
<tr>
	<td valign="top">
	<input type="text" accesskey="s" style="font-size: 9.0pt; margin: 4px 0px 0px 0px; padding: 0px 0px 0px 0px; width: 140px;" name="keywords" value="Click Here to Search" onFocus="this.value=''" />
</td>
	<td valign="top">
		$dropdown</td>
</tr>
</table>

EOR;

}



?>