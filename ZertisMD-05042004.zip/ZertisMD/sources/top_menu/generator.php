<?
//Top Menu Generator

require_once(LIB_DIR . '/classes/class.Top_Menu.php');
include_once(SOURCES_DIR . 'access_c/control.php');

//include_once('../java-menu/jsdomenu.inc.php');



////////////////////////////////////////////////////
////////////////////////////////////////////////////
function generate_top_menu($user_id) {

// find authority of modules
	$list = Module_Access_List();

/*
echo '<pre>';
print_r($list);
echo '</pre>';
*/

	// Generate default Links
	$name	= array("Home");
	$urls	= array("main.php?");
	$target	= array("Main2");

	// Generate Modules Links
	$count = count($list[list_names]);
	for($i=0;$i<$count;$i++) {

		if($list[list_top][$i] == '1') {

			if($list[list_names][$i] == 'Admin') {
				$trigger = 'ON';
			} else {
			$name[]		= $list[list_names][$i];
			$urls[]		= $list[list_link][$i];
			$target[]	= "Main2";
			}
		}
	}

	// Generate Admin Link
	if($trigger == 'ON') {
	$name[]		= "Admin";
	$urls[]		= "../sources/admin.php";
	$target[]	= "Main2";

	}

	// User Control Panel Links
	$name[]		= "Change Password";
	$urls[]		= "../sources/users/change_my_password.php";
	$target[]	= "Main2";


	// Generate default Links
	$name[]		= "About";
	$urls[]		= "javascript:Secret()";
	$target[]	= "_self";


$links[links] =
	array(
		"link_names" 	=> $name,
		"link_urls" 	=> $urls,
		"target" 		=> $target
		);


$top_menu = new Top_Menu();
return $top_menu->Render($links[links]);


}



?>
