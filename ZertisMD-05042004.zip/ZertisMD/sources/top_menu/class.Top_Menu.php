<?
//Top Menu Generator

class Top_Menu {



 function Render($links) {
 $link = '';
 $count = count ($links[link_names]);

 	for ($i = 0; $i < $count; $i++) {
 		$link .= '<a href="' . $links[link_urls][$i] . '" target="' . $links[target][$i] . '">';
 		$link .= $links[link_names][$i];
 		$link .= '</a> : ';

  	}

	$link = substr($link, 0, -3);
 return $link;
 }




}
?>