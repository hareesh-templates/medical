<?

require_once(LIB_DIR . '/classes/class.Left_Menu.php');
require_once(LIB_DIR . '/classes/class.Left_Menu_Java.php');

//Side Menu Grabber
function MAKE_LEFT ($user_id, $group_id) {
	if($_REQUEST[MENU] == 'mail') {
	return 'Mail Menu';
	} else {
	$Left_Menu = new Left_Menu_Java($user_id, $group_id);
	return $Left_Menu->Build_Menu();
	}
}

?>