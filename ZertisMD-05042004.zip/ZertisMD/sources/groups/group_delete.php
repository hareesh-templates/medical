<?php
session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');





$ID = req("GroupID") or die("No ID");
$trigger = 'Off';
// Make sure group is empty


// First check UserGroups Table for active members.
	$sql = "SELECT COUNT(*) FROM UserGroups WHERE GroupID='$ID'";
	$db = &dbconnect();
	$count = $db->GetOne($sql);
	if($count)
		$trigger = 'On';
	$db->Close();


// Next check Users for active members
	$sql = "SELECT COUNT(*) FROM Users WHERE Group_Id='$ID'";
	$db = &dbconnect();
	$count = $db->GetOne($sql);
	if($count)
		$trigger = 'On';
	$db->Close();



// if no members exist go ahead and delete the group

	if($trigger == 'Off') {

	$group = "SELECT * FROM UserGroups WHERE GroupID='$_REQUEST[GroupID]'";
	$remove_group = @$db->GetAll($group);
	$count = count($remove_group);
		for($i=0;$i<$count;$i++) {
			$temp = "DELETE FROM UserGroups WHERE ID='" . $remove_group[$i][ID] . "'";
		}


	$module = "SELECT * FROM Module_Perms WHERE ID='$_REQUEST[GroupID]' AND Type='GROUP'";
	$remove_perm = @$db->GetAll($module);
	$count = count($remove_perm);
		for($i=0;$i<$count;$i++) {
			$temp = "DELETE FROM Module_Perms WHERE PermID='" . $remove_perm[$i][PermID] . "'";
		}


	 $sql = "DELETE FROM Groups WHERE GroupID=$ID";
	 $db =& dbconnect();
	 $db->Execute($sql) or die(mysql_error());
	 $db->Disconnect();
	}

if($trigger == 'Off')
	header("Location: groups.php?msgid=4");
else
	header("Location: groups.php?msgid=3");


?>