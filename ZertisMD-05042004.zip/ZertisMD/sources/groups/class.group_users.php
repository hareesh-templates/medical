<?

CLASS Group_Users {
var $ID = '';
 // List ID's of Users in Group
 
 
 
 function GroupUsers($ID) {
  $sql = "SELECT * FROM Users A, UserGroups T WHERE A.UserID = T.UserID AND GroupID='$ID'";
  $db = &dbconnect();
  $record = $db->GetAll($sql);
  $db->Close();

 	$count = count($record);
 	$s = '<select size="10" style="width: 160" name="Members[]" multiple>';
 	for($i=0;$i<$count;$i++) {
 	$s .= '<option value="';
 	$s .= $record[$i][UserID];
 	$s .= '">';
 	$s .= $record[$i][Login];
 	$s .= '</option>';
 	}
 	$s .= '</select>';
 	return $s;
 }

 function Other_Users($ID) {
  $sql = "SELECT Users.UserID, Login FROM Users LEFT JOIN UserGroups ON (Users.UserID = UserGroups.UserID AND UserGroups.GroupID ='$ID') WHERE UserGroups.GroupID IS NULL";
    $db = &dbconnect();
    $record2 = $db->GetAll($sql);
  $db->Close();
  
 	$count = count($record2);
 	$s = '<select size="10" style="width: 160" name="Users[]" multiple>';
 	$s .= "\n";
 	for($i=0;$i<$count;$i++) {
 	$s .= '<option value="';
 	$s .= $record2[$i][UserID];
 	$s .= '">';
 	$s .= $record2[$i][Login];
 	$s .= "</option>\n";
 	}
 	$s .= "</select>\n\n";
	return $s;
 }






}
?>