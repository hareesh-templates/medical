<?php

session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');

include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . "/classes/SmartPager.class.php");
require_once(LIB_DIR . "/classes/SmartPagerJavascript.groups.class.php");
page_header("Manage Groups");


// Get a message from another page
$msgid = req("msgid");
switch($msgid) {
case 3;
	$msg = "Group cannot be deleted.<br />Some users are still a member of this group.";
	break;
case 4:
	$msg = "Group deleted successfully";
	break;
default:
	$msg = "";

}

?>

<html>
<head>
<?=CSS()?>
</head>
<body>

<div class="Error"><?=$msg?></div>
<h1 align="center">Groups</h1>

<script language="JavaScript">
function confirm_group_delete(idd) {
	if(confirm("Are you sure you wish to delete this Group?")) {
		document.location = "group_delete.php?GroupID=" + idd;
	}
}
</script>
<div align="center" width="90%">
<a href="../admin.php" class="return">&lt;--back to administration</a><br />


<?


$data_fields = array(

"list" 	=> array(
		"sql" => "SELECT * FROM Groups",
		"default_sort" => array("GroupID", "ASC"),
		"pre_links" => array(
							array("QSVar" => "GroupID", "QSVal" => "GroupID", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit Group", "Target" => "group_edit.php"),
							array("QSVar" => "GroupID", "QSVal" => "GroupID", "Image" => IMAGE_DIR . "/button_browse.png", "Title" => "View Logs", "Target" => "../logs/usr_logs.php?select=by_group")
							),
		"fields" => array(
			"Group Name"	=> "Name"

		)
	)
);


	$db =& dbconnect();
	$pager = new SmartPagerJavascript($db, $data_fields['list'], &$_REQUEST);

	$pager->first = '<img src="graphics/Begin.png" alt="FIRST" border="0">';
	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';
	echo $pager->Render($rows_per_page);
	$db->Disconnect();

function ValidateAddGroupForm() {
	if(!$_POST['Name'])
		return "No Group Name provided.";
	return '';
}



function AddGroup($Name) {
	$res = ValidateAddGroupForm();
	if($res)
		return $res;
	$db =& dbconnect();
	$count = $db->GetOne("SELECT COUNT(*) FROM Groups WHERE Name='$Name'");
	if($count)
		return "The Group Name <i>$Name</i> is already taken.";
	$sql = "INSERT INTO Groups Set Name='$Name'";

	if(!$db->Execute($sql))
		return "Could not add group:" . mysql_error() . $sql;

	$Action = "Added Group: <i>" . $Name . "</i>";
	MakeLog("$Action", "Added Group");

	return '';
}



$group_error = "";

if(req("btnAddUser") == "Add Group") {
	$result = AddGroup(req("Name"));
	if($result)
		$group_error = $result;
	else
		$group_error = "Group added successfully";
}


?>



</div>


<table border="1" cellspacing="0" cellpadding="0" align="center">


<form action="groups.php" method="post">

<h2 align="center">Add Group</h2><br />

<table align="center">

<tr>

	<td colspan="2"><div class="Error"><?=$group_error?></div></td></tr>

<tr>
	<td>Group Name</td>
	<td><input type="text" name="Name" /></td></tr>


<tr>
	<td><br /></td></tr>


<tr>
	<td colspan="2" align="center"><input type="submit" name="btnAddUser" value="Add Group" /></td></tr>

</table>

</form>
<br /><br />
<a href="../admin.php" class="return">&lt;--back to administration</a><br />
<br />
<?

page_footer();


?>

</body>
</html>