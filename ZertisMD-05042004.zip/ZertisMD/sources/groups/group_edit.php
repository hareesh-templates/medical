<?php
session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');
require_once('functions.group_users.php');




$ID = req("GroupID") or die("No id");
$sql = "SELECT * FROM Groups WHERE GroupID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();


$group_error = "";

if(req("btnEditGroup") == "Edit Group") {
	$group_error = EditGroup($ID, req("Name"));
	if(!$group_error)
		$group_error = "Group updated successfully.";
	$Action = "Edited Group: <i>" . $record[Name] . "</i>";
	MakeLog("$Action", "Edited Group");
}

elseif(req("btnEditGroup") == "<<") {
 if($_POST[Users]) {
 	$count = count($_POST[Users]);
 	for($i=0;$i<$count;$i++) {
 		echo add_user($_POST[Users][$i], $ID);
 	}
 }
 	$Action = "Edited Group: <i>" . $record[Name] . "</i>";
	MakeLog("$Action", "Edited Group");
}




elseif(req("btnEditGroup") == ">>") {
 if(is_array($_POST[Members])) {
 	$count = count($_POST[Members]);
 	for($i=0;$i<$count;$i++) {
	 	echo remove_Members($_POST[Members][$i], $ID);
 	}
 }
 	$Action = "Edited Group: <i>" . $record[Name] . "</i>";
	MakeLog("$Action", "Edited Group");
}

// Grab the record to display




$Members	= GroupUsers($ID);
$NotMembers	= Other_Users($ID);

page_header("Edit Group");


$sql = "SELECT * FROM Groups WHERE GroupID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();
?>

<html>
<head>
<?=CSS()?>
</head>
<body>

<table cellspacing="4" cellpadding="0" border="0">
<tr>
	<td colspan="3" align="center"><h1>Editing Group <i><?=$record[Name]?></i></h1>
	<a href="groups.php" class="return">&lt;--back to groups</a><br />
	<br />
	</td>
</tr>

<tr>
	<td align="center" class="Other">Group Members</td>
	<td></td>
	<td align="center" class="Other">Members</td>
</tr>

<tr>
	<td>
		<form action="group_edit.php" method="post">
		<input type="hidden" name="GroupID" value="<?=$record[GroupID]?>" />
		<?=$Members?>
	</td>

	<td>
		<input type="submit" name="btnEditGroup" value=">>">
		</form>
		<br /><br />
		<form action="group_edit.php" method="post">
		<input type="hidden" name="GroupID" value="<?=$record[GroupID]?>" />
		<input type="submit" name="btnEditGroup"  value="<<">
	</td>

	<td>
		<?=$NotMembers?>
		</form>
	</td>

</tr>
<tr>
	<td align="center" colspan="3" class="Other">
		<font size="-1">Hold <i>Ctrl</i> to select more than one user.</font>
	</td>
</tr>
</table>

<br />
<form action="group_edit.php" method="post">
<input type="hidden" name="GroupID" value="<?=$record[GroupID]?>" />
<h2 align="center">Edit Group</h2>
<br />
<table align="center">
<tr>

	<td colspan="2"><div class="Error"><?=$group_error?></td></tr>
<tr>
	<td>Group Name</td>
	<td><input type="text" name="Name" value="<?=$record[Name]?>"/></td></tr>


<tr>
	<td><br /></td></tr>


<tr>
	<td colspan="2" align="center"><input type="submit" name="btnEditGroup" value="Edit Group" /></td></tr>

</table>

</form>
<br /><br />
<a href="groups.php" class="return">&lt;--back to groups</a><br />
<br />



<?
page_footer();
?>
</body>
</html>