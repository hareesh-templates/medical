<?php

session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');

page_header("Manage Modules");

?>


<html>
<head>
<?=CSS()?>
</head>
<body>

<?

function EditModule($ID, $top_menu, $side_menu, $side_menu_item, $image) {
	$sql = "UPDATE Module_Info Set top_menu='$top_menu', side_menu='$side_menu', side_menu_item='$side_menu_item', image='$image' WHERE ModuleID='$ID'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error());
	//	echo $sql;
	$db->Close();

}


$ID = req("ModuleID") or die("No id");

$sql = "SELECT * FROM Module_Info WHERE ModuleID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();


if(req("btnEditModule") == "Edit Module") {
	$module_error = EditModule($ID, req("top_menu"), req("side_menu"), req("side_menu_item"), req("image"));
	if(!module_error)
		$module_error = "Module updated successfully.";
	$Action = "Edited Module: <i>" . $record[Module] . "</i>, changed info.";
	MakeLog("$Action", "Edited Module");
}


$sql = "SELECT * FROM Module_Info WHERE ModuleID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();







// Get a message from another page
$msgid = req("msgid");
switch($msgid) {
case 3;
	$msg = "Module edited successfully";
	break;
case 3;
	$msg = "Module installed successfully";
	break;
case 4:
	$msg = "Module uninstalled successfully";
	break;
default:
	$msg = "";

}

if ($msg == "")
	$msg = $module_error;

function side_menu ($temp) {
	$s = "<select name='side_menu'>\n";
	$s.= "<option value='1'";
	$s.= ($temp == '1' ? 'SELECTED' : '');
	$s.= ">True</option>";
	$s.= "<option value='0'";
	$s.= ($temp == '0' ? 'SELECTED' : '');
	$s.= ">False</option>";
	$s.= "</select>";
	return $s;
}

function top_menu ($temp) {

	$s = "<select name='top_menu'>\n";
	$s.= "<option value='1'";
	$s.= ($temp == '1' ? 'SELECTED' : '');
	$s.= ">True</option>";
	$s.= "<option value='0'";
	$s.= ($temp == '0' ? 'SELECTED' : '');
	$s.= ">False</option>";
	$s.= "</select>";
	return $s;

}


function side_menu_item ($temp) {

 $s = "<select name='side_menu_item'>\n";
 $s.= "<option></option>\n";

	$db = &dbconnect();
	$record = $db->GetAll("SELECT * FROM Left_Menus");

	$count = count($record);
	for($i=0;$i<$count;$i++) {
		$s.= "<option value='" . $record[$i][MenuID] . "'";
		$s.= ($record[$i][MenuID] == $temp ? 'SELECTED' : '');
		$s.= ">" . $record[$i][menu_name] . "</option>";
	}
	$s.= "</select>";
	$db->Close();
	return $s;
}


$side_menu = side_menu($record[side_menu]);
$top_menu = top_menu($record[top_menu]);
$side_menu_item = side_menu_item($record[side_menu_item]);
?>





<div class="Error"><?=$msg?></div>
<form action="manage_modules.php" method="post">
<input type="hidden" name="ModuleID" value="<?=$ID?>" />
<table align="center" border="0" cellspacing="0" cellpadding="2">
<tr>
	<td align="center" colspan="2">
	<h1>Editing Module <i><?=$record[Module]?></i></h1>
	<a href="modules.php" class="return">&lt;--back to modules</a>
	<br /><br /><br />
	</td>
</tr>

<tr>
	<td>
		Link
	</td>
	<td>
		<span style="border:1px solid #202020; padding:4px; background: #CCCCCC;">
		<?=$record[link]?>
		</span>
	</td>
</tr>

<tr>
	<td align="center" colspan="2">
		<br />
	</td>
</tr>

<tr>
	<td>
		Top Menu
	</td>
	<td>
		<?=$top_menu?>
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
		<br />
	</td>
</tr>
<tr>
	<td>
		Side Menu
	</td>
	<td>
		<?=$side_menu?>
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
		<br />
	</td>
</tr>
<tr>
	<td>
		Side Menu ID
	</td>
	<td>
		<?=$side_menu_item?>
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
		<br />
	</td>
</tr>
<tr>
	<td>
		Side Menu Image
	</td>
	<td>
		<input type="text" value="<?=$record[image]?>" name="image">
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
		<br />
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
	<input type="submit" name="btnEditModule" value="Edit Module" />
	</td>
</tr>


<tr>
	<td align="center" colspan="2">
		<br /><br />
		<a href="modules.php" class="return">&lt;--back to modules</a>
		<br />
	</td>
</tr>
</table>
</form>



<?
page_footer();
?>


</body>
</html>