<?php

session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');
require_once('functions.module_users.php');

?>


<html>
<head>
<?=CSS()?>
</head>
<body>

<?

$ID = req("ModuleID") or die("No id");
$sql = "SELECT * FROM Module_Info WHERE ModuleID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();


if(req("btnEditModule") == "<< Allow User") {
 if(is_array($_POST[Users_Allow])) {
 	$count = count($_POST[Users_Allow]);
 	for($i=0;$i<$count;$i++) {
	 	echo add_user($_POST[Users_Allow][$i], $ID);
 	}
 }
 	$Action = "Added User to Module: <i>" . $record[Module] . "</i>, modified access.";
	MakeLog("$Action", "Edited Module");
}

elseif(req("btnEditModule") == "<< Deny User") {
 if(is_array($_POST[Users_Deny])) {
 	$count = count($_POST[Users_Deny]);
 	for($i=0;$i<$count;$i++) {
	 	echo deny_user($_POST[Users_Deny][$i], $ID);
 	}
 }
 	$Action = "Denied User from Module: <i>" . $record[Module] . "</i>, modified access.";
	MakeLog("$Action", "Edited Module");
}


elseif(req("btnEditModule") == "<< Allow Group") {
 if(is_array($_POST[Groups_Allow])) {
 	$count = count($_POST[Groups_Allow]);
 	for($i=0;$i<$count;$i++) {
	 	echo add_group($_POST[Groups_Allow][$i], $ID);
 	}
 }
 	$Action = "Added Group to Module: <i>" . $record[Module] . "</i>, modified access.";
	MakeLog("$Action", "Edited Module");
}

elseif(req("btnEditModule") == "<< Deny Group") {
 if(is_array($_POST[Groups_Deny])) {
 	$count = count($_POST[Groups_Deny]);
 	for($i=0;$i<$count;$i++) {
	 	echo deny_group($_POST[Groups_Deny][$i], $ID);
 	}
 }
 	$Action = "Denied Group from Module: <i>" . $record[Module] . "</i>, modified access.";
	MakeLog("$Action", "Edited Module");
}




elseif(req("btnEditModule") == "Remove >>") {
 if(is_array($_POST[Remove])) {
 	$count = count($_POST[Remove]);
 	for($i=0;$i<$count;$i++) {
	 	echo remove_Perm($_POST[Remove][$i]);
 	}
 }
 	$Action = "Removed Group From Module: <i>" . $record[Module] . "</i>, modified access.";
	MakeLog("$Action", "Edited Module");
}

// Grab the record to display


//---------------------------------------//
$ModuleUsers		= ModuleUsers($ID);
$OtherUsers		= Other_Users($ID);
//-                                     -//
$ModuleUsers_Allow	= $ModuleUsers[Allow];
$OtherUsers_Allow	= $OtherUsers[Allow];
$ModuleUsers_Deny	= $ModuleUsers[Deny];
$OtherUsers_Deny	= $OtherUsers[Deny];
//---------------------------------------//
$ModuleGroups		= ModuleGroups($ID);
$OtherGroups		= Other_Groups($ID);
//-                                     -//
$ModuleGroups_Allow	= $ModuleGroups[Allow];
$OtherGroups_Allow	= $OtherGroups[Allow];
$ModuleGroups_Deny	= $ModuleGroups[Deny];
$OtherGroups_Deny	= $OtherGroups[Deny];
//---------------------------------------//
page_header("Edit Module");
?>

<table cellspacing="4" cellpadding="0" border="0">
<tr>
	<td colspan="3" align="center">
		<h1>Editing Module <i><?=$record[Module]?></i></h1>
		<a href="modules.php" class="return">&lt;--back to modules</a>
		<br />
		<br />
	</td>
</tr>

<tr>
	<td colspan="3" align="center"><h2>Users</h2>
	<span  class="Other">Remember - User Permissions supercede Group Permissions.</span>
	<br />
	<br />
	</td>
</tr>
<tr>
	<td align="center" class="Other">Module Users Allowed</td>
	<td></td>
	<td align="center" class="Other">Users</td>
</tr>

<tr>
	<td>
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<?=$ModuleUsers_Allow?>
	</td>

	<td align="center">
		<input type="submit" name="btnEditModule" value="Remove >>">
		</form>
		<br /><br />
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<input type="submit" name="btnEditModule"  value="<< Allow User">
	</td>

	<td>
		<?=$OtherUsers_Allow?>
		</form>
	</td>

</tr>
<tr>
	<td align="center" colspan="3" class="Other">
		<font size="-1">Hold <i>Ctrl</i> to select more than one user.</font>
	</td>
</tr>

<tr>
	<td colspan="3" align="center">
		<br /><br />
	</td>
</tr>

<tr>
	<td align="center" class="Other">Module Users Denied</td>
	<td></td>
	<td align="center" class="Other">Users</td>
</tr>

<tr>
	<td>
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<?=$ModuleUsers_Deny?>
	</td>

	<td align="center">
		<input type="submit" name="btnEditModule" value="Remove >>">
		</form>
		<br /><br />
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<input type="submit" name="btnEditModule"  value="<< Deny User">
	</td>

	<td>
		<?=$OtherUsers_Deny?>
		</form>
	</td>

</tr>
<tr>
	<td align="center" colspan="3" class="Other">
		<font size="-1">Hold <i>Ctrl</i> to select more than one user.</font>
	</td>
</tr>



<tr>
	<td colspan="3" align="center">
	<br /><hr />
	<h2>Groups</h2>
	<br />
	</td>
</tr>
<tr>
	<td align="center" class="Other">Module Groups Allowed</td>
	<td></td>
	<td align="center" class="Other">Groups</td>
</tr>

<tr>
	<td>
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<?=$ModuleGroups_Allow?>
	</td>

	<td align="center">
		<input type="submit" name="btnEditModule" value="Remove >>">
		</form>
		<br /><br />
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<input type="submit" name="btnEditModule"  value="<< Allow Group">
	</td>

	<td>
		<?=$OtherGroups_Allow?>
		</form>
	</td>

</tr>
<tr>
	<td align="center" colspan="3" class="Other">
		<font size="-1">Hold <i>Ctrl</i> to select more than one group.</font>
	</td>
</tr>

<tr>
	<td colspan="3" align="center">
		<br /><br />
	</td>
</tr>

<tr>
	<td align="center" class="Other">Module Groups Denied</td>
	<td></td>
	<td align="center" class="Other">Groups</td>
</tr>

<tr>
	<td>
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<?=$ModuleGroups_Deny?>
	</td>

	<td align="center">
		<input type="submit" name="btnEditModule" value="Remove >>">
		</form>
		<br /><br />
		<form action="manage_access.php" method="post">
		<input type="hidden" name="ModuleID" value="<?=$record[ModuleID]?>" />
		<input type="submit" name="btnEditModule"  value="<< Deny Group">
	</td>

	<td>
		<?=$OtherGroups_Deny?>
		</form>
	</td>

</tr>
<tr>
	<td align="center" colspan="3" class="Other">
		<font size="-1">Hold <i>Ctrl</i> to select more than one group.</font>
	</td>
</tr>
</table>

<br />
<br /><br />
<a href="modules.php" class="return">&lt;--back to modules</a><br />
<br />



<?
page_footer();
?>


</body>
</html>