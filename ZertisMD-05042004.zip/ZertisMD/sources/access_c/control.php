<?
// Access Level Checking functions

////////////////////////////////////////////////////
////////////////////////////////////////////////////
//function list module names
function Module_Names() {

 	$db = &dbconnect();
 	$record = $db->GetAll("SELECT * FROM Module_Info");
 	$db->Close();
 	return $record;
}


////////////////////////////////////////////////////
////////////////////////////////////////////////////
//function check to see if user has access to modules by name
function Access_Check_This($Module) {
 	$trigger = '0';
 	$db = &dbconnect();
 	$record = $db->GetRow("SELECT ModuleID FROM Module_Info WHERE Module='$Module'");
 	$ModuleID = $record[ModuleID];


 	// Is Individual Allowed or Denied?
 	$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$_SESSION[UserID]' AND Type='USER' AND ModuleID='$ModuleID'";
 	$record = $db->GetRow("$sql");
 	if($record[Allow_Deny] == '1') {
		$user = 1;
 	}
 	elseif($record[Allow_Deny] == '0') {
 		$user = 0;
 	}
 	// Is Individual a member of a group allowed?  ( checking in UserGroups )

 	$record = $db->GetAll("SELECT GroupID FROM UserGroups WHERE UserID='$_SESSION[UserID]'");
 	$count = count($record);
 		for($i=0;$i<$count;) {
		$temp = $record[$i][GroupID];
 			$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$temp' AND Type='GROUP' AND ModuleID='$ModuleID'";
 		 	$new_record = $db->GetRow("$sql");
			 	if($new_record[Allow_Deny] == '1') {
			 		$trigger = 1;
		 		}
 		$i++;
 		}


 	// Is Individual a member of a group allowed? ( checking in the individual users properties, their "primary" group

	$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$_SESSION[GroupID]' AND Type='GROUP' AND ModuleID='$ModuleID'";
	$personal = $db->GetRow($sql);
	if($personal[Allow_Deny] == '1') {
		$trigger = 1;
	}

 	$db->Close();
	if($user == '0') {
	  	return '0';
	} elseif ($user == '1') {
		return "$Module";
	}
	if($trigger == '0') {
		return '0';
	} elseif ($trigger == '1') {
		return "$Module";
	}
	return '0';
}

////////////////////////////////////////////////////
////////////////////////////////////////////////////
// Function that checks if a user has access
// to a specific module
function  Access_Check($Module) {
 if(Access_Check_This($Module) == $Module) {
 	return 1;
 } else {
 	echo '<pre>';
 	print_r($_SESSION);
 	echo '</pre>';
	print 'ERROR: You do not have access to this module.';
	die();
 }

}
////////////////////////////////////////////////////
////////////////////////////////////////////////////
// function list all modules that user has access to
function Module_Access_List () {

 $records = Module_Names();
 $count = count($records);

 for($i=0;$i<$count;$i++) {
 	if(Access_Check_This($records[$i][Module]) == $records[$i][Module]) {
	$list_names[]	= $records[$i][Module];
	$list_id[]		= $records[$i][ModuleID];

	$list_top[]		= $records[$i][top_menu];
	$list_link[]	= $records[$i][link];

	$list_side[]	= $records[$i][side_menu];
	$list_menus[]	= $records[$i][side_menu_item];

	$list_image[]	= $records[$i][image];
	}

  }
  $db = &dbconnect();
  $count = count($list_id);
  for($i=0;$i<$count;$i++) {
 	$record = $db->GetRow("SELECT link FROM Module_Info WHERE ModuleID='$list_id[$i]'");
  	$list_link[] = $record[link];
  }
  $db->Close();
  $list = array(
  	"list_names" => $list_names,
  	"list_id" => $list_id,

  	"list_top" => $list_top,
  	"list_link" => $list_link,

  	"list_side" => $list_side,
  	"list_menus" => $list_menus,

  	"list_image" => $list_image
  	);
return $list;
}

////////////////////////////////////////////////////
////////////////////////////////////////////////////
// function that creates the proper link to a module
// by module name from Module_Info Table
function Module_Link ($Module) {
  $db = &dbconnect();

  	$record = $db->GetRow("SELECT link FROM Module_Info WHERE Module='$Module'");
 	if($record[link] == '') {
 	 $link = '';
 	} else {
 	 $link = $record[link];
 	}
  return $link;
  $db->Close();
}
?>