<?

 // List ID's of Users in Module





 function ModuleUsers($ID) {
  $sql = "SELECT Users.UserID, Login, Module_Perms.PermID, Allow_Deny
FROM Users
LEFT JOIN Module_Perms ON (
Users.UserID = Module_Perms.ID
AND Module_Perms.ModuleID = '$ID'
AND Module_Perms.Type = 'USER'
)
WHERE Module_Perms.PermID IS NOT NULL";

  $db = &dbconnect();
  $record = $db->GetAll($sql);
  $db->Close();

 	$count = count($record);
 	$a = '<select size="10" style="width: 160" name="Remove[]" multiple>';
 	$d = '<select size="10" style="width: 160" name="Remove[]" multiple>';
 	for($i=0;$i<$count;$i++) {
 		if($record[$i][Allow_Deny] == 1) {
 		 	$a .= '<option value="';
		 	$a .= $record[$i][PermID];
		 	$a .= '">';
		 	$a .= $record[$i][Login];
		 	$a .= '</option>';
 		}
 		else {
			$d .= '<option value="';
			$d .= $record[$i][PermID];
			$d .= '">';
			$d .= $record[$i][Login];
		 	$d .= '</option>';
 		}


 	}
 	$a .= '</select>';
 	$d .= '</select>';
 	$s = array("Allow" => $a, "Deny" => $d);
 	return $s;
 }





 function Other_Users($ID) {
  $sql = "SELECT Users.UserID, Login, Module_Perms.PermID, Allow_Deny
FROM Users
LEFT JOIN Module_Perms ON (
Users.UserID = Module_Perms.ID
AND Module_Perms.ModuleID = '$ID'
AND Module_Perms.Type = 'USER'
)
WHERE Module_Perms.PermID IS NULL";
    $db = &dbconnect();
    $record2 = $db->GetAll($sql);
  $db->Close();

 	$count = count($record2);
 	$a = '<select size="10" style="width: 160" name="Users_Allow[]" multiple>';
 	$d = '<select size="10" style="width: 160" name="Users_Deny[]" multiple>';
 	for($i=0;$i<$count;$i++) {
 		 	$a .= '<option value="';
		 	$a .= $record2[$i][UserID];
		 	$a .= '">';
		 	$a .= $record2[$i][Login];
		 	$a .= '</option>';

			$d .= '<option value="';
			$d .= $record2[$i][UserID];
			$d .= '">';
			$d .= $record2[$i][Login];
		 	$d .= '</option>';
 	}
 	$a .= '</select>';
 	$d .= '</select>';

 	$s = array("Allow" => $a, "Deny" => $d);
 	return $s;
 }




 function ModuleGroups($ID) {
  $sql = "SELECT Groups.GroupID, Name, Module_Perms.PermID, Allow_Deny
FROM Groups
LEFT JOIN Module_Perms ON (
Groups.GroupID = Module_Perms.ID
AND Module_Perms.ModuleID = '$ID'
AND Module_Perms.Type = 'GROUP'
)
WHERE Module_Perms.PermID IS NOT NULL";

  $db = &dbconnect();
  $record = $db->GetAll($sql);
  $db->Close();

 	$count = count($record);
 	$a = '<select size="10" style="width: 160" name="Remove[]" multiple>';
 	$d = '<select size="10" style="width: 160" name="Remove[]" multiple>';
 	for($i=0;$i<$count;$i++) {
 		if($record[$i][Allow_Deny] == 1) {
 		 	$a .= '<option value="';
		 	$a .= $record[$i][PermID];
		 	$a .= '">';
		 	$a .= $record[$i][Name];
		 	$a .= '</option>';
 		}
 		else {
			$d .= '<option value="';
			$d .= $record[$i][PermID];
			$d .= '">';
			$d .= $record[$i][Name];
		 	$d .= '</option>';
 		}


 	}
 	$a .= '</select>';
 	$d .= '</select>';
 	$s = array("Allow" => $a, "Deny" => $d);
 	return $s;
 }





 function Other_Groups($ID) {
  $sql = "SELECT Groups.GroupID, Name, Module_Perms.PermID
FROM Groups
LEFT JOIN Module_Perms ON (
Groups.GroupID = Module_Perms.ID
AND Module_Perms.ModuleID = '$ID'
AND Module_Perms.Type = 'GROUP'
)
WHERE Module_Perms.PermID IS NULL";
    $db = &dbconnect();
    $record2 = $db->GetAll($sql);
  $db->Close();

 	$count = count($record2);
 	$a = '<select size="10" style="width: 160" name="Groups_Allow[]" multiple>';
 	$d = '<select size="10" style="width: 160" name="Groups_Deny[]" multiple>';
 	for($i=0;$i<$count;$i++) {
 		 	$a .= '<option value="';
		 	$a .= $record2[$i][GroupID];
		 	$a .= '">';
		 	$a .= $record2[$i][Name];
		 	$a .= '</option>';

			$d .= '<option value="';
			$d .= $record2[$i][GroupID];
			$d .= '">';
			$d .= $record2[$i][Name];
		 	$d .= '</option>';
 	}
 	$a .= '</select>';
 	$d .= '</select>';

 	$s = array("Allow" => $a, "Deny" => $d);
 	return $s;
 }



function add_user($user_id, $ID) {
$sql = "INSERT INTO Module_Perms set ID='$user_id', ModuleID='$ID', Allow_Deny='1', Type='USER'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error($sql));
	$db->Close();
}


function deny_user($user_id, $ID) {
$sql = "INSERT INTO Module_Perms set ID='$user_id', ModuleID='$ID', Allow_Deny='0', Type='USER'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error($sql));
	$db->Close();
}

function add_group($group_id, $ID) {
$sql = "INSERT INTO Module_Perms set ID='$group_id', ModuleID='$ID', Allow_Deny='1', Type='GROUP'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error($sql));
	$db->Close();
}


function deny_group($group_id, $ID) {
$sql = "INSERT INTO Module_Perms set ID='$group_id', ModuleID='$ID', Allow_Deny='0', Type='GROUP'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error($sql));
	$db->Close();
}



function remove_Perm($ID) {
$sql = "DELETE FROM Module_Perms WHERE PermID='$ID'";
	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error($sql));
	$db->Close();
}

 ?>