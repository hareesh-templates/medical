<?php

session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');

include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . "/classes/SmartPager.class.php");
//require_once(LIB_DIR . "/classes/SmartPagerJavascript.groups.class.php");
page_header("Manage Modules");


// Get a message from another page
$msgid = req("msgid");
switch($msgid) {
case 3;
	$msg = "Module installed successfully";
	break;
case 4:
	$msg = "Module uninstalled successfully";
	break;
default:
	$msg = "";

}
?>


<html>
<head>
<?=CSS()?>
</head>
<body>



<div class="Error"><?=$msg?></div>
<h1 align="center">Modules</h1>

<script language="JavaScript">
function confirm_module_delete(idd) {
	if(confirm("Are you sure you wish to uninstall this module?")) {
		document.location = "module_delete.php?ModuleID=" + idd;
	}
}
</script>
<div align="center" width="90%">
<a href="../admin.php" class="return">&lt;--back to administration</a><br />


<?


$data_fields = array(

"list" 	=> array(
		"sql" => "SELECT * FROM Module_Info",
		"default_sort" => array("Module", "ASC"),
		"sql_vars" => array("link"),
		"pre_links" => array(
							array("QSVar" => "ModuleID", "QSVal" => "ModuleID", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit Module", "Target" => "manage_modules.php"),
							array("QSVar" => "ModuleID", "QSVal" => "ModuleID", "Image" => IMAGE_DIR . "/button_access.png", "Title" => "Manage Access", "Target" => "manage_access.php")
							),
		"fields" => array(
			"Module Name"	=> "Module",
			"Top Menu"		=> "top_menu",
			"Side Menu"		=> "side_menu"
		)
	)
);


	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields['list'], &$_REQUEST);

	$pager->first = '<img src="graphics/Begin.png" alt="FIRST" border="0">';
	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';
	echo $pager->Render($rows_per_page);
	$db->Disconnect();




?>

</div>

<br /><br />
<a href="../admin.php" class="return">&lt;--back to administration</a><br />
<br />
<?

page_footer();


?>


</body>
</html>