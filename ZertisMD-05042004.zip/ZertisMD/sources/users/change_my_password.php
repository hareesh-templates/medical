<?php

session_start();
include('../../setup.php');
RequireLogin();


$ID = $_SESSION[UserID] or die("No User Id in Session");

	$db = &dbconnect();
	$record = $db->GetRow("SELECT * FROM Users WHERE UserID='$ID'");
	$db->Close();
	$dbpassword = $record['Password'];


function ValidateForm($_POST) {
GLOBAL $dbpassword;


	$old_pass = md5($_POST['old']);
	if(!$_POST['old'])
		return "ERROR: You must provide your old password.";
	if(!$_POST['new1'])
		return "ERROR: You must type your new password twice.";
	if(!$_POST['new2'])
		return "Error You must type your new password twice.";
	if($_POST['new1'] != $_POST['new2'])
		return "Error: Your passwords do not match.";
	if($old_pass != $dbpassword)
		return "Error: That is not your old password.";
	return '';
}

function EditPassword($ID, $new1) {
$New_Password = md5($new1);
$db = &dbconnect();
$records = $db->Execute("UPDATE Users Set Password='$New_Password' WHERE UserID='$ID'") or die(mysql_error());
$db->Close();

}

if(req("frmBttn") == "Submit") {
	$password_error = ValidateForm($_POST);
	if(!$password_error)
		$password_error = EditPassword($ID, req("new1"));
	if(!$password_error)
		$password_error = "Password updated successfully.";
	$Action = "Changed Password: <i>" . $record[Name] . "</i>";
	MakeLog("$Action", "Changed Password");
}

page_header("Site Administration");

?>


<html>
<head>
<?=CSS()?>
</head>
<body>


<div align="center">
<h1>Change Password</h1>
<br />
<div align="center" class="Error"><?=$password_error?></div>
<br />
<form action="change_my_password.php" method="post">
<table border="0" cellspacing="2" cellpadding"0">
<tr>
	<td colspan="2" align="center">
	<hr><br />
	</td>
</tr>

<tr>
	<td class="other2">
	Old Password
	</td>
	<td>
	<input type="password" name="old">
	</td>
</tr>

<tr>
	<td class="other">
	New Password
	</td>
	<td>
	<input type="password" name="new1">
	</td>
</tr>

<tr>
	<td class="other2">
	Re-type New Password
	</td>
	<td>
	<input type="password" name="new2">
	</td>
</tr>

<tr>
	<td colspan="2" align="center"><br /><br />
	<input type="Submit" value="Submit" name="frmBttn">
	</td>
</tr>

</table>
</form>

</div>

<?
echo page_footer();
?>

</body>
</html>
