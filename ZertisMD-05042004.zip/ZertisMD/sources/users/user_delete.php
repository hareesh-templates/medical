<?php
session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');


$ID = req("UserID") or die("No ID");


$db =& dbconnect();


$group = "SELECT * FROM UserGroups WHERE UserID='$_REQUEST[UserID]'";
$remove_group = @$db->GetAll($group);
$count = count($remove_group);
	for($i=0;$i<$count;$i++) {
		$temp = "DELETE FROM UserGroups WHERE ID='" . $remove_group[$i][ID] . "'";
		@$db->Execute($temp);

	}

$module = "SELECT * FROM Module_Perms WHERE ID='$_REQUEST[UserID]' AND Type='USER'";
$remove_perm = @$db->GetAll($module);
$count = count($remove_perm);
	for($i=0;$i<$count;$i++) {
		$temp = "DELETE FROM Module_Perms WHERE PermID='" . $remove_perm[$i][PermID] . "'";
		@$db->Execute($temp);
	}


$sql = "DELETE FROM Users WHERE UserID=$ID";
$db->Execute($sql) or die(mysql_error());
$db->Disconnect();
header("Location:users.php?msgid=4");


?>