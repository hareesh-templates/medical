<?php

session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');

include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . "/classes/SmartPager.class.php");
require_once(LIB_DIR . "/classes/SmartPagerJavascript.class.php");
page_header("Manage Users");

// Get a message from another page
$msgid = req("msgid");
switch($msgid) {
case 4:
	$msg = "User deleted successfully";
default:
	$msg = "";

}

?>


<html>
<head>
<?=CSS()?>
</head>
<body>


<div class="Error"><?=$msg?></div>
<h1 align="center">Users</h1>

<script language="JavaScript">
function confirm_user_delete(idd) {
	if(confirm("Are you sure you wish to delete this user?")) {
		document.location = "../sources/users/user_delete.php?UserID=" + idd;
	}
}
</script>
<div align="center" width="90%">
<a href="../admin.php" class="return">&lt;--back to administration</a><br />


<?


$data_fields = array(

"list" 	=> array(
		"sql" => "SELECT GroupID, T.Name As Group_Id, UserID, Login, Full_Name, Email, Home_Phone, Cell_Phone FROM Users A,Groups T WHERE A.Group_Id=T.GroupID",
		"default_sort" => array("Login", "ASC"),
		"pre_links" => array(
							array("QSVar" => "UserID", "QSVal" => "UserID", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit User", "Target" => "user_edit.php"),
							array("QSVar" => "UserID", "QSVal" => "UserID", "Image" => IMAGE_DIR . "/button_browse.png", "Title" => "View Logs", "Target" => "../logs/usr_logs.php?select=by_user")
							),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Login" 	=> array("QSVar" => "UserID", "QSVal" => "UserID", "Title" => "Edit User", "Target" => "user_edit.php")
								),

		"fields" => array(
			"Login Name"	=> "Login",
			"Real Name"		=> "Full_Name",
			"Email"			=> "Email",
			"Home Phone"	=> "Home_Phone",
			"Cell Phone"	=> "Cell_Phone",
			"Primary User Type"		=> "Group_Id"
		)
	)
);


	$db =& dbconnect();
	$pager = new SmartPagerJavascript($db, $data_fields['list'], &$_REQUEST);

	$pager->first = '<img src="graphics/Begin.png" alt="FIRST" border="0">';
	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';
	echo $pager->Render($rows_per_page);
	$db->Disconnect();

function ValidateAddUserForm() {
	if(!$_POST['Login'])
		return "No login provided.";
	if(!$_POST['Password'])
		return "No password provided.";
	if($_POST['Password'] != $_POST['Password2'])
		return "The passwords do not match.";
	return '';
}



function AddUser($login, $password, $type) {
	$res = ValidateAddUserForm();
	if($res)
		return $res;
	$db =& dbconnect();
	$count = $db->GetOne("SELECT COUNT(*) FROM Users WHERE Login='$login'");
	if($count)
		return "The Login $login is already taken.";
	$sql = "INSERT INTO Users Set Login='$login', Full_Name='$_POST[Full_Name]', Email='$_POST[Email]', SSN='$_POST[SSN]', Address_Line_1='$_POST[Address_Line_1]', Address_Line_2='$_POST[Address_Line_2]', Address_City='$_POST[Address_City]', Address_Zip='$_POST[Address_Zip]', Address_State='$_POST[Address_State]', Home_Phone='$_POST[Home_Phone]', Cell_Phone='$_POST[Cell_Phone]', Password=MD5('$password'), Group_Id='$_POST[Group_Id]' ";

	if(!$db->Execute($sql))
		return "Could not add user:" . mysql_error() . $sql;

	$Action = "Added User: <i>" . $login . "</i>";
	MakeLog("$Action", "Added User");

	return '';
}



$user_error = "";

if(req("btnAddUser") == "Add User") {
	$result = AddUser(req("Login"), req("Password"), req("Group_Id"));
	if($result)
		$user_error = $result;
	else
		$user_error = "User added successfully";
}




function UserTypeDropDown($type='') {

	$db = &dbconnect();
	$records = $db->GetAll("SELECT GroupID, Name FROM Groups ORDER BY GroupID ASC");
	$db->Close();
	$s = '';

	$count = count($records);
	for($i=0;$i<$count;$i++) {
		$s .= "<option value='" . $records[$i][GroupID] . "'";
		if($type == $records[$i][GroupID]) {
			$s .= " selected='selected'";
		}
		$s .= ">" . $records[$i][Name] . "</option>\n";
	}
	return $s;
}

$DropDown = UserTypeDropDown();
?>



</div>


<table border="1" cellspacing="0" cellpadding="0" align="center">


<form action="users.php" method="post">

<h2 align="center">Add User</h2><br />

<table align="center">

<tr>

	<td colspan="2"><div class="Error"><?=$user_error?></td></tr>

<tr>
	<td>Login</td>
	<td><input type="text" name="Login" /></td></tr>

<tr>
	<td>Password</td>
	<td><input type="password" name="Password" /></td></tr>

<tr>
	<td>Password (again)</td>
	<td><input type="password" name="Password2" /></td></tr>

<tr>
	<td>Full Name</td>
	<td><input type="text" name="Full_Name" /></td></tr>


<tr>
	<td>SSN</td>
	<td><input type="text" name="SSN" /></td></tr>

<tr>
	<td>Email</td>
	<td><input type="text" name="Email" /></td></tr>

<tr>
	<td>Home Phone</td>
	<td><input type="text" name="Home_Phone" /></td></tr>

<tr>
	<td>Cell Phone</td>
	<td><input type="text" name="Cell_Phone" /></td></tr>

<tr>
	<td>Address Line 1</td>
	<td><input type="text" name="Address_Line_1" /></td></tr>

<tr>
	<td>Address Line 2</td>
	<td><input type="text" name="Address_Line_2" /></td></tr>

<tr>
	<td>City</td>
	<td><input type="text" name="Address_City" /></td></tr>

<tr>
	<td>Zip</td>
	<td><input type="text" name="Address_Zip" /></td></tr>

<tr>
	<td>State</td>
	<td><select name="Address_State"><? echo state_list(); ?></td></tr>

<tr>
	<td>User Group</td>
	<td><select name="Group_Id">
		<?=$DropDown?></select></td></tr>

<tr>
	<td><br /></td></tr>

<tr>

	<td colspan="2" align="center"><input type="submit" name="btnAddUser" value="Add User" /></td></tr>

</table>

</form>
<br /><br />
<a href="../admin.php" class="return">&lt;--back to administration</a><br />
<br />
<?

page_footer();


?>


</body>
</html>