<?php
session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Admin');


?>


<html>
<head>
<?=CSS()?>
</head>
<body>

<?
function UserTypeDropDown($type='') {

	$db = &dbconnect();
	$records = $db->GetAll("SELECT GroupID, Name FROM Groups ORDER BY GroupID ASC");
	$db->Close();
	$s = '';

	$count = count($records);
	for($i=0;$i<$count;$i++) {
		$s .= "<option value='" . $records[$i][GroupID] . "'";
		if($type == $records[$i][GroupID]) {
			$s .= " selected='selected'";
		}
		$s .= ">" . $records[$i][Name] . "</option>\n";
	}
	return $s;
}

/*
function SecondaryTypeDropDown($type='') {

	$db = &dbconnect();
	$records = $db->GetAll("SELECT * FROM UserGroups A, Groups T WHERE A.GroupID = T.GroupID AND UserID='$_SESSION[UserID]'");
	$db->Close();
	$s = '';

	$count = count($records);
	for($i=0;$i<$count;$i++) {
		$s .= "<option value='" . $records[$i][GroupID] . "'";
		if($type == $records[$i][GroupID]) {
			$s .= " selected='selected'";
		}
		$s .= ">" . $records[$i][Name] . "</option>\n";
	}
	return $s;
}
*/

function EditUser($ID, $login, $pword, $pword2, $type) {

	if(!$login)
		return "No login given";

	if($pword && $pword != $pword2)
		return "Passwords do not patch";


	$sql = "UPDATE Users Set Login='$login', Full_Name='$_POST[Full_Name]', Email='$_POST[Email]', SSN='$_POST[SSN]', Address_Line_1='$_POST[Address_Line_1]', Address_Line_2='$_POST[Address_Line_2]', Address_City='$_POST[Address_City]', Address_Zip='$_POST[Address_Zip]', Address_State='$_POST[Address_State]', Home_Phone='$_POST[Home_Phone]', Cell_Phone='$_POST[Cell_Phone]'";
	if($pword)
		$sql .= ", Password=MD5('$pword')";

	$sql .= ", Group_Id='$type' WHERE UserID='$ID'";

	$db = &dbconnect();
	$db->Execute($sql) or die(mysql_error());
	//	echo $sql;
	$Action = "Edited User: <i>" . $login . "</i>";
	MakeLog("$Action", "Edited User");

	$db->Close();
}


$ID = req("UserID") or die("No id");
$user_error = "";

if(req("btnEditUser") == "Edit User") {
	$user_error = EditUser($ID, req("Login"), req("Password"), req("Password2"), req("Group_Id"));
	if(!$user_error)
		$user_error = "User updated successfully.";
}


// Grab the record to display
$sql = "SELECT * FROM Users WHERE UserID=$ID";
$db = &dbconnect();
$record = $db->GetRow($sql);
$db->Close();

$DropDown = UserTypeDropDown($record['Group_Id']);

page_header("Edit User");
?>
<a href="users.php" class="return">&lt;--back to users</a><br />
<form action="user_edit.php" method="post">
<input type="hidden" name="UserID" value="<?=$record[UserID]?>" />
<h2 align="center">Edit User</h2>
<table align="center">
<tr>

<table align="center">

<tr>

	<td colspan="2"><div class="Error"><?=$user_error?></td></tr>

<tr>
	<td>Login</td>
	<td><input type="text" name="Login" value="<?=$record[Login]?>" /></td></tr>

<tr>
	<td>Password</td>
	<td><input type="password" name="Password" /></td></tr>

<tr>
	<td>Password (again)</td>
	<td><input type="password" name="Password2" /></td></tr>

<tr>
	<td>Full Name</td>
	<td><input type="text" name="Full_Name" value="<?=$record[Full_Name]?>" /></td></tr>


<tr>
	<td>SSN</td>
	<td><input type="text" name="SSN" value="<?=$record[SSN]?>" /></td></tr>

<tr>
	<td>Email</td>
	<td><input type="text" name="Email" value="<?=$record[Email]?>" /></td></tr>

<tr>
	<td>Home Phone</td>
	<td><input type="text" name="Home_Phone" value="<?=$record[Home_Phone]?>" /></td></tr>

<tr>
	<td>Cell Phone</td>
	<td><input type="text" name="Cell_Phone" value="<?=$record[Cell_Phone]?>" /></td></tr>

<tr>
	<td>Address Line 1</td>
	<td><input type="text" name="Address_Line_1" value="<?=$record[Address_Line_1]?>" /></td></tr>

<tr>
	<td>Address Line 2</td>
	<td><input type="text" name="Address_Line_2" value="<?=$record[ss_Line_2]?>" /></td></tr>

<tr>
	<td>City</td>
	<td><input type="text" name="Address_City" value="<?=$record[Address_City]?>" /></td></tr>

<tr>
	<td>Zip</td>
	<td><input type="text" name="Address_Zip" value="<?=$record[Address_Zip]?>" /></td></tr>

<tr>
	<td>State</td>
	<td><select name="Address_State" value=""><? echo state_list($record[Address_State]); ?></td></tr>

<tr>
	<td>User Type</td>
	<td><select name="Group_Id"><?=$DropDown?>
		</select></td></tr>


<tr>
	<td></td>
	<td><input type="submit" name="btnEditUser" value="Edit User" /></td></tr>
</table>
<a href="users.php" class="return">&lt;--back to users</a><br />
<?
page_footer();
?>

</body>
</html>