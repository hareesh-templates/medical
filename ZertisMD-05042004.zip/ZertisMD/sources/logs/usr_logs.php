<?php
session_start();
include('../../setup.php');
RequireLogin();
Access_Check('Logs');


include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . "/classes/SmartPager.class.php");
?>


<html>
<head>
<?=CSS()?>
</head>
<body>

<?


function Action_Select ($selected='') {
	$db =& dbconnect();
	$type = $db->GetAll("SELECT * FROM log_actions");
	$count = count($type);
		$s = '<form action="usr_logs.php?select=by_action" name="action_selector" method="post">';
		$s .= "<select name='action_select' onchange='this.form.submit()'>\n";
		$s .= "<option></option>\n";
		for($i=0;$i<$count;$i++) {
		$s .= "<option value='" . $type[$i][Action] . "'";
		$s .= ($selected == $type[$i][Action] ? 'SELECTED' : '') . ">" . $type[$i][Action];
		$s .= "</option>\n";
		}
		$s .= "</select>\n";
		$s .= "</form>\n";
	$db->Disconnect();
	return $s;
}




function head($request) {
$head .= '
	<div align="center">
	<h2 align="center">Select a Log Type</h2>
	<center>
	&nbsp; '.($request == 'by_date' ? '':'<a href="?select=by_date">').'Date'.($request == 'by_date' ? '':'</a>').' &nbsp;
	&nbsp; : &nbsp;<a href="../users/users.php">User</a>&nbsp; : &nbsp;
	&nbsp; : &nbsp;<a href="../groups/groups.php">Group</a>&nbsp; : &nbsp;
	&nbsp; '.($request == 'by_action' ? '':'<a href="?select=by_action">').'Action'.($request == 'by_action' ? '':'</a>').'
	</center><hr /></div>';

return $head;
}

$request = $_REQUEST['select'];

//  ORDER BY
//  ORDER BY
//  ORDER BY


$Action_Selector = Action_Select($_REQUEST[action_select]);
//$_REQUEST[action_select];

$data_fields = array(
	"by_date" 	=> array(
		"sql" => "select GroupID, T.Name As user_type, id, user_name, action, action_date from admin_logs A,Groups T WHERE A.user_type=T.GroupID",
		"sql_vars" => array("select", "link"),
		"default_sort" => array("action_date", "DESC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"user_name" 	=> array("QSVar" => "UserID", "QSVal" => "id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit this User", "Target" => "../users/user_edit.php")
						),
		"fields" => array(
						"Date" 			=> "action_date",
						"Name" 			=> "user_name",
						"Action"		=> "action",
						"Type"			=> "user_type"
		)
	),
	"by_group" 	=> array(
		"sql" => "SELECT GroupID, T.Name AS user_type, id, user_name, action, action_date FROM admin_logs A, Groups T WHERE A.user_type = T.GroupID AND user_type = '%s'",
		"sql_vars" => array("GroupID", "select", "link"),
		"default_sort" => array("action_date", "DESC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"user_name" 	=> array("QSVar" => "UserID", "QSVal" => "id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit this User", "Target" => "../users/user_edit.php")
						),
		"fields" => array(
						"Date" 			=> "action_date",
						"Name" 			=> "user_name",
						"Action"		=> "action",
		)
	),

	"by_user" 	=> array(
		"sql" => "select id, T.Name user_type, user_name, action, action_date from admin_logs A, Groups T WHERE A.user_type=T.GroupID AND id='%s'",
		"sql_vars" => array("UserID", "select", "link"),
		"default_sort" => array("action_date", "DESC"),
		"fields" => array(
						"Date" 			=> "action_date",
						"Action" 		=> "action",
						"Type"			=> "user_type"
		)

	),
	"by_action" => array(
		"sql" => "SELECT GroupID, T.Name AS user_type,
 id, user_name, action, action_date
FROM admin_logs A, Groups T
WHERE A.user_type = T.GroupID
 AND ( action
LIKE  '%%$_REQUEST[action_select]%%' )",

		"sql_vars" => array("action_select", "select", "link"),
		"default_sort" => array("action_date", "DESC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"user_name" 	=> array("QSVar" => "UserID", "QSVal" => "id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Edit this User", "Target" => "../users/user_edit.php")
						),

		"fields" => array(
						"Date" 			=> "action_date",
						"Action" 		=> "action",
						"Name" 			=> "user_name",
						"Type" 			=> "user_type"
		)
	)
);

page_header("User Logs");
echo head($request);

if(array_key_exists($request, $data_fields)) {
	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields[$request], &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';

	echo '<h1>';
	switch($request) {
	case 'by_group':
		$record = $db->GetRow("SELECT * FROM Groups WHERE GroupID=$_REQUEST[GroupID]");
		echo "Viewing Group <i>$record[Name]'s</i>";
	break;
	case 'by_user':
		$record = $db->GetRow("SELECT * FROM Users WHERE UserID=$_REQUEST[UserID]");
		echo "Viewing User <i>$record[Login]</i>";
		break;
	case 'by_action':
		echo "Viewing Logs by: Action <br /><br />";
		echo $Action_Selector;
		break;
	case 'by_date':
		echo "Viewing Logs by: Date";
		break;
	default:
		echo 'BUG';

	}
	echo '</h1>';
	echo $pager->Render($rows_per_page);
	$db->Disconnect();

}



echo page_footer();

?>

</body>
</html>