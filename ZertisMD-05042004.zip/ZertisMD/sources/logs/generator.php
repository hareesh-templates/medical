<?
//No access level required, simply must be logged in.


/////////////////////////////////////////////////////
// Generate Logfile Function
// Specify full log and Search Action for Log Browsing
/////////////////////////////////////////////////////
function MakeLog($Log_Action_Full, $Log_Action) {
	$db = &dbconnect();
	
	$id=$_SESSION[UserID];
	$Login=$_SESSION[Login];
	$GroupID=$_SESSION[GroupID];
	// The below code does the following
	/* In the event that a user is logged out
	by the server restarting, or session being killed
	for whatever reason, but the browser is still open.
	When clicking on a link, or clicking logout, they are still
	directed to the proper location, for all frames, the login window
	*/
	if($id == '') {
	echo '
		<script language="Javascript">
		<!--
		window.location="' . BASE_URL. '";
		-->
		</script>
	';
	
	//header("Location: " . BASE_URL);
	die();
	}
	
	$record = $db->GetRow("SELECT Action FROM log_actions WHERE Action='$Log_Action'");
	if(!$record) {
		$db->Execute("INSERT INTO log_actions set Action='$Log_Action'");
	}

	$today = date("Y-m-d g:i:s A");
	$sql = "INSERT INTO admin_logs (id, user_type, user_name, action, action_date) VALUES ('$id', '$GroupID', '$Login', '$Log_Action_Full', '$today')";
	if(!$db->Execute($sql)) {
		return "Could not add Log File:" . mysql_error();
	}
	
	$db->Close();
}

?>