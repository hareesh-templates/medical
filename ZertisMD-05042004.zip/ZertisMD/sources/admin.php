<?php
session_start();
include('../setup.php');
RequireLogin();
Access_Check('Admin');
?>
<html>
	<head>
	<?=CSS()?>
</head>
<body>
<?page_header("Site Administration")?>
<h1 align="center">Site Administration</h1>
<br /><br />
<div align="center"><input type="button" onclick="document.location='users/users.php'" value="Manage Users" />
&nbsp;&nbsp;&nbsp;
<input type="button" onclick="document.location='groups/groups.php';" value="Manage Groups" /></div>
<br /><br />
<div align="center"><input type="button" onclick="document.location='logs/usr_logs.php'" value="View Logs" /></div>
<br /><br />
<div align="center"><input type="button" onclick="document.location='access_c/modules.php'" value="Select Module" />
&nbsp;&nbsp;&nbsp;
<input type="button" onclick="document.location='access_c/modules.php'" value="Modules Access" /></div>
<br />
<?page_footer()?>
</body>
</html>