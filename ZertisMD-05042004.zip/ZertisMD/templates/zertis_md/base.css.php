<?

function css() {
$IMAGE_DIR = IMAGE_DIR;
$PROGRAM = PROGRAM;
return <<< EOOF
<style type="text/css">
.Error {
	font-weight: bold;
	font-family; Arial;
	text-align: center;
	color: #FF0000;
}


textarea, input {
color: #000000;
text-decoration: NONE;
font-weight: plain
font-size: 10px;
}

.TopMenu  {
	color: #4F4F4F;
	text-decoration: none;
	font-weight: plain;
	text-align: left;
}
.TopMenu:hover {
	color: #4F4F4F;
	text-decoration: none;
	font-weight: plain;
}
/*
Smarty Pager Begin
*/
.smarty_table {
border:1px solid #808080;
}

TR.Row0 {
	background-color: #FFFFFF;
	font-family: Verdana;
	font-size: 10pt;
}

TR.Row0 a:link, TR.Row0 a:visited {
	color: #0000FF;
	text-decoration: none;
	font-family: Verdana;
	font-size: 10pt;
}

TR.Row0 a:HOVER {
	color: #FF0000;
	text-decoration: none;
}

TR.Row0:HOVER {
	color: #0000FF;
	text-decoration: none;
	background-color: #FEFEDD;
}

TR.Row1 {
	font-family: Verdana;
	font-size: 10pt;
	background-color: #EFEFEF;
}


TR.Row1 a:link, TR.Row1 a:visited {
	color: #0000FF;
	text-decoration: none;
	font-family: Verdana;
	font-size: 10pt;
}

TR.Row1 a:HOVER {
	color: #FF0000;
	text-decoration: none;
}

TR.Row1:HOVER {
	background-color: #FEFEDD;
	text-decoration: none;
	color: #0000FF;
}

.divider {
	border-left: 1px dashed #808080;
}

.CurrentSort {
	font-weight: bold;
	color: #202020;
	text-decoration: underline;
	text-align: left;
}

TR.Menu_Head {
	background-color: #91B3C1;
	background-image: url($IMAGE_DIR/bg.png);
	color: #FF2222;
	font-family: Arial;
	font-weight: bold;
	font-size: 9pt;
}


.TopLinks {
	color: #003366;
	font-family: Arial;
	font-weight: bold;
	font-size: 9pt;
	text-decoration: none;
}

.TopLinks:HOVER {
	text-decoration: underline;
	color: #FF0000;
}

/*
Smarty Pager End
*/

.return:link, .return:visited {
	text-decoration: none;
	color: #003366;
	font-size: 10pt;
	font-family: verdana;
	font-weight: plain;
	text-decoration: none;
}

.return:hover {
	text-decoration: none;
	color: #AA0000;
	font-weight: plain;
	font-family: verdana;
}



H1 {
	font-family: Arial;
	font-size: 1.5em;
	color: #336699;
}

H2 {
	font-family: Arial;
	font-size: 1.2em;
	color: #888888;
	margin-bottom: 0px;
}

H3 {
	font-family: Arial;
	font-size: 12px;
	color: #8888FF;
	margin-bottom: 0px;
}


TD.FormCaption, .FormCaption {
	font-family: Ms Sans Serif;
	text-align: right;
	font-weight: bold;
	font-size: .9em;
	color:#202020;
}



BODY	{
	color: #000000;
	background-color: #FFFFFF;
	font-family: Arial;
	font-size: .9em;
	margin: 0px 0px 0px 0px;
	padding: 0px 0px 0px 0px;

}

.other {
	color: #003366;
	font-family: Arial;
	font-weight: bold;
	font-size: 9pt;
	text-decoration: none;
}
.other2 {
	color: #000033;
	font-family: Arial;
	font-weight: plain;
	font-size: 9pt;
	text-decoration: none;
}



#Header {
	font-family: Verdana;
	font-size: 14pt;
	font-weight: plain;
	color: #202099;
	}

div[id=Header] {
	color: #000000 !important;
	font-weight: plain;
	font-family: Verdana;
	font-size: 14pt;
	font-weight: plain;
	}
#Header:after {
	content: '$PROGRAM';
	color: #336699; 
	font-weight: plain;
	display: block;
	text-indent: .51ex;
	margin-top: -1.29em;
}


.Pipe {
	color: #202020;
	font-family: Verdana;
	font-size: 10px;
	font-weight: bold;
}

.Zertis
{
position: absolute;
top: -100px;
left: -100px;
}

.Top_Menu {
	color: #000000;
	background-color: #FFFFFF;
	font-family: Arial;
	background-image: url($IMAGE_DIR/new.png);
	font-size: 8pt;
	margin: 0px 0px 0px 0px ;
	height:28px;
	padding: 0px 0px 0px 0px;
	border-top:1px solid #404040;

}

.TopBar {
	color: #101010;
	background-color: #FFFFFF;
	background-image: url($IMAGE_DIR/stretchbar.jpg);
	font-family: Arial;
	font-size: .9em;
	height: 17px;
	background-position: top left;
	background-repeat: repeat-y;
	margin: 0px;
	padding; 0px:
}

.Menu {
	color: #000000;
	background-color: #EfEfEf;
	background-image: url($IMAGE_DIR/bg.png);
	text-align:left;
	padding: 0px 0px 0px 0px;
	font-family: Verdana;
	font-size: 10pt;
	font-weight: plain;
	height: 22px;
	background-position: top left;
	background-repeat: repeat-x;
}

.Menu a:visited, .Menu a:link {
	color: #003366;
	font-family: Verdana;
	font-size: 10pt;
	font-weight: bold;
	text-decoration: none;
}

.Menu a:hover {
	color: #000000;
	font-family: Verdana;
	font-size: 10pt;
	font-weight: bold;
	text-decoration: none;
}

.Tabs {
	margin: 10px 0px 0px 0px;
	

}

.TabActive {
	font-weight: bold;
	font-family: Arial, Helvetica, Sans Serif;
	font-size: 10pt;
	margin: 0px 3px 1px 3px;
	text-align: center;
	color: #003366;
	text-decoration: none;
}
.TabInactive, .TabInactive a:link, .TabInactive a:active,
.TabInactive a:visited, .TabInactive a:hover {
	font-weight: bold;
	font-family: Arial, Helvetica, Sans Serif;
	font-size: 9pt;
	margin: 0px 3px 1px 3px;
	text-align: center;
	text-decoration: none;
	color: #000000;
}


</style>

EOOF;
}

?>
