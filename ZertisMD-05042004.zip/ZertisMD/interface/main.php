<?php

session_start();
include('../setup.php');
RequireLogin();


// Eventually, I want the admin to be able to chose where the login page
// is with then use a variable and send all users loging in to that location.
// Until then, we will still always send them to this file, but manually change
// the location depending on the program job.

header ("Location: ../modules/calendar/login.php?return_path=day.php");

//echo "No modules Installed.";


?>
