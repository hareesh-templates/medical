<?
session_start();
include('../setup.php');
RequireLogin();



$smarty = GetSmarty();
$smarty->display('index_main.tpl');

?>