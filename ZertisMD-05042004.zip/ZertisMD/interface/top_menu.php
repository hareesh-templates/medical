<?
// Generate Top Page
session_start();
include('../setup.php');
RequireLogin();
require_once(SOURCES_DIR . 'top_menu/generator.php');

include_once('../sources/search/search_form.php');
$search = make_search();
include_once('../modules/patients/facility_selector.php');
$selector = show_facilities($my_facility);

$PROGRAM = PROGRAM;
$menu = generate_top_menu($_SESSION['UserID']);
//$menu = generate_top_menu("1");




$smarty = GetSmarty();
$smarty->assign('USER_NAME', $_SESSION['Login']);
$smarty->assign('CSS', css());
$smarty->assign('notify',$notify);
$smarty->assign('MENU', $menu);
$smarty->assign('SEARCH', $search);
$smarty->assign('SELECTOR', $selector);
$smarty->display('top_menu.tpl');

?>