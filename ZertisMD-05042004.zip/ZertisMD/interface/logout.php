<?
session_start();
include('../setup.php');

MakeLog('Logged Out', 'Logged Out');


$_SESSION["UserID"] = '';
$_SESSION["Login"] = '';
$_SESSION['GroupID'] = '';

header("location: " . BASE_URL . "interface/login.php");	
echo 'Please wait...';
?>