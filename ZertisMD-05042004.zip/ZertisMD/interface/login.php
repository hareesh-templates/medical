<?php
session_start();
include_once('../setup.php');

function login($login, $password) {
	$db = &dbconnect();
	$record = $db->GetRow("SELECT UserID, Login, Group_Id FROM Users WHERE Login='$login' AND Password=md5('$password')");

	if(!$record) {
		return "Invalid login or password";
	} else {
		$_SESSION["UserID"] = $record['UserID'];
		$_SESSION["Login"] = $record['Login'];
		$_SESSION['GroupID'] = $record['Group_Id'];
		MakeLog('Logged In', 'Logged In');
		return 0;
	}
	$db->Close();
}

$refer = sor(req('refer'), BASE_URL);
$error_msg = '';

if(req('Login')) {
	$error_msg = login($_POST['Login'], $_POST['Password']);
	if(!$error_msg)
		header("Location: $refer");
}

page_header('User Login');
?>

<br /><br />
<img src="<?=IMAGE_DIR?>small_logo.jpg" /><br />
<h1 align="center">Login</h1>
<form method="post" action="login.php">
<table align="center">
<tr>
	<td colspan="2"><div class="Error"><?=$error_msg?></div></td></tr>
<tr>
	<td align="right"><b>Login:</b> </td>
	<td><input type="text" name="Login" /></td></tr>
<tr>
	<td align="right"><b>Password:</b> </td>
	<td><input type="password" name="Password" /></td></tr>
<tr>
	<td></td>
	<td><br />
		<input name="buttonB" type="submit" name="btnLogin" value="Login" />
	</td></tr>
</table>
<input type="hidden" name="refer" value="<?=req('refer');?>" />
</form>

<?php
page_footer()
?>
