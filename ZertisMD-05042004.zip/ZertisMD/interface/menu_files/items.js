var MENU_ITEMS_XP = [
	[wrap_root('Menu Compatibility'), null, {'sw' : 110}, 
		[wrap_parent('Win32 platform'), null, null, 
			[wrap_child('Internet Explorer 4.0+', 'i.gif')],
			[wrap_child('Netscape 4.02+', 'n7.gif')],
			[wrap_child('Mozilla 0.9.5+', 'm12.gif')],
			[wrap_child('Opera 5.02+', 'o.gif')]
		],
		[wrap_parent('Macintosh platform'), null, null, 
			[wrap_child('Internet Explorer 5.0+', 'i.gif')],
			[wrap_child('Netscape 4.7+', 'n7.gif')]
		],
		[wrap_parent('Unsupported Browsers'), null, null,
			[wrap_child('Lynx')],
			[wrap_child('Hot Java')]
		],
		[wrap_child('Report test results', 'email.gif'), 'http://www.softcomplex.com/support.html']
	],
	[wrap_root('Demos', 'd'), null, {'bw' : 120}, 
		[wrap_parent('Functionality'), null, {'sb' : 'Functionality demos', 'bl' : 121},
			[wrap_child('Multiple'), '../multiple/index.html', {'tt' : 'multiple instances (vertical and horizontal menu bars, styles, rollovers)', 'sb' : 'Multiple demo'}],
			[wrap_child('Cross-framed'), '../frames/index.html', {'tt' : 'cross framed (horizontal menu bar, styles, relative positioning, rollovers)', 'sb' : 'Cross-framed demo'}],
			[wrap_child('Select-boxes'), '../selects/index.html', {'tt' : 'select-boxes overlapping (horizontal menu bar, styles, relative positioning, rollovers)', 'sb' : 'Select-boxes demo'}],
			[wrap_child('Effects'), '../effects/index.html', {'tt' : 'transitions (horizontal menu bars, styles, rollovers, inner html, transitions, transparency)', 'sb' : 'Effects demo'}]
		],
		[wrap_parent('Design'), null, {'sb' : 'Design demos', 'bl' : 121},
			[wrap_child('Icons &amp; arrows'), '../icons/index.html', {'tt' : 'strict blue design with icons and arrows (horizontal menu bar, styles, relative positioning, smart relocation, rollovers, inner html, tooltips, status bar messages)', 'sb' : 'Design demo'}],
			[wrap_child('Idea!'), '../idea/index.html', {'tt' : 'alternative design (horizontal menu bar, styles, relative positioning, smart relocation, graphic rollovers, inner html, transitions)', 'sb' : ' demo'}],
			[wrap_child('Hi there!'), '../hithere/index.html', {'tt' : 'yet another design (horizontal menu bar, styles, relative positioning, smart relocation, rollovers, animation, inner html, transitions)', 'sb' : 'Hi there! demo'}],
			[wrap_child('Matrix'), '../matrix/index.html', {'tt' : 'underground design (horizontal menu bar, styles, relative positioning, smart relocation, rollovers, animation, inner html, transitions)', 'sb' : 'Matrix demo'}],
			[wrap_child('MS Style'), '../msstyle/index.html', {'tt' : 'Microsoft<sup>&reg;</sup> site style menu (horizontal menu bar, styles, relative positioning, rollovers)', 'sb' : 'MS Style demo'}],
			[wrap_child('XP'), '../xp/index.html', {'tt' : 'XP style menu (horizontal menu bar, styles, relative positioning, rollovers, transitions)', 'sb' : 'XP demo'}],
			[wrap_child('Dots'), '../dots/index.html', {'tt' : 'Simple graphical menu (horizontal menu bar, graphical items, relative positioning, rollovers)', 'sb' : 'Dots demo'}],
			[wrap_child('3D-Buttons'), '../3dbuttons/index.html', {'tt' : 'Nice looking Arcanoid style 3D buttons (multiple instances, vertical and horizontal menu bars, graphical items, relative positioning, rollovers)', 'sb' : '3D-Buttons demo'}],
			[wrap_child('Tabs'), '../tabs/index.html', {'tt' : 'Double-decka menu of cool 3D tabs (multiple instances, wrappers, relative positioning, rollovers, semi-transparensy)', 'sb' : 'Tabs demo'}]
		]
	],
	[wrap_root('Contact'), null, {'bw' : 150},
			[wrap_child('E-mail', 'email.gif'), 'http://www.softcomplex.com/support.html'],
			[wrap_child('ICQ: 31599891', 'icq.gif'), null],
			[wrap_child('Y! ID: softcomplex', 'yahoo.gif'), null],
			[wrap_child('AIM ID: softcomplex', 'aol.gif'), null]
	]
]; 
var ii0 = new Image(); ii0.src = 'icons/arr.gif';
var ii1 = new Image(); ii1.src = 'icons/i.gif';
var ii2 = new Image(); ii2.src = 'icons/n7.gif';
var ii3 = new Image(); ii3.src = 'icons/m12.gif';
var ii4 = new Image(); ii4.src = 'icons/o.gif';
var ii5 = new Image(); ii5.src = 'icons/email.gif';
var ii6 = new Image(); ii6.src = 'icons/icq.gif';
var ii7 = new Image(); ii7.src = 'icons/yahoo.gif';
var ii8 = new Image(); ii8.src = 'icons/aol.gif';
var ii9 = new Image(); ii9.src = 'menu_files/pixel.gif';

function wrap_parent (text,icon) {
	return [['<table cellpadding=1 cellspacing=0 border=0 width=100%><tr><td bgcolor=#EFEDDE><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=16', ' hspace=3></td><td width=100%><table cellpadding=1 cellspacing=0 border=0 width=100% height=22><tr><td class=a0>&nbsp; ', text, '</td></tr></table></td><td><img src=icons/arr.gif width=4 height=7 align="middle" align=absmiddle hspace=3></td></tr></table>'].join(''),
	['<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=1 cellspacing=0 border=0 width=100% height=22 bgcolor=#CED1C3><tr><td><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=16', ' hspace=3></td><td width=100% class=a0>&nbsp; ', text, '</td><td><img src=icons/arr.gif width=4 height=7 align="middle" align=absmiddle hspace=3></td></tr></table></td></tr></table>'].join(''),
	['<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=1 cellspacing=0 border=0 width=100% height=22 bgcolor=#CED1C3><tr><td><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=16', ' hspace=3></td><td width=100% class=a0>&nbsp; ', text, '</td><td><img src=icons/arr.gif width=4 height=7 align="middle" align=absmiddle hspace=3></td></tr></table></td></tr></table>'].join('')
	];
}

function wrap_child (text,icon) {
	return [['<table cellpadding=1 cellspacing=0 border=0 width=100%><tr><td bgcolor=#EFEDDE><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=15', ' hspace=3></td><td width=100%><table cellpadding=1 cellspacing=0 border=0 width=100% height=22><tr><td class=a0>&nbsp; ', text, '</td></tr></table></td></tr></table>'].join(''),
	['<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=1 cellspacing=0 border=0 width=100% height=22 bgcolor=#CED1C3><tr><td><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=16', ' hspace=3></td><td width=99% class=a0>&nbsp; ', text, '</td></tr></table></td></tr></table>'].join(''),
	['<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=1 cellspacing=0 border=0 width=100% height=22 bgcolor=#CED1C3><tr><td><img height=16 src=', icon !=null ? 'icons/' + icon: 'menu_files/pixel.gif width=16', ' hspace=3></td><td width=99% class=a0>&nbsp; ', text, '</td></tr></table></td></tr></table>'].join('')
	];
}

function wrap_root (text) {
	return [
	'<table cellpadding=1 cellspacing=0 border=0 width=100%><tr><td><table cellpadding=0 cellspacing=0 border=0 width=100% height=21><tr><td width=100% class=a0 align="center">&nbsp; ' + text + ' &nbsp;</td></tr></table></td></tr></table>',
	'<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=0 cellspacing=0 border=0 width=100% height=21><tr><td width=100% class=a1 align="center">&nbsp; ' + text + ' &nbsp;</td></tr></table></td></tr></table>',
	'<table cellpadding=1 cellspacing=0 border=0 width=100% bgcolor=#93A070><tr><td><table cellpadding=0 cellspacing=0 border=0 width=100% height=21><tr><td width=100% class=a1 align="center">&nbsp; ' + text + ' &nbsp;</td></tr></table></td></tr></table>'
	];
}