<?
session_start();
require('../setup.php');
RequireLogin();
require_once(SOURCES_DIR . 'left_menu/generator.php');


$menu = MAKE_LEFT($_SESSION[UserID], $_SESSION[GroupID]);

$cross	= JMENU . 'crossbrowser.js';
$out	= JMENU . 'outlook.js';

$MENU_CALL = MENU_CALL;


$smarty = GetSmarty();
$smarty->assign('CROSSBROWSER', $cross);
$smarty->assign('CSS', css());
$smarty->assign('OUTLOOK', $out);
$smarty->assign('MENU', $menu);
$smarty->display('left_menu.tpl');


?>