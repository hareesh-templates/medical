<?php
// Redfine these depending on where the application is installed
define('BASE_URL', '/~jlee/ZertisMD/');
define('BASE_DIR', '/home/jlee/public_html/ZertisMD');

// Database Variables
define('DB_TYPE', 'mysql');
define('DB_USER', 'XXX');
define('DB_PASSWD', i'XXX');
define('DB_DB', 'lee_zertis_system');
define('DB_SERVER', 'localhost');
$REPDIR="/home/jlee/public_html/ZertisMD/files";
?>
