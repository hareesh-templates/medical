<?php
session_start();
require 'setup.php';
RequireLogin();

$smarty = GetSmarty();
$smarty->display('index.tpl');
?>