SELECT A.Name FROM
 Groups A,
 Module_Perms T

 WHERE T.ModuleID='4' AND T.Type='GROUP'


 SELECT
 Users.UserID, Login,
 Module_Perms.PermID

 FROM Users LEFT JOIN Module_Perms ON

 (Users.UserID = Module_Perms.ID AND Module_Perms.ModuleID ='1' AND Module_Perms.Type='GROUP')



// Groups allowed or denied, use For both, if allow_deny = 1 or 0
SELECT Groups.GroupID, Name, Module_Perms.PermID, Allow_Deny
FROM Groups
LEFT JOIN Module_Perms ON (
Groups.GroupID = Module_Perms.ID
AND Module_Perms.ModuleID = '1'
AND Module_Perms.Type = 'GROUP'
)
WHERE Module_Perms.PermID IS NOT NULL

// Other Groups
SELECT Groups.GroupID, Name, Module_Perms.PermID, Allow_Deny
FROM Groups
LEFT JOIN Module_Perms ON (
Groups.GroupID = Module_Perms.ID
AND Module_Perms.ModuleID = '1'
AND Module_Perms.Type = 'GROUP'
)
WHERE Module_Perms.PermID IS NULL



// Users allowed or denied, use For both, if allow_deny = 1 or 0
SELECT Users.UserID, Login, Module_Perms.PermID, Allow_Deny, Type
FROM Users
LEFT JOIN Module_Perms ON (
Users.UserID = Module_Perms.ID
AND Module_Perms.ModuleID = '2'
AND Module_Perms.Type = 'USER'
)
WHERE Module_Perms.PermID IS NOT NULL


// Other Users
SELECT Users.UserID, Login, Module_Perms.PermID, Allow_Deny, Type
FROM Users
LEFT JOIN Module_Perms ON (
Users.UserID = Module_Perms.ID
AND Module_Perms.ModuleID = '2'
AND Module_Perms.Type = 'USER'
)
WHERE Module_Perms.PermID IS NULL

1 port rs232 serial extender to 3300 feet  399

