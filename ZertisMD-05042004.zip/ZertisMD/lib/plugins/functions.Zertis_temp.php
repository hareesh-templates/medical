<?
# MISC FUNCTIONS FILE

//-------------------------------------------------------------------------------------------------------
// PAGER FUNCTION
function zertis_pager( $data_field, &$_REQUEST ) {
	include_once('adodb/adodb-pager.inc.php');
	require_once(LIB_DIR . '/classes/SmartPager.class.php');

	$db =& dbconnect();
	$pager = new SmartPager($db, $data_field, &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';
	$pager->trim = true;
	$pager->trim_length = '30';
	echo $pager->Render();
	$db->Disconnect();

}
	
function state_list($sel='') {
	  $s = '';
	  $s = $s . "<option value='AL'".($sel=='AL'?'
	selected':'').">Alabama</option>\n";
	  $s = $s . "<option value='AK'".($sel=='AK'?'
	selected':'').">Alaska</option>\n";
	  $s = $s . "<option value='AS'".($sel=='AS'?' selected':'').">American
	Samoa</option>\n";
	  $s = $s . "<option value='AZ'".($sel=='AZ'?'
	selected':'').">Arizona</option>\n";
	  $s = $s . "<option value='AR'".($sel=='AR'?'
	selected':'').">Arkansas</option>\n";
	  $s = $s . "<option value='CA'".($sel=='CA'?'
	selected':'').">California</option>\n";
	  $s = $s . "<option value='CO'".($sel=='CO'?'
	selected':'').">Colorado</option>\n";
	  $s = $s . "<option value='CT'".($sel=='CT'?'
	selected':'').">Connecticut</option>\n";
	  $s = $s . "<option value='DE'".($sel=='DE'?'
	selected':'').">Delaware</option>\n";
	  $s = $s . "<option value='DC'".($sel=='DC'?' selected':'').">District
	of Columbia</option>\n";
	  $s = $s . "<option value='FM'".($sel=='FM'?' selected':'').">Federated
	States of Micronesia</option>\n";
	  $s = $s . "<option value='FL'".($sel=='FL'?'
	selected':'').">Florida</option>\n";
	  $s = $s . "<option value='GA'".($sel=='GA'?'
	selected':'').">Georgia</option>\n";
	  $s = $s . "<option value='GU'".($sel=='GU'?'
	selected':'').">Guam</option>\n";
	  $s = $s . "<option value='HI'".($sel=='HI'?'
	selected':'').">Hawaii</option>\n";
	  $s = $s . "<option value='ID'".($sel=='ID'?'
	selected':'').">Idaho</option>\n";
	  $s = $s . "<option value='IL'".($sel=='IL'?'
	selected':'').">Illinois</option>\n";
	  $s = $s . "<option value='IN'".($sel=='IN'?'
	selected':'').">Indiana</option>\n";
	  $s = $s . "<option value='IA'".($sel=='IA'?'
	selected':'').">Iowa</option>\n";
	  $s = $s . "<option value='KS'".($sel=='KS'?'
	selected':'').">Kansas</option>\n";
	  $s = $s . "<option value='KY'".($sel=='KY'?'
	selected':'').">Kentucky</option>\n";
	  $s = $s . "<option value='LA'".($sel=='LA'?'
	selected':'').">Louisiana</option>\n";
	  $s = $s . "<option value='ME'".($sel=='ME'?'
	selected':'').">Maine</option>\n";
	  $s = $s . "<option value='MH'".($sel=='MH'?' selected':'').">Marshall
	Islands</option>\n";
	  $s = $s . "<option value='MD'".($sel=='MD'?'
	selected':'').">Maryland</option>\n";
	  $s = $s . "<option value='MA'".($sel=='MA'?'
	selected':'').">Massachusetts</option>\n";
	  $s = $s . "<option value='MI'".($sel=='MI'?'
	selected':'').">Michigan</option>\n";
	  $s = $s . "<option value='MN'".($sel=='MN'?'
	selected':'').">Minnesota</option>\n";
	  $s = $s . "<option value='MS'".($sel=='MS'?'
	selected':'').">Mississippi</option>\n";
	  $s = $s . "<option value='MO'".($sel=='MO'?'
	selected':'').">Missouri</option>\n";
	  $s = $s . "<option value='MT'".($sel=='MT'?'
	selected':'').">Montana</option>\n";
	  $s = $s . "<option value='NE'".($sel=='NE'?'
	selected':'').">Nebraska</option>\n";
	  $s = $s . "<option value='NV'".($sel=='NV'?'
	selected':'').">Nevada</option>\n";
	  $s = $s . "<option value='NH'".($sel=='NH'?' selected':'').">New
	Hampshire</option>\n";
	  $s = $s . "<option value='NJ'".($sel=='NJ'?' selected':'').">New
	Jersey</option>\n";
	  $s = $s . "<option value='NM'".($sel=='NM'?' selected':'').">New
	Mexico</option>\n";
	  $s = $s . "<option value='NY'".($sel=='NY'?' selected':'').">New
	York</option>\n";
	  $s = $s . "<option value='NC'".($sel=='NC'?' selected':'').">North
	Carolina</option>\n";
	  $s = $s . "<option value='ND'".($sel=='ND'?' selected':'').">North
	Dakota</option>\n";
	  $s = $s . "<option value='MP'".($sel=='MP'?' selected':'').">Northern
	Mariana Islands</option>\n";
	  $s = $s . "<option value='OH'".($sel=='OH'?'
	selected':'').">Ohio</option>\n";
	  $s = $s . "<option value='OK'".($sel=='OK'?'
	selected':'').">Oklahoma</option>\n";
	  $s = $s . "<option value='OR'".($sel=='OR'?'
	selected':'').">Oregon</option>\n";
	  $s = $s . "<option value='PW'".($sel=='PW'?'
	selected':'').">Palau</option>\n";
	  $s = $s . "<option value='PA'".($sel=='PA'?'
	selected':'').">Pennsylvania</option>\n";
	  $s = $s . "<option value='PR'".($sel=='PR'?' selected':'').">Puerto
	Rico</option>\n";
	  $s = $s . "<option value='RI'".($sel=='RI'?' selected':'').">Rhode
	Island</option>\n";
	  $s = $s . "<option value='SC'".($sel=='SC'?' selected':'').">South
	Carolina</option>\n";
	  $s = $s . "<option value='SD'".($sel=='SD'?' selected':'').">South
	Dakota</option>\n";
	  $s = $s . "<option value='TN'".($sel=='TN'?'
	selected':'').">Tennessee</option>\n";
	  $s = $s . "<option value='TX'".($sel=='TX'?'
	selected':'').">Texas</option>\n";
	  $s = $s . "<option value='UT'".($sel=='UT'?'
	selected':'').">Utah</option>\n";
	  $s = $s . "<option value='VT'".($sel=='VT'?'
	selected':'').">Vermont</option>\n";
	  $s = $s . "<option value='VI'".($sel=='VI'?' selected':'').">Virgin
	Islands</option>\n";
	  $s = $s . "<option value='VA'".($sel=='VA'?'
	selected':'').">Virginia</option>\n";
	  $s = $s . "<option value='WA'".($sel=='WA'?'
	selected':'').">Washington</option>\n";
	  $s = $s . "<option value='WV'".($sel=='WV'?' selected':'').">West
	Virginia</option>\n";
	  $s = $s . "<option value='WI'".($sel=='WI'?'
	selected':'').">Wisconsin</option>\n";
	  $s = $s . "<option value='WY'".($sel=='WY'?'
	selected':'').">Wyoming</option>\n";
	  return $s;
	}
?>