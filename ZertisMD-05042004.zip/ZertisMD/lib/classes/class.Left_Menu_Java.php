<?

require_once ('class.panel.generator.php');

class Left_Menu_Java extends Left_MenuGenerator {
var $user_id = 0;
var $Group_id = 0;

function Top_Java() {
$IMAGE = IMAGE_DIR . 'new.png';
return <<< EOOOF

<STYLE TYPE="text/css">

.button {width:300px; margin-top:0px; padding:4px 2px 0px 2px; align:center; text-align:center; font-family:arial;
 font-size:10pt; color:silver; font-weight: bold; cursor:hand; border-width:1;
 border-style:outset; position: absolute; top:-100px; left: -100px; border-color:silver;
 background-image: url($IMAGE); }
</style>

<STYLE>
  div    {
         position:absolute;
         }
</STYLE>


	<script type="text/javascript" language="JavaScript">
	// ---------------------------------------------------------------------------
	// Example of howto: use Outlook Like Bar
	// ---------------------------------------------------------------------------


	  //create OutlookBar-Object:
	  //              Name
	  //              x-position
	  //              y-Position
	  //              width
	  //              height
	  //              background-color
	  //              page background-color (needed for OP5)
	  //(screenSize object is created by 'crossbrowser.js')
	  //

	  var o = new createOutlookBar('Bar',0,0,screenSize.width,screenSize.height,'#FFFFFF','#FFFFFF') // OutlookBar
	  var p

	  function go_there(\$location) {
		parent.Main2.location=\$location;
	  }
	  //Dynamicly Create the Panels

EOOOF;

}

function Bottom_Java() {
		return <<< EOOOF
		  o.draw();         //draw the Outlook Like Bar!


		//-----------------------------------------------------------------------------
		//functions to manage window resize
		//-----------------------------------------------------------------------------
		//resize OP5 (test screenSize every 100ms)

		function resize_op5() {
		  if (bt.op5) {
			o.showPanel(o.aktPanel);
			var s = new createPageSize();
			if ((screenSize.width!=s.width) || (screenSize.height!=s.height)) {
			  screenSize=new createPageSize();
			  //need setTimeout or resize on window-maximize will not work correct!
			  //ben�tige das setTimeout oder das Maximieren funktioniert nicht richtig
			  setTimeout("o.resize(0,0,screenSize.width,screenSize.height)",100);
			}
			setTimeout("resize_op5()",100);
		  }
		}

		//resize IE & NS (onResize event!)
		function myOnResize() {
		  if (bt.ie4 || bt.ie5 || bt.ns5) {
			var s=new createPageSize();
			o.resize(0,0,s.width,s.height);
		  }
		  else
			if (bt.ns4) location.reload();
		}

		</script>
EOOOF;
}



	////////////////////////////////////////////////////
	function get_panels () {
	$get_that_panels = $this->get_Menu_Array();
		$Middle_Java_Script = '';
		// weird but first input to menu javascript must be a string,
		// non interger that is different every time if they are not
		//  different, then the scrolling feature doesn't work.
		$i = 'a';
		foreach($get_that_panels as $get_that_panel) {
			$panel = new Panel_Generator();
			$Middle_Java_Script .= $panel->Create_Panel($get_that_panel, $i) . "\n";
			$i .= $i;
		}
	return $Middle_Java_Script;
	}
	////////////////////////////////////////////////////
	function Build_Menu () {
	$Top = $this->Top_Java();
	$Middle = $this->get_panels();
	$Bottom = $this->Bottom_Java();

	$Total_Java = $Top . "\n" . $Middle . "\n" . $Bottom;

	return $Total_Java;
	}



}

?>