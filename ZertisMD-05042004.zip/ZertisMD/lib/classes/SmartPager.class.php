<?php
class SmartPager extends ADODB_Pager {

	var $first = '<< BEGINING';
	var $last = 'END >>';
	var $next = 'Next >';
	var $prev = '< Previous';
	var $asc_icon = 'v';
	var $desc_icon = '^';
	var $table_def = 0;
	var $data_bag = array();
	var $trim = false;
	var $trim_length = '24';

	function trim_key ($key) {
		if($this->trim == false)
			return $key;
		$str_length = strlen($key);
		if($this->trim_length > $str_length + 1)
			return $key;
		$new_key = substr($key, 0, $this->trim_length);
		return $new_key . '...';
	}

	function SmartPager(&$db,$table_def, $data_bag, $id = 'adodb', $showPageLinks = false) {
		if(!@$table_def['default_sort'])
			$table_def['default_sort'] = array('','ASC');
		$this->table_def = $table_def;
		$this->data_bag = $data_bag;

		if(!@$this->data_bag['_sort']) {
			$this->data_bag['_sort'] = $table_def['default_sort'][0];
			$this->data_bag['_sort_order'] = $table_def['default_sort'][1];
		}

		$this->sort_field = $this->data_bag['_sort'];
		$this->sort_order = $this->data_bag['_sort_order'];

		$sort = $this->data_bag['_sort'] . ' ' . $this->data_bag['_sort_order'];
		if($this->sort_field != $this->table_def['default_sort'][0]) {
			$sort .= ', ' . $table_def['default_sort'][0] . ' ' . $table_def['default_sort'][1];
		}

		$this->rows = @$this->data_bag['_row_elem_count'] or 30;
		$this->data_bag['_row_elem_count'] = $this->rows;

		ADODB_Pager::ADODB_Pager(&$db, $table_def['sql'] . " ORDER BY $sort", $id, $showPageLinks);
	}

	function ExtraQS() {
		$ardata = array(
			'_sort' 		  => $this->sort_field,
			'_sort_order'     => $this->sort_order,
			'_row_elem_count' => $this->rows
		);
		foreach($this->table_def['sql_vars'] as $var)
			$ardata[$var] = $this->data_bag[$var];
		
		$s = '';
		foreach($ardata as $key => $value) {
				$s .= urlencode($key) . '=' . urlencode($value) . '&';
		}
		return $s;
	}

	function RenderPostHeader($footer, $extra='') {
		echo "<table width='100%'><tr><td width='33%'>&nbsp;</td><td width='33%' align='center'>\n" .
			$footer .
			"</td><td width='33%' align='right'><form style='margin:0px' method='get' action='?" . $_SERVER['QUERY_STRING'] .
			"' name='_nump_links_form'>\n" . $this->nump_links() .
			"</form></td></tr></table>\n";
	}

	function RenderPostFooter($header, $extra='') {
		echo $header;
	}

	function RenderLayout($header, $grid, $footer, 
	                      $attributes="border='0' width='98%' cellspacing='0' cellpadding='2' align='center'", 
	                      $extraheader='', $extrafooter='')	{
		$qs = $_SERVER['QUERY_STRING'];
		$nqs = '';
		foreach($_GET as $key => $value) {
			if($key != '_row_elem_count')
				$nqs .= "$key=$value&";
		}
		echo <<<EOF
		<script language="JavaScript">
		function _nump_link_change_select(elem) {
			document.location = '?' + '$nqs' + '&_row_elem_count=' +
				document.forms['_nump_links_form'].elements['_row_elem_count'].options[document.forms['_nump_links_form'].elements['_row_elem_count'].selectedIndex].value;
		}
		</script>

EOF;
		echo "<table $attributes><tr><td align='center'>",
				$header,
			 "</td></tr><tr><td align='center'>\n",
				$this->RenderPostHeader($footer, $extraheader),
			"</td></tr><tr><td align='center'>\n",
				$grid,
			"</td></tr><tr><td align='center'>\n",
				"<table width='100%'><tr><td width='33%'>&nbsp;</td><td width='33%' align='center'>\n",
				$footer,
			"</td><td width='33%' align='right'></td></tr></table>\n",
			"</td></tr><tr><td align='center'>\n",
				$this->RenderPostFooter($header, $extrafooter),
			"</td></tr></table>\n";
	}

	function nump_links() {
		/* Generates dropdown box for selecting how many elements to display per page */
		$s = "<select name='_row_elem_count' onchange='_nump_link_change_select(this)'>\n";
		for($i = 5; $i <= 100; $i+=5) {
			$s .= "<option " . ($i == $this->data_bag['_row_elem_count'] ? 'selected="selected"' : '') .
					">$i</option>\n";
		}
		$s .= "</select>\n";
		return $s;
	}

	//---------------------------------------------------

	function RenderGrid() {
		// What in the hell was I smoking when I wrote this? 
		$rs = $this->rs;
		$s = "<tr class='Menu_Head'>";

		if(array_key_exists('pre_links', $this->table_def)) {
		 $s .= '<td nowrap="nowrap" width="80" align="center">&nbsp; OPTIONS </td>';
		}

		$ar = $this->table_def['fields'];
		foreach($ar as $key => $value) {
			$s .= 	"<td align='left' valign='middle' nowrap='nowrap'>&nbsp; " .
					($value == $this->sort_field ? ($this->sort_order == 'DESC' ? $this->desc_icon : $this->asc_icon) : "") .
					"<a href='?";
			$has_sort = 0;
			$df = 0;
			if($value == $this->sort_field) {
				foreach($_GET as $get => $gval) {
					if($get == "_sort_order") {
						$s .= ($gval == 'DESC' ? 'ASC' : 'DESC') . "&";
						$has_sort = 1;
					} else {
						$s .= "$get=$gval&";
					}
				}
				$df = 1;
			} else {
				foreach($_GET as $get => $gval) {
					if($get == "_sort") {
						$s .= "_sort=$value&";
						$has_sort = 1;
					} elseif($get == "_sort_order") {
						$s .= "_sort_order=DESC&";
					} else {
						$s .= "$get=$gval&";
					}
				}
			}
			if(!$has_sort)
				$s .= "_sort=$value&_sort_order=DESC";

			$s .= "' " . ($df ? " class='CurrentSort'>" : " class='TopLinks'>") .
				" $key</a></td>";
		}
		$s .= "</tr>";

		$x = 0;
		while(!$rs->EOF) {
			$c = $x++ % 2;

			// print out the row
			$s .= "\n<tr class='Row$c'>\n";
			$fields = ($this->table_def['fields'] ? array_values($this->table_def['fields']) : array_keys($rs->fields));

			if(array_key_exists('pre_links', $this->table_def)) {
				$count = count($this->table_def['pre_links']);
			  $s .= '<td nowrap="nowrap" align="center">&nbsp; ';
				for($i=0; $i<$count;) {
					$pre_links = $this->table_def['pre_links'][$i];

			 		$s .= ' <a href="' . $pre_links['Target'] . (strstr($pre_links['Target'], "?") ? "&" : "?") . $pre_links['QSVar'] . '=' . $rs->fields[$pre_links['QSVal']] . '" title="' . $pre_links['Title'] . '" style="text-decoration: none;">';
			 		$s .= '<img src="' . $pre_links['Image'] . '" border="0" alt="' . $pre_links['Title'] . ' " />';
			 		$s .= '</a> ';

			 		$i++;
			 	}
			  $s .= '</td>';
			}

			foreach($fields as $key) {
				$s .= "<td class=\"divider\" nowrap=\"nowrap\" title=\"" . $rs->fields[$key] . "\">&nbsp; ";


				if(array_key_exists('table_links', $this->table_def)) {
					if(array_key_exists($key, $this->table_def['table_links'])) {
				       $fld = $this->table_def['table_links'][$key];

						if(array_key_exists('Image', $fld)) {
							$s .= '<img src="' . $fld['Image'] . '" border="0" alt="' . $fld['Title'] . ' " /> ';
						}

						$s .= ' <a href="' . $fld['Target'] . (strstr($fld['Target'], "?") ? "&" : "?") . $fld['QSVar'] . '=' . $rs->fields[$fld['QSVal']] . '" title="' . $fld['Title'] . '"';
						if(array_key_exists('Window', $fld)) {
							$s .= ' target="' . $fld['Window'];
							$s .= '"';
						}

						$s .= '>';
						$temp = $this->trim_key($rs->fields[$key]);
						$s .= $temp;
						$s .= '</a>' ;


						} else {
							$temp = $this->trim_key($rs->fields[$key]);
							$s .= $temp;
						}

				} else {
				  $temp = $this->trim_key($rs->fields[$key]);
				  $s .= $temp;
								}
				$s .= "</td>";
			}
			$s .= "</tr>";
			$rs->MoveNext();
		}
		return "\n<table class='smarty_table' cellspacing='0'  width='100%'>\n$s\n</table>\n";
	}

	function Render($rows=30) {
		global $ADODB_COUNTRECS;
		if($this->table_def['sql_vars']) {
			$ardata = array();
			foreach($this->table_def['sql_vars'] as $var) {
				if(@$this->data_bag[$var])
					$ardata[] = $this->data_bag[$var];
			}
			$this->sql = vsprintf($this->sql, $ardata);
		}
		ADODB_Pager::Render($this->rows);
	}

	//---------------------------------------------------
	// original code by "Pablo Costa" <pablo@cbsp.com.br>
	function render_pagelinks()
	{
		global $PHP_SELF;
		$pages        = $this->rs->LastPageNo();
		$linksperpage = $this->linksPerPage ? $this->linksPerPage : $pages;
		for($i=1; $i <= $pages; $i+=$linksperpage)
		{
			if($this->rs->AbsolutePage() >= $i)
			{
				$start = $i;
			}
		}
		$numbers = '';
		$end = $start+$linksperpage-1;
		$link = $this->id . "_next_page";
		if($end > $pages) $end = $pages;


		if ($this->startLinks && $start > 1) {
			$pos = $start - 1;
			$numbers .= "<a href=$PHP_SELF?$link=$pos>$this->startLinks</a>  ";
		}

		for($i=$start; $i <= $end; $i++) {
			if ($this->rs->AbsolutePage() == $i)
				$numbers .= "<font color=$this->linkSelectedColor><b>$i</b></font>  ";
			else
				 $numbers .= "<a href=$PHP_SELF?$link=$i>$i</a>  ";

		}
		if ($this->moreLinks && $end < $pages)
			$numbers .= "<a href=$PHP_SELF?$link=$i>$this->moreLinks</a>  ";
		print $numbers . ' &nbsp; ';
	}


	//---------------------------------------------------
	// Display link to first page
	function Render_First($anchor=true)	{
		global $PHP_SELF;
		if($anchor) {
			echo "<a href='$PHP_SELF?$this->id" . "_next_page=1&" . $this->ExtraQS() . "'>$this->first</a>";
		} else {
			echo "$this->first &nbsp; ";
		}
	}

	//---------------------------------------------------
	// Link to previous page
	function render_prev($anchor=true)
	{
	global $PHP_SELF;
		if ($anchor) {
	?>
		<a href="<?php echo $PHP_SELF,'?',$this->id,'_next_page=',$this->rs->AbsolutePage() - 1,'&',$this->ExtraQS()?>"><?php echo $this->prev;?></a> &nbsp;
	<?php
		} else {
			print "$this->prev &nbsp; ";
		}
	}

	//--------------------------
	// Display link to next page
	function render_next($anchor=true)
	{
	global $PHP_SELF;

		if ($anchor) {
		?>
		<a href="<?php echo $PHP_SELF,'?',$this->id,'_next_page=',$this->rs->AbsolutePage() + 1,'&',$this->ExtraQS()?>"><?php echo $this->next;?></a> &nbsp;
		<?php
		} else {
			print "$this->next &nbsp; ";
		}
	}

	//------------------
	// Link to last page
	//
	// for better performance with large recordsets, you can set
	// $this->db->pageExecuteCountRows = false, which disables
	// last page counting.
	function render_last($anchor=true)
	{
	global $PHP_SELF;

		if (!$this->db->pageExecuteCountRows) return;

		if ($anchor) {
		?>
			<a href="<?php echo $PHP_SELF,'?',$this->id,'_next_page=',$this->rs->LastPageNo(),'&',$this->ExtraQS()?>"><?php echo $this->last;?></a> &nbsp;
		<?php
		} else {
			print "$this->last &nbsp; ";
		}
	}
}
?>
