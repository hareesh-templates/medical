<?
require_once ('../setup.php');
require_once ('class.panel.generator.php');

class Left_MenuGenerator {
var $user_id = 0;
var $Group_id = 0;
	// Access Level Checking functions

	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	//function list module names
	function Module_Names() {

		$db = &dbconnect();
		$record = $db->GetAll("SELECT * FROM Module_Info");
		$db->Close();
		return $record;
	}


	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	//function check to see if user has access to modules by name
	function Access_Check_This($Module) {
		$trigger = '0';
		$db = &dbconnect();
		$record = $db->GetRow("SELECT ModuleID FROM Module_Info WHERE Module='$Module'");
		$ModuleID = $record[ModuleID];


		// Is Individual Allowed or Denied?
		$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$user_id' AND Type='USER' AND ModuleID='$ModuleID'";
		$record = $db->GetRow("$sql");
		if($record[Allow_Deny] == '1') {
			$user = 1;
		}
		elseif($record[Allow_Deny] == '0') {
			$user = 0;
		}
		// Is Individual a member of a group allowed?  ( checking in UserGroups )

		$record = $db->GetAll("SELECT GroupID FROM UserGroups WHERE UserID='$user_id'");
		$count = count($record);
			for($i=0;$i<$count;) {
			$temp = $record[$i][GroupID];
				$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$temp' AND Type='GROUP' AND ModuleID='$ModuleID'";
				$new_record = $db->GetRow("$sql");
					if($new_record[Allow_Deny] == '1') {
						$trigger = 1;
					}
			$i++;
			}


		// Is Individual a member of a group allowed? ( checking in the individual users properties, their "primary" group

		$sql = "SELECT Allow_Deny FROM Module_Perms WHERE ID='$Group_id' AND Type='GROUP' AND ModuleID='$ModuleID'";
		$personal = $db->GetRow($sql);
		if($personal[Allow_Deny] == '1') {
			$trigger = 1;
		}

		$db->Close();
		if($user == '0') {
			return '0';
		} elseif ($user == '1') {
			return "$Module";
		}
		if($trigger == '0') {
			return '0';
		} elseif ($trigger == '1') {
			return "$Module";
		}
		return '0';
	}

	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	// Function that checks if a user has access
	// to a specific module
	function  Access_Check($Module) {
	 if(Access_Check_This($Module) == $Module) {
		return 1;
	 } else {
		echo '<pre>';
		print_r($_SESSION);
		echo '</pre>';
		print 'ERROR: You do not have access to this module.';
		die();
	 }

	}
	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	// function list all modules that user has access to
	function Module_Access_List () {

	 $records = Module_Names();
	 $count = count($records);

	 for($i=0;$i<$count;$i++) {
		if(Access_Check_This($records[$i][Module]) == $records[$i][Module]) {
		$list_names[]	= $records[$i][Module];
		$list_id[]		= $records[$i][ModuleID];

		$list_top[]		= $records[$i][top_menu];
		$list_link[]	= $records[$i][link];

		$list_side[]	= $records[$i][side_menu];
		$list_menus[]	= $records[$i][side_menu_item];

		$list_image[]	= IMAGE_DIR . $records[$i][image];
		}

	  }
	  $db = &dbconnect();
	  $count = count($list_id);
	  for($i=0;$i<$count;$i++) {
		$record = $db->GetRow("SELECT link FROM Module_Info WHERE ModuleID='$list_id[$i]'");
		$list_link[] = $record[link];
	  }
	  $db->Close();
	  $list = array(
		"list_names" => $list_names,
		"list_id" => $list_id,

		"list_top" => $list_top,
		"list_link" => $list_link,

		"list_side" => $list_side,
		"list_menus" => $list_menus,

		"list_image" => $list_image
		);
	return $list;
	}

	////////////////////////////////////////////////////
	////////////////////////////////////////////////////
	// function that creates the proper link to a module
	// by module name from Module_Info Table
	function Module_Link ($Module) {
	  $db = &dbconnect();

		$record = $db->GetRow("SELECT link FROM Module_Info WHERE Module='$Module'");
		if($record[link] == '') {
		 $link = '';
		} else {
		 $link = $record[link];
		}
	  return $link;
	  $db->Close();
	}
	////////////////////////////////////////////////////
	function BuildMenuArray ($panel, $names, $urls, $image, $target) {
		$Menus = array(array(
					"panel_name"	=> $panel,
					"link_names" 	=> $names,
					"link_urls" 	=> $urls,
					"image"			=> $image,
					"target" 		=> $target
					)
				);
	return $Menus;
	}

	////////////////////////////////////////////////////
	function get_Menu_Array() {
	// find authority of modules
		$list = $this->Module_Access_List();

		// Generate default Links
		$panel  = "Main";

		$name	= array("Home");
		$urls	= array("main.php?");
		$image	= array(IMAGE_DIR . "home.png");
		$target	= array("Main");


		$Menus = $this->BuildMenuArray($panel, $name, $urls, $image, $target);

	// Grab Left Menu Panels From DB
	  $db = &dbconnect();
	  $records = $db->GetAll("SELECT MenuID, menu_name FROM Left_Menus");
		if(!$records)
			die($db->ErrorMsg());
	  foreach($records as $record) {
				$panel  = '';
				$name	= '';
				$urls	= '';
				$image	= '';
				$target	= '';
			$MenuID = $record[MenuID];
			$menu_name = $record[menu_name];
			$panel = $menu_name;
			$count = count($list[list_names]);
				for($i=0;$i<$count;$i++) {
					if($list[list_menus][$i] == $MenuID && $list[list_side][$i] == '1') {
						// Generate Modules Links
						$name[]		= $list[list_names][$i];
						$urls[]		= $list[list_link][$i];
						$image[]	= $list[list_image][$i];
						$target[]	= "Main2";
					}
				}
		if($name != '') {
			$New_Menus = $this->BuildMenuArray($panel, $name, $urls, $image, $target);
			$Menus = array_merge($Menus, $New_Menus);
		}
	  }

	  $db->Close();

	return $Menus;
	}


}

?>
