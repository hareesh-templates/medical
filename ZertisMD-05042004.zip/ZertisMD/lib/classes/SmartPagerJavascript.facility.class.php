<?

///////////////////////////////////////////////////
// For users.php ONLY confirms delete of User by ID
class SmartPagerJavascript extends SmartPager {


	function RenderGrid()
	{

		$rs = $this->rs;
		$s = "<tr class='Menu_Head'>";

		if(array_key_exists('pre_links', $this->table_def)) {
		 $s .= '<td nowrap="nowrap">&nbsp; OPTIONS </td>';
		}

		$ar = (C ? $this->table_def['fields'] : $rs->fields);
		foreach($ar as $key => $value) {
				$s .= 	"<td align='left' nowrap='nowrap' valign='middle'>&nbsp; " .
						($value == $this->sort_field ? ($this->sort_order == 'DESC' ? $this->desc_icon : $this->asc_icon) : "") .
						"<a href='?";
				$has_sort = 0;
				$df = 0;
				if($value == $this->sort_field) {
					foreach($_GET as $get => $gval) {
						if($get == "_sort_order") {
							$s .= ($gval == 'DESC' ? 'ASC' : 'DESC') . "&";
							$has_sort = 1;
						} else {
							$s .= "$get=$gval&";
						}
					}
					$df = 1;
				} else {
					foreach($_GET as $get => $gval) {
						if($get == "_sort") {
							$s .= "_sort=$value&";
							$has_sort = 1;
						} elseif($get == "_sort_order") {
							$s .= "_sort_order=DESC&";
						} else {
							$s .= "$get=$gval&";
						}
					}
				}
				if(!$has_sort)
					$s .= "_sort=$value&_sort_order=DESC";

				$s .= "' " . ($df ? " class='CurrentSort'>" : " class='TopLinks'>") .
					" $key</a></td>";
		}
		$s .= "</tr>";

		$x = 0;
		while(!$rs->EOF) {
			$c = $x++ % 2;

			// print out the row
			$s .= "\n<tr class='Row$c'>\n";
			$fields = ($this->table_def['fields'] ? array_values($this->table_def['fields']) : array_keys($rs->fields));


			if(array_key_exists('pre_links', $this->table_def)) {
				$count = count($this->table_def['pre_links']);
			  $s .= '<td nowrap="nowrap" align="center">&nbsp; ';
				for($i=0; $i<$count;) {
					$pre_links = $this->table_def['pre_links'][$i];

			 		$s .= ' <a href="' . $pre_links['Target'] . (strstr($pre_links['Target'], "?") ? "&" : "?") . $pre_links['QSVar'] . '=' . $rs->fields[$pre_links['QSVal']] . '" title="' . $pre_links['Title'] . '" style="text-decoration: none;">';
			 		$s .= '<img src="' . $pre_links['Image'] . '" border="0" alt="' . $pre_links['Title'] . ' " />';
			 		$s .= '</a> ';

			 		$i++;
			 	}
			  $s .= '<a href="javascript:confirm_facility_delete(' . $rs->fields[id] . ')" title="Delete Facility"><img src="' . IMAGE_DIR . '/button_drop.png" border="0"></a>';
			  $s .= '</td>';
			}


			foreach($fields as $key) {
				$s .= "<td class='divider' nowrap='nowrap'>&nbsp; ";
				if(array_key_exists('table_links', $this->table_def)) {
					if(array_key_exists($key, $this->table_def['table_links'])) {
				       $fld = $this->table_def['table_links'][$key];

						if(array_key_exists('Image', $fld)) {
							$s .= '<img src="' . $fld['Image'] . '" border="0" alt="' . $fld['Title'] . ' " /> ';
						}

						$s .= ' <a href="' . $fld['Target'] . (strstr($fld['Target'], "?") ? "&" : "?") . $fld['QSVar'] . '=' . $rs->fields[$fld['QSVal']] . '" title="' . $fld['Title'] . '">' . $rs->fields[$key] . '</a>' ;


						} else {
						  $s .= $rs->fields[$key];
						}

				} else {
				  $s .= $rs->fields[$key];
				}
				$s .= "</td>";
			}
			$s .= "</tr>";
			$rs->MoveNext();
		}
		return "\n<table class='smarty_table' cellspacing='0'  width='100%'>\n$s\n</table>\n";
	}

	function Render($rows=30)
	{
	global $ADODB_COUNTRECS;
		if($this->table_def['sql_vars']) {
			$ardata = array();
			foreach($this->table_def['sql_vars'] as $var) {
				$ardata[] = $this->data_bag[$var];
			}
			$this->sql = vsprintf($this->sql, $ardata);
		}

	ADODB_Pager::Render($this->rows);
	}

}
?>
