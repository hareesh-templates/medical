<?

class Panel_Generator {

	function Create_Panel($Panel_Array, $pan) {

		$count = count ($Panel_Array[link_names]);
		$panel = '';
		if(!$count == '0') {
		$panel_content = '';
		$panel_name = "p = new createPanel('" . $pan . "','" . $Panel_Array[panel_name] . "');" . "\n";
			for($i=0;$i<$count;$i++) {
				$panel_content .= "p.addButton('";
				$panel_content .= $Panel_Array[image][$i];
				$panel_content .= "','";
				$panel_content .= $Panel_Array[link_names ][$i];
				$panel_content .= "','go_there(";
				$panel_content .= '"' . $Panel_Array[link_urls][$i] . '"';
				$panel_content .= ")');" . "\n";
			}
			$panel_end .= "  o.addPanel(p);" . "\n";
		$panel = $panel_name . $panel_content . $panel_end;
		}

		return $panel;
	}
	

	
};
  
?>
