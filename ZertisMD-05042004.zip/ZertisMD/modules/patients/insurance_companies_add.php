<?php
require 'lib/patients.inc.php';
require 'lib/insurance.inc.php';
RequireLogin();
Access_Check('Insurers');

$finish_label = 'Cancel';
$msg = '';
if(req('btnSubmit') == 'Add Company') {
	$id = NULL;
	$msg = add_insurance_company($_REQUEST, &$id);
	if(!$msg) {
		$msg = "Insurance company added successfully";
		$finish_label = 'Finish';
	}
}

?>
<html>
<head>
<title>Add Insurance Company</title>
<script>
<?=cif($msg, "alert('$msg');")?>
window.onclose = function(){ opener.location=opener.location };
</script>
</head>
<body bgcolor="#CCCCCC">

<form border=0 name="insurance_company" method="post" action="insurance_companies_add.php">
<table border="0" cellpadding="0" cellspacing="3">
<tr class="Row0">
	<td class="FormCaption">Name:</td>
	<td colspan="2" align="right"><input type="text" name="name" size="20" value=""></td>
</tr>
<tr class="Row0">
	<td class="FormCaption">ATTN:</td>
	<td colspan="2" align="right"><input type="text" name="attn" size="20" value=""></td>
</tr>
<tr class="Row0">
	<td class="FormCaption">CMS Identification Number:</td>
	<td colspan="2" align="right"><input type="text" size="20" name="cms_id" value=""></td>
</tr>
<tr class="Row0">
	<td class="FormCaption">Billing Type:</td>
	<td colspan="2" align="right"><input type="text" size="20" name="freeb_type" value=""></td>
</tr>
<tr class="Row0">
	<td class="FormCaption">X12 Reciever ID:</td>
	<td colspan="2" align="right"><input type="text" size="20" name="x12_receiver_id" value=""></td>
</tr>
<tr>
	<td></td>
	<td align="right" valign="bottom" nowrap="nowrap">
		<input type="Submit" name="btnSubmit" value="Add Company"> &nbsp;
		</form>
	</td>
	<td align="right" width="60" valign="bottom">
		<form>
		<input type="button" value="<?=$finish_label?>" onClick="window.close()">
	</td>
</tr>
</table>
</form>
</body>
</html>

