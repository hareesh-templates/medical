<?
session_start();
include('../../setup.php');
include('functions/functions.insurance.php');
Access_Check('New Patient');
RequireLogin();

$PID = $_REQUEST[PID] or die('ERROR, NO ID');

if($_REQUEST[msg])
	$msg =$_REQUEST['msg'];

page_header("Edit Patient");






function EditFacility () {
	$msg = '';
	$db =& dbconnect();
	$_POST[subscriber_phone] = strip_phone($_POST[subscriber_phone]);
	$_POST[subscriber_ss] = strip_ssn($_POST[subscriber_ss]);
	$rs = $db->Execute("SELECT * FROM insurance_data WHERE pid='$_REQUEST[PID]' && type='primary'");
		if(!$rs)
		$msg =$db->ErrorMsg();

	$isql = $db->GetUpdateSQL($rs, $_POST);
        if(!$isql)
		$msg =$db->ErrorMsg();

		if(!$db->Execute($isql))
	     $msg = $db->ErrorMsg();
	$db->Disconnect();

	if($msg == '')
		return '';
	else
		return $msg;
}

if($_POST[btnEditPatient] == 'Edit Patient') {
	$msg = '';
	$msg = EditFacility();
	if(!$msg) {
		$db =& dbconnect();
		$SQL = "SELECT CONACT(lname,', ',fname,' ',mname) AS name FROM patient_data WHERE pid='$PID'";
		$temp = $db->GetRow("$SQL");
		$FName = $temp[name];
		$db->Disconnect();
		
		$Action = 'Edited Patient Insurance for : <i>' . $FName . '</i>';
		MakeLog("$Action", "Edited Patient Insurance");
		$msg = "Updated Insurance Successfuly.";
	}
}


function Edit_Form($ar, $record) {

$CSS = css();
GLOBAL $msg;
$IMAGE_DIR = IMAGE_DIR;
$provider = Providers($ar[provider]);
$subscriber_relationship = Relationships($ar[subscriber_relationship]);
$subscriber_state = state_list($ar[subscriber_state ]);
$subscriber_employer_state  = state_list($ar[subscriber_employer_state ]);
$subscriber_sex = Gender($ar[subscriber_sex]);

$subscriber_phone = format_phone($ar[subscriber_phone]);
$subscriber_SSN = format_ssn($ar[subscriber_ss]);


$self_phone = format_phone($record[phone_home]);
$self_SSN = format_ssn($record[ss]);
return <<< EOF
<html>
<head>
$CSS
<script>

function auto_populate() {

	if(document.Edit.subscriber_relationship.value == 'self') {
	  document.Edit.subscriber_fname.value = '$record[fname]';
	  document.Edit.subscriber_mname.value = '$record[mname]';
	  document.Edit.subscriber_lname.value = '$record[lname]';
	  document.Edit.subscriber_street.value = '$record[street]';
	  document.Edit.subscriber_city.value = '$record[city]';
	  document.Edit.subscriber_postal_code.value = '$record[postal_code]';
	  document.Edit.subscriber_phone.value = '$self_phone';
	  document.Edit.subscriber_country.value = '$record[country_code]';
	  document.Edit.subscriber_ss.value = '$self_SSN';
	  document.Edit.subscriber_DOB.value = '$record[DOB]';
	  document.Edit.subscriber_sex.value = '$record[sex]';
	  document.Edit.subscriber_state.value = '$record[state]';
	}
}

	function add_note(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL + '?PID=' + '$record[pubpid]', '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,status=0,menubar=0,resizable=0,width=400,height=165,left = 340,top = 412');");
	}

</script>

</head>
<body>





	<h1 align="Center">Primary Insurance Provider</h1>

	<form action="patient_pri_insurance.php?PID=$_REQUEST[PID]" method="post" name="Edit">

	<table cellspacing="2" border="0">

			<tr>
				<td colspan="2" align="center"><br /><div class="Error"> $msg </div></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Patient MR Number: </td>
				<td class="other">$record[pubpid]</td></tr>

			<tr class="Row0">
				<td class="FormCaption">Primary Insurance Provider:</td>
					<td><select name="provider">
					$provider
					</select>
					<a href="javascript:add_note('insurance_companies_add.php')">Add New Insurer</a>
					</td></tr>
			<tr class="Row0">
				<td class="FormCaption">Plan Name: </td>
				<td><input type="text" name="plan_name" value="$ar[plan_name]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Policy Number: </td>
				<td><input type="text" name="policy_number" value="$ar[policy_number]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Group Number: </td>
				<td><input type="text" name="group_number" value="$ar[group_number]"></td></tr>


			<tr><td colspan="2"><hr></td></tr>


			<tr class="Row0">
				<td class="FormCaption">Subscriber Employer (SE) <br>(enter Student, PT Student, or leave blank for unemployed): </td>
				<td><input type="text" name="subscriber_employer" value="$ar[subscriber_employer]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">SE Street: </td>
				<td><input type="text" name="subscriber_employer_street" value="$ar[subscriber_employer_street]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">SE City: </td>
				<td><input type="text" name="subscriber_employer_city" value="$ar[subscriber_employer_city]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">SE Zip Code: </td>
				<td><input type="text" name="subscriber_employer_postal_code" value="$ar[subscriber_employer_postal_code]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">SE State: </td>
				<td><select name="subscriber_employer_state">$subscriber_employer_state</select></td></tr>

			<tr class="Row0">
				<td class="FormCaption">SE Country: </td>
				<td><input type="text" name="subscriber_employer_country" value="$ar[subscriber_employer_country]"></td></tr>


			<tr><td colspan="2"><hr></td></tr>

			<tr>
			<td align="right">
			<h3>Subscriber:</h3>
			</td>
			<td>
			</td>
			</tr>


			<tr class="Row0">
			<td class="FormCaption">Relationship: </td>
			<td><select name=subscriber_relationship onchange="javascript:auto_populate();">
				$subscriber_relationship
				</select></td></tr>
					
			<tr class="Row0">
				<td class="FormCaption">First Name: </td>
				<td><input type="text"  name="subscriber_fname" value="$ar[subscriber_fname]"></td></tr>


			<tr class="Row0">
				<td class="FormCaption">Middle Name: </td>
				<td><input type="text" name="subscriber_mname" value="$ar[subscriber_mname]"></td></tr>


			<tr class="Row0">
				<td class="FormCaption">Last Name: </td>
				<td><input type="text" name="subscriber_lname" value="$ar[subscriber_lname]"></td></tr>



			<tr class="Row0">
				<td class="FormCaption">D.O.B.: </td>
				<td><input type="text" name="subscriber_DOB" value="$ar[subscriber_DOB]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">S.S.N.: </td>
				<td><input type="text" name="subscriber_ss" value="$subscriber_SSN"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Sex: </td>
				<td><select name="subscriber_sex">
					$subscriber_sex
					</select></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Subscriber Address: </td>
				<td><input type="text" name="subscriber_street" value="$ar[subscriber_street]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">City: </td>
				<td><input type="text" name="subscriber_city" value="$ar[subscriber_city]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">State: </td>
				<td><select name="subscriber_state">$subscriber_state</select> </td></tr>

			<tr class="Row0">
				<td class="FormCaption">Zip Code: </td>
				<td><input type="text" name="subscriber_postal_code" value="$ar[subscriber_postal_code]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Country: </td>
				<td><input type="text" name="subscriber_country" value="$ar[subscriber_country]"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">Subscriber Phone: </td>
				<td><input type=text name="subscriber_phone" value="$subscriber_phone"></td></tr>

			<tr class="Row0">
				<td class="FormCaption">CoPay: </td>
				<td><input type=text name="copay" value="$ar[copay]"></td></tr>


			<tr><td colspan="2" align="center"><br />
	<input type="image" src="$IMAGE_DIR/Save.png" name="btnEditPatient" value="Edit Patient" />

	</form>

	</table>
EOF;
}


if($_REQUEST['PID']) {
	$db =& dbconnect();

	$SQL = "SELECT fname, mname, lname, street, postal_code, city, state, country_code, DOB, ss, sex, phone_home, pubpid FROM patient_data WHERE pid='$_REQUEST[PID]'";
	$record = $db->GetRow("$SQL") or die('I BLEW UP');


	$rec = $db->GetRow("SELECT * FROM insurance_data WHERE pid='$_REQUEST[PID]' && type='primary'");
	echo Edit_Form($rec, $record);

	$db->Disconnect();

} else {
	echo '<br /><br /><div class="Error">ERROR: No Patient Specified</div>';
}


?>

</body>
</head>
