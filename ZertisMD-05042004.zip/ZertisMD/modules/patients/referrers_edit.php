<?
session_start();
include_once('../../setup.php');
RequireLogin();
Access_Check('Referrers');



/////////////////////////////////////////////////

function EditReferrer () {
	$msg = '';
	$_POST[ssn] = strip_ssn($_POST[ssn]);
	$_POST[phone_h] = strip_phone($_POST[phone_h]);
	$_POST[phone_biz]= strip_phone($_POST[phone_biz]);
	$_POST[phone_c] = strip_phone($_POST[phone_c]);
	$_POST[pager] = strip_phone($_POST[pager]);
	$db =& dbconnect();
	$rs = $db->Execute("SELECT * FROM Referrers WHERE ReferrerID='$_REQUEST[ReferrerID]'");
		if(!$rs)
		$msg =$db->ErrorMsg();

	$isql = $db->GetUpdateSQL($rs, $_POST);
        if(!$isql)
		$msg =$db->ErrorMsg();

		if(!$db->Execute($isql))
	     $msg = $db->ErrorMsg();
	$db->Disconnect();

	if($msg == '')
		return '';
	else
		return $msg;
}

function ValidateForm() {
	if(!$_POST['fname'])
		return "NO First Name NAME WAS REFERRER.";

	if(!$_POST['lname'])
			return "NO Last Name NAME WAS REFERRER.";
	return '';
}

if($_POST[bttnEditReferrer] == 'Edit Referrer') {
	$msg = '';
	$msg = ValidateForm();
	if(!$msg)
		$msg = EditReferrer();
	if(!$msg) {
		$Action = 'Edited Referrer: ' . $_POST[fname] . ' ' . $_POST[lname];
		MakeLog("$Action", "Edited Referrer");
	}
}

/////////////////////////////////////////////////
function EditForm ($rec) {
$CSS = CSS();
Global $msg;
$ssn = format_ssn($rec[ssn]);
$phone_h = format_phone($rec[phone_h]);
$phone_biz= format_phone($rec[phone_biz]);
$phone_c = format_phone($rec[phone_c]);
$pager = format_phone($rec[pager]);
$state = state_list($rec[state]);
return <<< EOOF

	<html>
	<head>
	$CSS
	</head>
	<body>
	<div align="center">
		<h1>Editing Referrer: <i>$rec[fname] $rec[lname]</i></h1>
		<form action="referrers_edit.php?ReferrerID=$rec[ReferrerID]" method="post" name="edit_referrers">
		<div class="Error">$msg</div>
<a href="referrers.php" class="return">&lt;--back to referrers</a><br />
<br />
<br />
		<table border="0" cellpadding="0" cellspacing="3">

		<tr class="Row0">
			<td class="FormCaption">
				First Name:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="fname" value="$rec[fname]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Middle Name:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="mname" value="$rec[mname]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Last Name:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="lname" value="$rec[lname]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Federal Tax ID:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="ssn" value="$ssn">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Federal Drug ID:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="fdid" value="$rec[fdid]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Home Phone:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="phone_h" value="$phone_h">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Business Phone:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="phone_biz" value="$phone_biz">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Cell Phone:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="phone_c" value="$phone_c">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Pager:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="pager" value="$pager">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Address:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="street" value="$rec[street]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				City:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="city" value="$rec[city]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				State:&nbsp;
			</td>
			<td>
				<select name="state">$state</select>
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Zip Code:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="zip" value="$rec[zip]">
			</td>
		</tr>

		<tr class="Row0">
			<td class="FormCaption">
				Country:&nbsp;
			</td>
			<td>
				<input type="text" size="33" name="country" value="$rec[country]">
			</td>
		</tr>

		<tr>
			<td colspan="2" align="center">
				<br />
				<input type="submit" name="bttnEditReferrer" value="Edit Referrer">
			</td>
		</tr>

		</table>
		<br />
		<br />
<a href="referrers.php" class="return">&lt;--back to referrers</a><br />

		</form>
	</div>
	</body>
	</html>
EOOF;
}



/////////////////////////////////////////////////
//Edit Provider




if($_REQUEST[ReferrerID] == 0) {
	$error = 'ERROR: No Referrer Selected.';
	header("Location: referrers.php?msg=$error");
}

$ID = $_REQUEST[ReferrerID] or die("No id");


$db =& dbconnect();


$SQL = "SELECT * FROM Referrers WHERE ReferrerID='$_REQUEST[ReferrerID]'";
$rec = $db->GetRow("$SQL");

echo EditForm($rec);
$db->Disconnect();

?>