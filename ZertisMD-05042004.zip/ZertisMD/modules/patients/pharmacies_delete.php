<?
// Pharmacy Delete Action
session_start();
include_once('../../setup.php');
RequireLogin();
Access_Check('Pharmacies');



if(!$_REQUEST[ID]) {
	//Redirect to Pharmacies, no Pharmacy ID Given
	$error = 'ERROR: No Pharmacy Selected.';
	header("Location: pharmacies.php?msg=$error");
}
elseif($_REQUEST[ID] == 0)
	header("Location: pharmacies.php?");
else {



	$db =& dbconnect();


	$SQL = "Select * FROM Pharmacies WHERE id='$_REQUEST[ID]'";
	$rec = $db->GetRow("$SQL");
	$name= $rec[name];

	$SQL = "DELETE FROM Pharmacies WHERE id='$_REQUEST[ID]'";

	if($db->Execute("$SQL"))
		$msg = 'Pharmacy removed successfully.';

	$db->Disconnect();

	$Action = 'Deleted Pharmacy: ' . $name;
	MakeLog("$Action", "Deleted Pharmacy");

	header("Location: pharmacies.php?msg=$msg");
}
?>