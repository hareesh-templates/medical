<?php
//Perform Search for patient name and id to return to other pages

session_start();
require_once('../../setup.php');
RequireLogin();

$CSS = CSS();

	function strip_keywords($keywords) {
		$keywords = str_replace('-', '', $keywords);
		$keywords = str_replace(',', '', $keywords);
		$keywords = str_replace('.', '', $keywords);
		$keywords = str_replace('/', '', $keywords);
		return str_replace('\\', '', $keywords);
	}
	
function build_html($keywords) {

$keywords = strip_keywords($keywords);

	$sql = "SELECT pid, pubpid, DOB, CONCAT(lname,', ',fname,' ',mname) AS name FROM patient_data WHERE ";
	if(is_numeric($keywords)) {
	 $sql .= "pubpid LIKE '%%$keywords%%' " . 
	 		 "OR ss LIKE '%%$keywords%%' " . 
	 		 "OR DOB LIKE '%%$keywords%%' ";
	} else {
	 $sql .= "lname LIKE '%%$keywords%%' OR mname LIKE '%%$keywords%%' OR fname LIKE '%%$keywords%%' ";
	}
	$sql .= "ORDER BY pubpid DESC, lname DESC, fname DESC, mname DESC";

	$db =& dbconnect();
	$records = $db->GetAll("$sql"); // or die("Can't search, brain hurts"); <- Dies if no results
	$db->Disconnect();

	$a = "<select size=\"10\" name=\"patient\">\n";

	foreach ($records as $record) {
	$a .= "<option vaule=\"$record[pid]\">$record[name] - MR: $record[pubpid] - DOB: $record[DOB]</option>";
	}
	$a .= "</select>";






	$i=0;
	$a .= "\n\n";
	$a .= "<script language=\"Javascript\">";
	$a .= "var thecontents=new Array() \n";
	foreach ($records as $record) {
	$a .= "thecontents[$i]='$record[pid]'\n";
	$i++;
	}
	$a .= "</script>";


	$i=0;
	$a .= "\n\n";
	$a .= "<script language=\"Javascript\">";
	$a .= "var names=new Array() \n";
	foreach ($records as $record) {
	$a .= "names[$i]='$record[name]'\n";
	$i++;
	}
	$a .= "</script>";


	$a .= "<br /><input class=\"button\" TYPE=\"BUTTON\" NAME=\"select\" VALUE=\"Select\" onClick=\"my_process(); return true;\">";

	return $a;
}



if( isset ($_POST[keywords]) && $_POST[keywords] != '')
	$show = build_html ($_POST[keywords]);
else
	$show = '';
?>







<html>
<head>
<?=$CSS?>

<script language="Javascript">

	function my_process () {
		if (names[document.lookup.patient.selectedIndex]) {
		opener.document.editentryform.PatientName.value = names[document.lookup.patient.selectedIndex];
		opener.document.editentryform.patient_id.value = thecontents[document.lookup.patient.selectedIndex];
		// Close the window
		window.self.close();
		}
		else {
			;
		}
	}

</script>

</head>
<body>
	<form action="mini_search.php" method="post" name="lookup">
<table align="center">
<tr>
	<td nowrap="nowrap" align="center"><?=$show?></td></tr>
<tr>
	<td align="center">
		<img src="<?=IMAGE_DIR?>qsearch.gif" alt="Search: " /> <input type="text" style="font-size: .8em; width: 190px" name="keywords" value="<?=$_POST[keywords]?>" onFocus="this.value=''" />
	</td></tr>
<tr>
	<td  align="center"><input type="submit" value="<? echo ($_POST[keywords] == '' ? 'Search' : 'Search Again'); ?>" /></td>
</tr>
</table>
</form>
</body>
</html>
