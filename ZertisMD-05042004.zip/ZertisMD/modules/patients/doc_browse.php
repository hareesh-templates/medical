<html>
<head>
<script>
function op() { //This function is used with folders that do not open pages themselves. See online docs.
}
</script>
</head>
<frameset rows="1,*" noresize="noresize">
	<frame src="asdf.php" noresize="noresize"  scrolling="none" />
	<frameset cols="200,*">
		<frame src="doc_browse_left.php?PID=<?=@$_REQUEST['PID']?>" name="treeframe" />
		<frame src="doc_view_dir.php?PID=<?=@$_REQUEST['PID']?>&path=/" name="basefrm" />
	</frameset>
</frameset>
</html>
