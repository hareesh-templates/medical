<?
session_start();
include('../../setup.php');
Access_Check('Patients');
RequireLogin();

error_reporting(E_ALL);

require_once ('classes/RxList.class.php');


function build_list ( $query ) {
	new RxList();
	$page = RxList::getPage( $query );
	$tokens = RxList::parse2tokens($page);
	$hash = RxList::tokens2hash($tokens);
	
	$a = "\n";
	foreach ($hash AS $k => $v) {
		$a .= "<option title=\"". $v[drug_class] . "\"";
		$a .= "value=\"" . $v[brand_name] . " (" . $v[generic_name] . ")" . "\">" . "\n";
		$a .= $v[brand_name] . " (" .$v[generic_name] . ")";
		$a .= "</option> \n";
	}
 return $a;	
}


?>
<html>
<head>


<script language="Javascript">

	function my_process () {
		if (self.document.first_form.prescription.value) {
		opener.document.prescribe.drug.value = self.document.first_form.prescription.value;
		// Close the window
		window.self.close();
		}
		else {
			;
		}
	}

</script>

</head>
<body bgcolor="#CACACA">

<?
if (isset ( $_POST['drug'])) {
	$keyword = $_POST['drug'];
?>
<form name="first_form">
 <table align="center">
 <tr>
 	<td align="center" nowrap="nowrap">
 	<select name="prescription">
	<?=build_list( $_POST['drug'])?>
	</select> <input class="button" TYPE="BUTTON" NAME="select" VALUE="Select" onClick="my_process(); return true;">
	</td>
</tr>
</table>
</form>
<?
	$search_text = "Search Again";
}
else {
	$search_text = "Search";
	$keyword = '';
}
?>

 <form action="prescription_lookup.php" method="POST" name="lookup">
 <table align="center">
 <tr>
 	<td align="center" nowrap="nowrap">
 	<img src="<?=IMAGE_DIR?>qsearch.gif"><input type="text" name="drug" value="<?=$keyword?>">
 	</td>
 </tr>
 <tr>
 	<td align="center">
 	<br />
 	<input type="Submit" name="Submit" value="<?=$search_text?>">
 	</td>
 </tr></table>
 </form>
 </body>
 </html>