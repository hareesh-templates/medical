<?

session_start();
require_once('../../setup.php');
//Access_Check('List Patients');
RequireLogin();

function List_Info ($rec) {
$CSS = css();

return <<< EOF
<html>
<head>
$CSS
<style>
BODY, .text, .bold, TABLE, TR, TD {
font-size:9pt;
color:#404040;

}

</style>
</head>

<body>
<SCRIPT LANGUAGE="JavaScript">

	function popUp(URL) {
	day = new Date();
	id = "findfirstpopup";
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width=350,height=400,left = 825,top = 400');");
	}

	function reloadForm(select) {
		var provid = select.options[select.selectedIndex].value;
		var title = document.find_first.event_subject.value;
		var category = document.find_first.event_category.options[document.find_first.event_category.selectedIndex].value;
		var duration = document.find_first.event_dur_minutes.options[document.find_first.event_dur_minutes.selectedIndex].value;
		var s_day = document.find_first.event_startday.options[document.find_first.event_startday.selectedIndex].value;
		var s_month = document.find_first.event_startmonth.options[document.find_first.event_startmonth.selectedIndex].value;
		var s_year = document.find_first.event_startyear.options[document.find_first.event_startyear.selectedIndex].value;
		var s_hour = document.find_first.event_starttimeh.options[document.find_first.event_starttimeh.selectedIndex].value;
		var s_min = document.find_first.event_starttimem.options[document.find_first.event_starttimem.selectedIndex].value;
		var s_ampm = document.find_first.event_startampm.options[document.find_first.event_startampm.selectedIndex].value;
		var location = 'find_patient.php?no_nav=1&event_startampm=1&event_starttimeh=10&event_category=5&event_dur_minutes=15&patient_id=1';

		location = location + '&provider_id=' + provid;

		if (title != "undefined") {
			location = location + '&event_subject=' + title;
		}
		if (category != "undefined") {
			location = location + '&event_category=' + category;
		}
		if (duration != "undefined") {
			location = location + '&event_dur_minutes=' + duration;
		}
		if (s_day != "undefined") {
			location = location + '&event_startday=' + s_day;
		}
		if (s_month != "undefined") {
			location = location + '&event_startmonth=' + s_month;
		}
		if (s_year != "undefined") {
			location = location + '&event_startyear=' + s_year;
		}
		if (s_hour != "undefined") {
			location = location + '&event_starttimeh=' + s_hour;
		}
		if (s_min != "undefined") {
			location = location + '&event_starttimem=' + s_min;
		}
		if (s_ampm != "undefined") {
			location = location + '&event_startampm=' + s_ampm;
		}
		window.location.href=location;
	}
</script>

 <form name="find_first" action="find_patient.php?no_nav=1" method="post" enctype="application/x-www-form-urlencoded">
	<table width="100%" border="0" cellpadding="2" cellspacing="0" >
	<!-- EVENT INFO ROWS -->
	<tr>
		<td valign="top">
			Event Title <span style="font-size:8pt;">*Required</span><br />
			<input type="text" name="event_subject" value="" /><br />
			Event Date <span style="font-size:8pt;">*Required</span><br />
			<select name="event_startmonth" id="event_startmonth" size="1" tabindex="1" ><option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10" selected="selected">October</option><option value="11">November</option><option value="12">December</option></select><select name="event_startday" id="event_startday" size="1" tabindex="2" ><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22" selected="selected">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select><select name="event_startyear" id="event_startyear" size="1" tabindex="3" ><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004" selected="selected">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option><option value="2033">2033</option><option value="2034">2034</option></select><br /><br />

			<input type="hidden" name="event_sharing" value="1"><!-- default of 1 is ahring type "public" -->
		</td>

		<td  align="left" valign="top">

			<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td>
					Provider
				</td>
				<td>
					<select name="event_userid" onChange="reloadForm(this);" ><option value="">Unassigned</option><option value="1">Dr. Gilrowy</option><option value="1">Dr. Kavorkian</option><option value="a">Dr. Mom</option><option value="A">Dr. Kid</option></select>
				</td>
			</tr>

			<tr>
				<td>
					Patient
				</td>
				<td>
					<select name="event_pid" ><option value="1">Doe, John</option><option value="">None Specified</option></select>
				</td>
			</tr>

			<tr>
				<td valign="top">
					Category&nbsp;
				</td>
				<td>
					<select name="event_category" ><option value="1" >No Show</option><option value="2" >In Office</option><option value="3" >Out Of Office</option><option value="4" >Vacation</option><option value="5" selected>Office Visit</option><option value="8" >Lunch</option></select>
				</td>
			</tr>
			</table>
		</td>
		<td valign="top">
			<table>
			<tr>
				<td>
					Time &nbsp;
				</td>
				<td>
					<select name="event_starttimeh" id="event_starttimeh" size="1" tabindex="7" ><option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10" selected="selected">10</option><option value="11">11</option><option value="12">12</option></select> <select name="event_starttimem" id="event_starttimem" size="1" tabindex="8" ><option value="0">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select> <select name="event_startampm" id="event_startampm" size="1" tabindex="9" ><option value="1" selected="selected">AM</option><option value="2">PM</option></select>
				</td>
			</tr>

			<tr>
				<td>
					Duration&nbsp;
				</td>
				<td>
					<!--<select name="event_dur_hours"><option value="0" selected>00</option><option value="1" >01</option><option value="2" >02</option><option value="3" >03</option><option value="4" >04</option><option value="5" >05</option><option value="6" >06</option><option value="7" >07</option><option value="8" >08</option><option value="9" >09</option><option value="10" >10</option><option value="11" >11</option><option value="12" >12</option><option value="13" >13</option><option value="14" >14</option><option value="15" >15</option><option value="16" >16</option><option value="17" >17</option><option value="18" >18</option><option value="19" >19</option><option value="20" >20</option><option value="21" >21</option><option value="22" >22</option><option value="23" >23</option><option value="24" >24</option></select>:-->
					<input type="hidden" name="event_dur_hours" value="0" /><select name="event_dur_minutes" ><option value="0" >00</option><option value="15" selected>15</option><option value="30" >30</option><option value="45" >45</option></select>
				</td>
			</tr>
			</table>
		</td>
		<td valign="top">
			<A HREF="javascript:popUp('index.php?no_nav=1&module=PostCalendar&func=search&event_category=5&patient_id=1&provider_id=0&event_endday=29&event_endmonth=10&event_endyear=2004&submit=Find%20First&event_subject=' + document.find_first.event_subject.value )" style="font-size:10pt;font-family:san-serif;">First Available Appointment</A>
			<br /><br />
			<input type="submit" name="submit" value="go">
			<input type=hidden name="form_action" value="commit"/>
			<input type="hidden" name="event_desc" value="no description" />
			<input type="hidden" name="event_allday" value="0" />
			<!-- EVENT INFO ROWS -->
			<!-- baggage from regular size submit form -->
			<input type="hidden" name="event_repeat" value="0" checked />
			<input type="hidden" name="event_repeat_on_freq" value="1" size="4" />
			<input type="hidden" name="event_endtype" value="1"  />
			<input type="hidden" name="event_endmonth" id="event_endmonth" value="01">
			<input type="hidden" name="event_endday" id="event_day" value="01">
			<input type="hidden" name="event_endyear" id="event_day" value="1994">
			<input type="hidden" name="event_endtype" value="0" checked />
			<input type="hidden" name="double_book" value=""/>
			<!-- REPEATING ROWS -->
			<input type="hidden" name="pc_html_or_text" value="text" selected>
			<input type="hidden" name="is_update" value="" /><input type="hidden" name="pc_event_id" value="" />
			<input type="hidden" name="data_loaded" value="1" />
		</td>
	</tr>
	</table>
</form>


EOF;
}



$ID = $_REQUEST[PID] or die("No id");


$db =& dbconnect();

$SQL = "SELECT * FROM patient_data WHERE pid='$_REQUEST[PID]'";

$rec = $db->GetRow("$SQL");

echo List_Info($rec);
$db->Disconnect();

?>

</body>
</head>