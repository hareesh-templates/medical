<?
//Modified Trailer from origanol Calendar

 function Top (){
 
 ?>

	<table border="0" style="width:90%; align: center;" align="center" cellpadding="0" cellspacing="0">
	<tr><td align="center" nowrap="nowrap">
	<form>
	<a href="day.php?date=<?=date("Ymd")?>" title="Today"><img src="today.png" style="vertical-align:middle; border:0px;"></a>
	</form>

	</td>
	<td align="center" nowrap="nowrap">


	<form action="month.php" method="get" name="SelectMonth">
	<?php
	  if ( ! empty ( $user ) && $user != $login )
		echo "<input type=\"hidden\" name=\"user\" value=\"$user\" />\n";
	  if ( ! empty ( $cat_id ) && $categories_enabled == "Y"
		&& ( ! $user || $user == $login ) )
		echo "<input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\" />\n";
	?>
	<a href="month.php?date=<?=date("Ymd")?>" title="This Month"><img src="month.png" style="vertical-align:middle; border:0px;"></a>
	<select name="date" onchange="document.SelectMonth.submit()" style="vertical-align:middle;">
	<?php
	  if ( ! empty ( $thisyear ) && ! empty ( $thismonth ) ) {
		$m = $thismonth;
		$y = $thisyear;
	  } else {
		$m = date ( "m" );
		$y = date ( "Y" );
	  }
	  $d_time = mktime ( 3, 0, 0, $m, 1, $y );
	  $thisdate = date ( "Ymd", $d_time );
	  $y--;
	  for ( $i = 0; $i < 25; $i++ ) {
		$m++;
		if ( $m > 12 ) {
		  $m = 1;
		  $y++;
		}
		$d = mktime ( 3, 0, 0, $m, 1, $y );
		echo "<option value=\"" . date ( "Ymd", $d ) . "\"";
		if ( date ( "Ymd", $d ) == $thisdate )
		  echo " selected=\"selected\"";
		echo ">";
		echo date_to_str ( date ( "Ymd", $d ), $DATE_FORMAT_MY, false, true );
		echo "</option>\n";
	  }
	?>
	</select>
	<!-- <input type="submit" value="<?php etranslate("Go")?>" /> -->
	</form>
	</td>
	<td align="center" nowrap="nowrap">

	<form action="week.php" method="get" name="SelectWeek">
	<?php
	  if ( ! empty ( $user ) && $user != $login )
		echo "<input type=\"hidden\" name=\"user\" value=\"$user\" />\n";
	  if ( ! empty ( $cat_id ) && $categories_enabled == "Y"
		&& ( ! $user || $user == $login ) )
		echo "<input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\" />\n";
	?>
	<a href="week.php?date=<?=date("Ymd")?>" title="This Week"><img src="week.png" style="vertical-align:middle; border:0px;"></a>
	<select name="date" onchange="document.SelectWeek.submit()" style="vertical-align:middle;">
	<?php
	  if ( ! empty ( $thisyear ) && ! empty ( $thismonth ) ) {
		$m = $thismonth;
		$y = $thisyear;
	  } else {
		$m = date ( "m" );
		$y = date ( "Y" );
	  }
	  if ( ! empty ( $thisday ) ) {
		$d = $thisday;
	  } else {
		$d = date ( "d" );
	  }
	  $d_time = mktime ( 3, 0, 0, $m, $d, $y );
	  $thisdate = date ( "Ymd", $d_time );
	  $wday = date ( "w", $d_time );
	  if ( $WEEK_START == 1 )
		$wkstart = mktime ( 3, 0, 0, $m, $d - ( $wday - 1 ), $y );
	  else
		$wkstart = mktime ( 3, 0, 0, $m, $d - $wday, $y );
	  for ( $i = -7; $i <= 7; $i++ ) {
		$twkstart = $wkstart + ( 3600 * 24 * 7 * $i );
		$twkend = $twkstart + ( 3600 * 24 * 6 );
		echo "<option value=\"" . date ( "Ymd", $twkstart ) . "\"";
		if ( date ( "Ymd", $twkstart ) <= $thisdate &&
		  date ( "Ymd", $twkend ) >= $thisdate )
		  echo " selected=\"selected\"";
		echo ">";
		printf ( "%s - %s",
		  date_to_str ( date ( "Ymd", $twkstart ), $DATE_FORMAT_MD, false, true ),
		  date_to_str ( date ( "Ymd", $twkend ), $DATE_FORMAT_MD, false, true ) );
		echo "</option>\n";
	  }
	?>
	</select>
	<!-- <input type="submit" value="<?php etranslate("Go")?>" /> -->
	</form>
	</td>
	<td align="center" nowrap="nowrap">

	<form action="year.php" method="get" name="SelectYear">
	<?php
	  if ( ! empty ( $user ) && $user != $login )
		echo "<input type=\"hidden\" name=\"user\" value=\"$user\" />\n";
	  if ( ! empty ( $cat_id ) && $categories_enabled == "Y"
		&& ( ! $user || $user == $login ) )
		echo "<input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\" />\n";
	?>
	<a href="year.php?year=<?=date("Y")?>" title="This Year"><img src="year.png" style="vertical-align:middle; border:0px;"></a>
	<select name="year" onchange="document.SelectYear.submit()" style="vertical-align:middle;">
	<?php
	  if ( ! empty ( $thisyear ) ) {
		$y = $thisyear;
	  } else {
		$y = date ( "Y" );
	  }
	  for ( $i = $y - 4; $i < $y + 4; $i++ ) {
		echo "<option value=\"$i\"";
		if ( $i == $y )
		  echo " selected=\"selected\"";
		echo ">$i</option>\n";
	  }
	?>
	</select>
	<!-- <input type="submit" value="<?php etranslate("Go")?>" />-->
	</form>
	</td>
	</tr>
	</table>
 <?php
 }
 
 function Bottom($type, $u_url, $thisyear, $thismonth, $thisday ) {
 ?>

 <hr /><br />

 <table border="0" width="90%" align="center" cellspacing="0" cellpadding="0">
 <tr>
	<td align="left">
	<a class="navlinks" href="<?=$type?>.php?
	<?php
	  echo $u_url;
	  if ( $thisyear ) {
		switch($type) {
		case 'day':
 			echo "year=$thisyear&amp;month=$thismonth&amp;day=$thisday&amp;";
			break;
		case 'week':
			echo "year=$thisyear&amp;month=$thismonth&amp;day=$thisday&amp;";
			break;
		case 'month':
    		echo "year=$thisyear&amp;month=$thismonth&amp;";
			break;
		case 'year':
   			echo "year=$thisyear&amp;";
			break;
		default:
			echo 'BUG';
	 	}
	  }
	  echo $caturl . "&amp;";
	?>
	friendly=1" target="cal_printer_friendly" title="Generate printer-friendly version">
	[Printer Friendly]</a>

	</td>
	
	<td align="right">
	<a class="navlinks" href="search.php" title="Search Calendar">[Search]</a>
	</td>
 </tr>
 </table>
 <br />
<?PHP
 }
?>