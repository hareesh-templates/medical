<hr />
<b><?php etranslate("Go to")?>:</b> <a href="help_index.php"><?php etranslate("Help Index")?></a>
