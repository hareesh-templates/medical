<script type="text/javascript">
<!-- <![CDATA[
function schedule_event (h,m) {
  document.forms[0].hour.value = h;
  document.forms[0].minute.value = m;
  document.forms[0].submit ();
  return true;
}
//]]> -->
</script>