<?php
//Perform Checkout

session_start();
require_once('../../setup.php');
RequireLogin();

if( isset ($_REQUEST[checkin]) == 1) {
	if( isset ($_REQUEST[cal_id])) {

		$db =& dbconnect();
		$SQL = "UPDATE webcal_entry SET check_out = '0' WHERE cal_id='$_REQUEST[cal_id]'";
		$rec = $db->Execute("$SQL") or die(mysql_error());
		$db->Disconnect();

	header("Location: $_SERVER[HTTP_REFERER]");
	} else {

		echo "<h1>ERROR:</h1><i>Opps! My brain hurts!</i><br />  I can't remember who you were checking out,<br /> I didn't recieve a calendar ID from the previous form.";

	}

}
elseif( isset ($_REQUEST[cal_id])) {

		$db =& dbconnect();
		$SQL = "UPDATE webcal_entry SET check_out = '1' WHERE cal_id=$_REQUEST[cal_id]";
		$rec = $db->Execute("$SQL") or die(mysql_error());
		$SQL = "SELECT patient_id FROM webcal_entry WHERE cal_id=$_REQUEST[cal_id]";
		$rec = $db->GetRow("$SQL") or die(mysql_error());
		$db->Disconnect();

	header("Location: ../patients/patient_index?PID=" . $rec[patient_id]);
} else {

	echo "<h1>ERROR:</h1><i>Opps! My brain hurts!</i><br />  I can't remember who you were checking out,<br /> I didn't recieve a calendar ID from the previous form.";
}

?>