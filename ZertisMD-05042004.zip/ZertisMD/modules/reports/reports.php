<?

session_start();
require_once('../../setup.php');
Access_Check('Reports');
RequireLogin();

if ( isset ($_REQUEST[report])) {
	$report = $_REQUEST[report];
	header("Location: forms/" . $report );
}



$data_fields = array(


"list_multiple" 	=> array(
		"sql" => "select * from Reports WHERE type='multiple'",
		"default_sort" => array("title", "ASC"),
		"sql_vars" => array(""),
		"table_links" => array(
					//Link Item          URL VAR  VAR Value     Link To
					"title" 		=> array(
										"QSVar"  => "report",
									    "QSVal"  => "file",
									    "Title"  => "Generate Report",
									    "Target" => "reports.php",
									    "Window" => "_blank")
						),
		"fields" => array(
			"Report"			=> "title"
		)
	),

"list_single" 	=> array(
		"sql" => "select * from Reports WHERE type='single'",
		"default_sort" => array("title", "ASC"),
		"sql_vars" => array(""),
		"table_links" => array(
					//Link Item          URL VAR  VAR Value     Link To
					"title" 		=> array(
										"QSVar"  => "report",
									    "QSVal"  => "file",
									    "Title"  => "Generate Report",
									    "Target" => "reports.php",
									    "Window" => "_blank")

						),
		"fields" => array(
			"Report"			=> "title",
		)
	)

);


?>


<html>
<head>
<?=CSS()?>
</head>
<body>
<br />
<div align="center">
<h1>Report Generator</h1>
</div>
<br />

<table style="border:0px solid; width:90%;" align="center">
<tr>
	<td class="other" align="center">
		Generate Batch Reports
		<!-- Select Report, Each report should know how to handle what it is doing, the SQL and so forth, -->
		<!-- Just go to Reports URL -->
	</td>
	<td class="other" align="center">
		Generate Individual Reports
		<!-- Javascript popup, chose individual, on submit, send to report with individual's ID -->
	</td>
</tr>
<tr>
	<td>
		<?=zertis_pager( $data_fields['list_multiple'], &$_REQUEST )?>
		<!-- List ALL Batch Reports -->
	</td>
	<td>
	<?=zertis_pager( $data_fields['list_single'], &$_REQUEST )?>
		<!-- List ALL Individual Reports -->
	</td>
</tr>
</table>

<?=page_footer()?>

</body>
</head>