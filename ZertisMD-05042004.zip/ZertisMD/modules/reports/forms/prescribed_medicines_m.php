<?
session_start();
include_once('../../../setup.php');
include_once('../functions.inc.php');
RequireLogin();

// leave blank for default, space for nothing
$title = "All Patient Medications vs Allergies"; // 
$today = date("m-d-Y");

$multiple = "1"; // Must have


$smarty = GetSmarty();
$style = "<style type=\"text/css\">
		H1 {
		font-family: Arial;
		font-size: 16px;
		}
		</style>";

$smarty->clear_compiled_tpl("report.tpl");
$smarty->assign('style', $style);
$smarty->template_dir = MODULE_DIR . '/reports';
$smarty->assign('TODAY', $today);
$smarty->assign('multiple', $multiple);
$smarty->assign('title', $title);
$smarty->display('header.tpl');
$smarty->display('title.tpl');

// if input is not provided, then ask user 
// for custome input, all needed to hand to 
// files below, put in $INPUT array as if in 
// $_REQUEST array this should only be asked for once,

	$db =& dbconnect();
	$SQL = "SELECT pid FROM patient_data";
		$records = @$db->GetAll("$SQL");
	$db->Disconnect();
	$INPUT = true;
	include('prescribed_medicines_s.php');
	$i = '1';
	foreach ($records as $record) {
		if($i=='1') {
		$multiple = "0"; // Must have
		$output = make_report($record[pid]);
		create_output($output, $title, $multiple);
		}
		else {
		$multiple = "1"; // Must have
		$output = "<br /><div style=\"page-break-before: always\">";
		$output .= 	"<div style=\"text-align: right;\"> Date: $today</div><br />";
		$output .= make_report($record[pid]);
		$output .= "</div>";
		create_output($output, $title, $multiple);
		}
	$i++;
	}


$smarty->display('footer.tpl');

?>