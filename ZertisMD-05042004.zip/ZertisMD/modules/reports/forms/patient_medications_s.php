<?
session_start();
include_once('../../../setup.php');
include_once('../functions.inc.php');
RequireLogin();


// leave blank for default, space for nothing
$title = "Patient Medications";

// Use filename for function name
// very important, otherwise functions are
// redeclared when files are included
// in multiple reports
function make_report ($PID) {
// do sql query begin generating report
	$db =& dbconnect();
	$SQL = "SELECT CONCAT(lname,', ',fname,' ',mname) AS name FROM patient_data WHERE pid='$PID'";
		$rec = @$db->GetRow("$SQL");
		$name = $rec[name];
		
	$SQL = "SELECT date, title, activity, comments FROM p_lists WHERE pid='$PID' && type='medication' ORDER BY activity DESC, date DESC";
		$records = @$db->GetAll("$SQL");
		$db->Disconnect();
		$s = "<table style=\"border:1px solid #808080; width: 100%;\"> \n
				<tr style=\"background-color:#AAAAAA\"><td colspan=\"4\">Medication Report for:<b> $name </b></td></tr> \n
				<tr style=\"background-color:#CCCCCC\"><td>Date</td><td>Title</td><td>Comment</td><td>Active</td></tr>\n";
		foreach($records AS $record) {
		$s .= "<tr>";
		$s .= "<td>" . $record[date] . "</td>\n";
		$s .= "<td>" . $record[title] . "</td>\n";
		$s .= "<td>" . $record[comments] . "</td>\n";
		$s .= "<td>" . $record[activity] . "</td>\n";
		$s .= "</tr>\n";
		}
		$s .= "</table>\n";

	return $s;

}

//test for $INPUT from multiple reports,
if( isset ($INPUT)) {
	if(! isset ($multiple))
		$multiple = 1;
	//once you have the input Generate Output
	// Generated in the multiple php file
	//	$output = make_report($INPUT[PID]);
	//	create_output($output, $title, $multiple);
}

//test for input from request
elseif( isset ($_REQUEST[PID])) {
	if(! isset ($multiple))
		$multiple = 0;
	//once you have the input Generate Output
	$output = make_report($_REQUEST[PID]);
	create_output($output, $title, $multiple);
}

elseif( isset ($_REQUEST[patient_id])) {
	if(! isset ($multiple))
		$multiple = 0;
	//once you have the input Generate Output
	$output = make_report($_REQUEST[patient_id]);
	create_output($output, $title, $multiple);
}

//if both test fail, ask user for input for report
else {
	if( isset ($_SESSION[PID])) {
	$db =& dbconnect();
	$SQL = "SELECT CONCAT(lname,', ',fname,' ',mname) AS name FROM patient_data WHERE pid='$_SESSION[PID]'";
		$rec = @$db->GetRow("$SQL");
		$name = $rec[name];
	$db->Disconnect();
	}
	?>	
		<html><head><?=CSS();?>
		</head>
		<body>
		<br />
		<div align="center">
		<form action="patient_medications_s.php" name="editentryform" method="POST">
		<h2>Which patient to you wish to genarate this report for?</h2><br />
		<input type="text" name="PatientName" size="40" value="<?=$name?>" READONLY style="background-color:#E5E5E5;"> &nbsp;
		<input type="button" value="Clear" onClick="javascript:editentryform.PatientName.value=''; editentryform.patient_id.value='';" />
		   &nbsp; &nbsp;
		<input class="button" type="BUTTON" 
		onClick="patientPopup=window.open('../../patients/mini_search.php', 'patientPopup', 'width=460,height=300,menubar=no,titlebar=no,left = 350,top = 400'); patientPopup.opener=self; return true;"
		value="Patient" /><br /><br />
		<input type="hidden" name="patient_id" value="<?=$_SESSION[PID]?>" />
		<input type="Submit" name="Sumbit" value="Submit" />
		</form>
		</div>
		</body>
	<?
	
}
?>