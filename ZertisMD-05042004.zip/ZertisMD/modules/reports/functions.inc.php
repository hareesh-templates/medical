<?

function create_output($output, $title, $multiple) {
$style = "<style type=\"text/css\">
		H1 {
		font-family: Arial;
		font-size: 16px;
		}
		</style>";

$today = date("m-d-Y");
$smarty = GetSmarty();
$smarty->clear_compiled_tpl("report.tpl");
$smarty->template_dir = MODULE_DIR . '/reports';
$smarty->assign('TODAY', $today);
$smarty->assign('style', $style);
$smarty->assign('OUTPUT', $output);
$smarty->assign('multiple', $multiple);
$smarty->assign('title', $title);
$smarty->display('report.tpl');
}
?>