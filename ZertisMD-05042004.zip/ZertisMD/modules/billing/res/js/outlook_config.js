

// ---------------------------------------------------------------------------
// Example of howto: use Outlook Like Bar
// ---------------------------------------------------------------------------


  //create OutlookBar-Object:
  //              Name
  //              x-position
  //              y-Position
  //              width
  //              height
  //              background-color
  //              page background-color (needed for OP5)
  //(screenSize object is created by 'crossbrowser.js')
  //

	  var o = new createOutlookBar('Bar2',0,0,screenSize.width,screenSize.height,'#FFFFFF','#FFFFFF') // OutlookBar
  var p

  //create first panel..
  p = new createPanel('a','Main');

  //add buttons:
  //             image name
  //             label text
  //             onClick JavaScript code
  //


  function go_there($location) {
  parent.PMain.location=$location;
  }

  p.addButton('java-menu/netm.gif','Demographics','go_there("?")');
  p.addButton('java-menu/netm.gif','Additional Info','go_there("?")');
  p.addButton('java-menu/netm.gif','Occupational Info','go_there("?")');
  p.addButton('java-menu/netm.gif','Patient History','go_there("?")');
  o.addPanel(p);

  //create second panel...
  p = new createPanel('I','Insurance');
  p.addButton('java-menu/netm.gif','Primary Insurance Provider','go_there("?")');
  p.addButton('java-menu/netm.gif','Secondary Insurance Provider','go_there("?")');
  p.addButton('java-menu/netm.gif','Tertiary Insurance Provider','go_there("?")');
  p.addButton('java-menu/netm.gif','Bill Provider','go_there("?")');
  o.addPanel(p);

  p = new createPanel('M','Medincinal');
  p.addButton('java-menu/netm.gif','Allergies','go_there("?")');
  p.addButton('java-menu/netm.gif','Medications','go_there("?")');
  p.addButton('java-menu/netm.gif','Immunizations','go_there("?")');
  p.addButton('java-menu/netm.gif','Prescriptions','go_there("?")');
  o.addPanel(p);


  p = new createPanel('S','Scheduling');
  p.addButton('java-menu/netm.gif','Schedule Appointment','go_there("?")');
  p.addButton('java-menu/netm.gif','View Appointments','go_there("?")');
  p.addButton('java-menu/netm.gif','View History','go_there("?")');
  p.addButton('java-menu/netm.gif','Add Note','go_there("?")');
  o.addPanel(p);

  p = new createPanel('BR','Billing & Reports');
  p.addButton('java-menu/netm.gif','Bill Provider','go_there("?")');
  p.addButton('java-menu/netm.gif','Generate Patient Bill','go_there("?")');
  p.addButton('java-menu/netm.gif','View Status','go_there("?")');
  p.addButton('java-menu/netm.gif','Add Note','go_there("?")');
  o.addPanel(p);

  o.draw();         //draw the Outlook Like Bar!


//-----------------------------------------------------------------------------
//functions to manage window resize
//-----------------------------------------------------------------------------
//resize OP5 (test screenSize every 100ms)

function resize_op5() {
  if (bt.op5) {
    o.showPanel(o.aktPanel);
    var s = new createPageSize();
    if ((screenSize.width!=s.width) || (screenSize.height!=s.height)) {
      screenSize=new createPageSize();
      //need setTimeout or resize on window-maximize will not work correct!
      //ben�tige das setTimeout oder das Maximieren funktioniert nicht richtig
      setTimeout("o.resize(0,0,screenSize.width,screenSize.height)",100);
    }
    setTimeout("resize_op5()",100);
  }
}

//resize IE & NS (onResize event!)
function myOnResize() {
  if (bt.ie4 || bt.ie5 || bt.ns5) {
    var s=new createPageSize();
    o.resize(0,0,s.width,s.height);
  }
  else
    if (bt.ns4) location.reload();
}

