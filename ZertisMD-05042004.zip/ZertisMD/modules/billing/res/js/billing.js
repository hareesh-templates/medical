function force_frames() {
	if(self.name != 'billing_view') {
		// Have to make FULL URL for Opera
		var url = location.protocol + '//' + location.host + 
			location.pathname.substring(0,location.pathname.lastIndexOf('/')) +
			'/billing_frameset.php?link=' + location.pathname;
   
   		// keep from trapping the "Back button" with replace
		if(document.images)
			document.location.replace(url);
		else
			document.location.href = url;
	}
}