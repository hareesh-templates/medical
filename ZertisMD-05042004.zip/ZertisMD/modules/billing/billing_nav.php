<?php
/* Outlook-like menu navigation for the Billing Module */
require 'lib/billing.inc.php';
RequireLogin();
//Access_Check('Patients');

$IMAGE = IMAGE_DIR . 'new.png';
?>

<html>
<base target="billing_view" />
<head>
	<?=CSS()?>
	<style type="text/css">
		div { position:absolute; }
		.button {
			width:300px; 
			margin-top:0px; 
			padding:4px 2px 0px 2px; 
			align:center; 
			text-align:center; 
			font-family:arial;
 			font-size:10pt; 
 			color:silver; 
 			font-weight: bold; 
 			cursor:hand; 
 			border-width:1;
 			border-style:outset; 
 			position: absolute; 
 			top:-100px; 
 			left: -100px; 
 			border-color:silver;
 			background-image: url(<?=$IMAGE?>); 
 		}
	</style>
	
	<script language="JavaScript" type="text/javascript" src="res/js/crossbrowser.js"></script>
	<script language="JavaScript" type="text/javascript" src="res/js/outlook.js"></script>
	<script language="JavaScript" type="text/javascript">
		// Shortcuts
		function g(location) {	parent.billing_view.location=location; }
		function i(path) { return '<?=$ICONURL?>/' + path; }

		var o = new createOutlookBar('BILL_BAR',0,0,screenSize.width,screenSize.height,'#FFFFFF','#FFFFFF');

		var p = new createPanel('BILL_MAIN','Billing');
		p.addButton(i('ledger.png'), 'Ledger', 'g("ledger.php")');
		p.addButton(i('ledger.png'), 'Billable Items', 'g("billableitems.php")');
		p.addButton(i('ledger.png'), 'Ledger', 'g("ledger.php")');
		p.addButton(i('ledger.png'), 'Ledger', 'g("ledger.php")');
		o.addPanel(p);
		o.draw();

		//-----------------------------------------------------------------------------
		//functions to manage window resize
		//resize OP5 (test screenSize every 100ms)
		function resize_op5() {
		  if (bt.op5) {
		    o.showPanel(o.aktPanel);
		    var s = new createPageSize();
		    if ((screenSize.width!=s.width) || (screenSize.height!=s.height)) {
		      screenSize=new createPageSize();
		      //need setTimeout or resize on window-maximize will not work correct!
		      //ben�tige das setTimeout oder das Maximieren funktioniert nicht richtig
		      setTimeout("o.resize(0,0,screenSize.width,screenSize.height)",100);
		    }
		    setTimeout("resize_op5()",100);
		  }
		}

		//resize IE & NS (onResize event!)
		function myOnResize() {
		  if (bt.ie4 || bt.ie5 || bt.ns5) {
		    var s=new createPageSize();
		    o.resize(0,0,s.width,s.height);
		  }
		  else
		    if (bt.ns4) location.reload();
		}
</script>
</head>
<body onload="resize_op5()" onresize="myOnResize()">
</body>
</html>