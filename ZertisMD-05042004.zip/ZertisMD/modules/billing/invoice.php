<?

session_start();
require_once('../../setup.php');
Access_Check('Billing');
RequireLogin();


?>

<html>
<head>
<?=css()?>
</head>
<body>

<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#FFFFFF" class="Tabs">
<tr>
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>1.gif" width="30">
	</td>
	<td><img src="<?=IMAGE_DIR?>8.gif" height="25" alt="" /></td>
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="summery.php">Summary</a></div></td>
	<td><img src="<?=IMAGE_DIR?>6.gif" height="25" alt="" /></td>

	<!-- Inactive entry -->
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="payable.php">Accounts Payable</a></div></td>
	<td><img src="<?=IMAGE_DIR?>6.gif" height="25" alt="" /></td>

	<!-- end inactive entry -->

	<!-- Inactive entry -->
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="recievable.php">Accounts Recievable</a></div></td>
	<td><img src="<?=IMAGE_DIR?>10.gif" height="25" alt="" /></td>
	<!-- end inactive entry -->


	<!-- Inactive entry -->
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>3.gif" valign="bottom"><div class="TabActive">Invoice - Statement</td>
	<td><img src="<?=IMAGE_DIR?>11.gif" height="25" alt="" /></td>
	<!-- end inactive entry -->
	

	<td nowrap="nowrap" background="<?=IMAGE_DIR?>1.gif" width="95%">
	</td>
	</tr>
</table>



<div align="center">
<h1>Generate Invoice / Statement</h1>
[<a class="return" href="#">Generate Invoice</a>]
&nbsp; &nbsp;
[<a class="return" href="#">Generate Statement</a>]
</div>
<br />
<br />
<br />
<table align="center"><tr>
		<td nowrap="nowrap" align="right">Search Transactions </td>
<form action="" method="post">
		<td align="center">
		<input type="text" style="font-size: .8em; width: 190px" name="keywords" value="<?=$_REQUEST[keywords]?>" onFocus="this.value=''" />
		</td></tr>
		<tr><td colspan="2" align="center"><br /><input type="submit" value="Search" /></td></form>
</tr></table>


</body>
</head>
