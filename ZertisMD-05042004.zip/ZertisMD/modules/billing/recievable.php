<?

session_start();
require_once('../../setup.php');
Access_Check('Billing');
RequireLogin();


?>

<html>
<head>
<?=css()?>
</head>
<body>

<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#FFFFFF" class="Tabs">
<tr>
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>1.gif" width="30">
	</td>
	<td><img src="<?=IMAGE_DIR?>8.gif" height="25" alt="" /></td>
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="summery.php">Summary</a></div></td>
	<td><img src="<?=IMAGE_DIR?>6.gif" height="25" alt="" /></td>

	<!-- Inactive entry -->
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="payable.php">Accounts Payable</a></div></td>
	<!-- end inactive entry -->

	<!-- Inactive entry -->
	<td><img src="<?=IMAGE_DIR?>10.gif" height="25" alt="" /></td>
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>3.gif" valign="bottom"><div class="TabActive">Accounts Recievable</td>
	<td><img src="<?=IMAGE_DIR?>4.gif" height="25" alt="" /></td>
	<!-- end inactive entry -->
	
	<!-- Inactive entry -->
	<td nowrap="nowrap" background="<?=IMAGE_DIR?>5.gif" valign="bottom"><div class="TabInactive"><a href="invoice.php">Invoice - Statement</a></td>
	<td><img src="<?=IMAGE_DIR?>7.gif" width="21" height="25" alt="" /></td>
	<!-- end inactive entry -->

	<td nowrap="nowrap" background="<?=IMAGE_DIR?>1.gif" width="95%">
	</td>
	</tr>
</table>





<div align="center"><h1>Accounts Recievable</h1>
<div style="text-align:right; width:95%;"><a class="return" href="#">Search Transactions</a></div>

<script language="JavaScript">
		function _nump_link_change_select(elem) {
			document.location = '?' + 'select=list_all&' + '&_row_elem_count=' +
				document.forms['_nump_links_form'].elements['_row_elem_count'].options[document.forms['_nump_links_form'].elements['_row_elem_count'].selectedIndex].value;
		}
		</script>
<div align="center">
<a class="return" href="#">Add Transaction</a><br />
</div>
<table border='0' width='98%' cellspacing='0' cellpadding='2' align='center'><tr><td align='center'><img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Begin.png" alt="FIRST" align="middle" border="0"> &nbsp; <img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Left.png" alt="PREV" align="middle" border="0"> &nbsp; 		<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Right.png" alt="NEXT" align="middle" border="0"> &nbsp;

					<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//End.png" alt="LAST" align="middle" border="0"> &nbsp;
		</td></tr><tr><td align='center'>
<table width='100%'><tr><td width='33%'>&nbsp;</td><td width='33%' align='center'>
<font size=-1>Page 1/2</font></td><td width='33%' align='right'><form style='margin:0px' method='get' action='?select=list_all' name='_nump_links_form'>
<select name='_row_elem_count'>
<option >5</option>
<option >10</option>
<option >15</option>
<option >20</option>

<option >25</option>
<option >30</option>
<option >35</option>
<option >40</option>
<option >45</option>
<option >50</option>
<option >55</option>
<option >60</option>
<option >65</option>

<option >70</option>
<option >75</option>
<option >80</option>
<option >85</option>
<option >90</option>
<option >95</option>
<option >100</option>
</select>
</form></td></tr></table>
</td></tr><tr><td align='center'>

<table class='smarty_table' cellspacing='0'  width='100%'>
<tr class='Menu_Head'>

<td align='left' valign='middle' nowrap='nowrap'>&nbsp;  <a href="#" class="CurrentSort">Refrence Number</a></td>
<td align='left' valign='middle' nowrap='nowrap'>&nbsp;  <a href="#" class="TopLinks">Date</a></td>
<td align='left' valign='middle' nowrap='nowrap'>&nbsp;  <a href="#" class="TopLinks">Title</a></td>
<td align='left' valign='middle' nowrap='nowrap'>&nbsp;  <a href="#" class="TopLinks">Description</a></td>
<td align='left' valign='middle' nowrap='nowrap'>&nbsp;  <a href="#" class="TopLinks">Ammount</a></td></tr>

<tr class='Row0'>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">10001</a></td>
<td class="divider" nowrap="nowrap">&nbsp; 12-11-2004</td>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">Blue Cross</a></td>
<td class="divider" nowrap="nowrap">&nbsp; For Patient: Joe Dirt appointment... </td>
<td class="divider" nowrap="nowrap">&nbsp; $150.54</td>
</tr>

<tr class='Row1'>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">10003</a></td>
<td class="divider" nowrap="nowrap">&nbsp; 12-12-2004</td>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">Patient: Joe Dirt</a></td>
<td class="divider" nowrap="nowrap">&nbsp; Physical</td>
<td class="divider" nowrap="nowrap">&nbsp; $14.00</td>
</tr>

<tr class='Row0'>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">10005</a></td>
<td class="divider" nowrap="nowrap">&nbsp; 12-14-2004</td>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">Patient: Billy Bob</a></td>
<td class="divider" nowrap="nowrap">&nbsp; Cast removal</td>
<td class="divider" nowrap="nowrap">&nbsp; $140.89</td>
</tr>

<tr class='Row1'>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">10006</a></td>
<td class="divider" nowrap="nowrap">&nbsp; 12-14-2004</td>
<td class="divider" nowrap="nowrap">&nbsp; <a href="#">Insurance: Blue Cross</a></td>
<td class="divider" nowrap="nowrap">&nbsp; For Patient: Sally Jane, Hearing test</td>
<td class="divider" nowrap="nowrap">&nbsp; $254.99</td>
</tr>


</table>
<div align="right" class="other">
Total: $560.42
&nbsp; &nbsp;
</div>
</td></tr>

<tr><td align='center'>
	<table width='100%'><tr><td width='33%'>&nbsp;</td>
	<td width='33%' align='center'>
	<font size=-1>Page 1/2</font></td><td width='33%' align='right'></td></tr>
	</table>
</td></tr>

<tr><td align='center'>
<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Begin.png" alt="FIRST" align="middle" border="0"> &nbsp; 
<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Left.png" alt="PREV" align="middle" border="0"> &nbsp;
<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//Right.png" alt="NEXT" align="middle" border="0"> &nbsp;
<img src="/~jlee/ZertisMD/templates/zertis_md/graphics//End.png" alt="LAST" align="middle" border="0"> &nbsp;
</td></tr></table>


</body>
</head>
