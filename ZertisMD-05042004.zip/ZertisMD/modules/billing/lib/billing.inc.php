<?php
/* Billing include file - Common functionality across the billing module */
session_start();
require '../../setup.php';
error_reporting(E_ALL);

$MODURL = MODULE_URL . 'billing';

$bi_tabs = array(
	array("Billable Items", "billableitems.php"),
	array("Add Item", "add_billableitem.php"),
	array("Search", "search_billableitems.php")
);

function bpage_header($title, $tabs=NULL,$ctab=NULL) {
	echo "<html>\n<head>\n";
	echo CSS();
	echo "</head>\n<body>\n";
	page_header($title);
	if($tabs)
		tabs($tabs, $ctab);	
	echo "<h1>$title</h1>";	
}

function bpage_footer() {
	page_footer();
	echo "</body>\n</html>";	
}




?>