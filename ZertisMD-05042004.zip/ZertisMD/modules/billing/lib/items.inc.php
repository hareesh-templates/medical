<?php
// Billable items implementation

class BillableItem {
	var $db=NULL;
	var $ItemID=0;
	var $Name='';
	var $TaxRate=0.0;
	
	function BillableItem($id=0) {
		$this->ItemID=$id;
		$this->db =& dbconnect();
	}
	
	function populate() {
		if(!$this->ItemID)
			return;
		$sql = "SELECT * FROM BillableItems WHERE ItemID=$this->ItemID";
		$record = $db->GetRow($sql);
		if($record) {
			$this->Name = $record['Name'];
		 	$this->TaxRate = $record['TaxRate']; 	
		}
	}
	
	function validate($data) {
		if(!@$data['Name'])
			return "No Name";
	}
	
	function create($data) {
		$result = $this->validate($data);
		if($result)
			return $result;
		$trs = $this->db->Execute("SELECT * FROM BillableItems WHERE ItemID=-1");
		$isql = $this->db->GetInsertSQL($trs, $data);
		$this->db->Execute($isql) or dberr($isql, $this->db->GetErrorMsg());
		
		$this->Name = $data['Name'];
		$this->TaxRate = $data['TaxRate'];
		$this->ItemID = $this->db->Insert_ID();
	}
	
	function update($data) {
		$result = $this->validate($data);
		if($result)
			return $result;
		$trs = $this->db->Execute("SELECT * FROM BillableItems WHERE ItemID=" . $data['ItemID']);
		if(!$trs) {
			return "The record could not be found";
		}
		$usql = $this->db->GetUpdateSQL($trs, $data);
	}
}
?>