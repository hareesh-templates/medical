<?php
/* Billing JumpStart */

session_start();
require '../../setup.php';
RequireLogin();
//Access_Check('Billing');

error_reporting(E_ALL);
require 'lib/billing.inc.php';


?>
<html>
<head>
	<script language="Javascript" src="res/js/billing.js"></script>
	<?=CSS()?>
</head>
<body onload="force_frames()">
<div style="margin:10px">
<h1>Billing Panel</h1>
<table>
<tr>
	<td align="center">
		<img src="res/img/core.png" /><br />
		<a href="general_ledger.php">General Ledger</a>
	</td>
	
</table>
</div>
</body>
</html>