<?

session_start();
require_once('../../setup.php');
Access_Check('Billing');
RequireLogin();


$ID = $_REQUEST[PID] or die("No id");


?>


<html>
<head>
<?=CSS()?>
</head>
<body>




</body>
</head>
