<?php
require 'lib/billing.inc.php';
RequireLogin();
//Access_Check('Billing');

$path = @$_REQUEST['link'];
$path = $path ? $path : 'index.php';
?>
<html>
<head>
	<meta HTTP-EQUIV="Content-Type" CONTENT="text/html;CHARSET=iso-8859-1" />
</head>
<frameset cols="*,120" frameborder="yes" bordercolor="#99AACC">
	<frame src="<?=$path?>" name="billing_view" scrolling="Auto" />
	<frame SRC="<?=$MODURL?>/billing_nav.php" name="billing_nav" scrolling="no" noresize="noresize" />
</frameset>
</html>