<?php
require_once('../../setup.php');
session_start();
Access_Check('All Clients');
RequireLogin();
$CSS = css();

?>


<html>
<head>
<?=$CSS?>
</head>
<body>


<?

include_once('adodb-pager.inc.php');
require_once(LIB_DIR . '/classes/SmartPager.class.php');


$request = $_REQUEST['select'];

$data_fields = array(

"list_current" 	=> array(
		"sql" => "select * from Clients WHERE Type='Current Client'",
		"default_sort" => array("Client_Id", "ASC"),
		"sql_vars" => array("select"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Products and Services", "Target" => "client_index.php?link=client_specs.php"),
								"Client_Id" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_properties.png", "Title" => "Edit this Clients Account Properties", "Target" => "client_index.php?link=client_edit.php")
						),
		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
		)
	),


"list_prospective" 	=> array(
		"sql" => "select * from Clients WHERE Type='Prospective Client'",
		"default_sort" => array("Client_Id", "ASC"),
		"sql_vars" => array("select"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Products and Services", "Target" => "client_index.php?link=client_specs.php"),
								"Client_Id" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_properties.png", "Title" => "Edit this Clients Account Properties", "Target" => "client_index.php?link=client_edit.php")
						),
		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
		)
	),
"list_all" 	=> array(
		"sql" => "select * from Clients",
		"default_sort" => array("Client_Id", "ASC"),
		"sql_vars" => array("select"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Products and Services", "Target" => "client_index.php?link=client_specs.php"),
								"Client_Id" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_properties.png", "Title" => "Edit this Clients Account Properties", "Target" => "client_index.php?link=client_edit.php")
						),
		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
		)
	)
);


page_header("List Client");
echo '<h1>Listing All Clients</h1>';

	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields[$request], &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';


	echo $pager->Render($rows_per_page);
	$db->Disconnect();

echo page_footer();

?>

</body>
</head>