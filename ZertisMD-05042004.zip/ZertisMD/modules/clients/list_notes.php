<?
require_once('../../setup.php');
session_start();
Access_Check('Client Notes');
RequireLogin();
?>

<html>
<head>

<?=css()?>

</head>

<body>

<?
include_once('adodb-pager.inc.php');
require_once(LIB_DIR . '/classes/SmartPager.class.php');


$request = $_REQUEST[select];
$ClientID = $_REQUEST[ClientID];

$data_fields = array(

	"list" 	=> array(
			"sql" => "select * from Client_Notes WHERE client_id='$ClientID'",
			"sql_vars" => array("select", "ClientID"),
			"default_sort" => array("input_date", "DESC"),

			"table_links" => array(
									//Link Item          URL VAR  VAR Value     Link To
									"note" 	=> array("QSVar" => "NoteID", "QSVal" => "note_id", "Title" => "View this note", "Target" => MODULE_URL . "clients/note_view.php?select=list")
						),
			"fields" => array(
				"Entered Date"		=> "input_date",
				"Note" 				=> "note",
				"Entered By"		=> "user_input_name"
						)
			),
	"list_all" 	=> array(
			"sql" => "select * from Client_Notes",
			"sql_vars" => array("select", "ClientID"),
			"default_sort" => array("input_date", "DESC"),

			"table_links" => array(
									//Link Item          URL VAR  VAR Value     Link To
									"note" 	=> array("QSVar" => "NoteID", "QSVal" => "note_id", "Title" => "View this note", "Target" => MODULE_URL . "clients/note_view.php?select=list_all"),
									"client_name" 	=> array("QSVar" => "ClientID", "QSVal" => "client_id", "Title" => "View this note", "Target" => MODULE_URL . "clients/client_index.php?link=client_edit.php")

						),
			"fields" => array(
				"Entered Date"		=> "input_date",
				"Note" 				=> "note",
				"Client Name" 		=> "client_name",
				"Entered By"		=> "user_input_name"
						)
			)
);


page_header("Client Notes");

echo '<h1>Client Notes</h1>';

	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields[$request], &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';
	$pager->trim = true;
	$pager->trim_length = '30';

	echo $pager->Render($rows_per_page);
	$db->Disconnect();

echo page_footer();

?>

</body>
</html>