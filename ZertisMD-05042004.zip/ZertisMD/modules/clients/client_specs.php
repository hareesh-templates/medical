<?
require_once('../../setup.php');
session_start();
Access_Check('Add Client');
RequireLogin();


if($_REQUEST[msg])
	$msg =$_REQUEST['msg'];

page_header("Edit Client");


function Client_Type ($ar) {

	$a = '<select name="Type">';
	$a .= '<option value="Prospective Client" ' .($ar[Type] == 'Prospective Client' ? 'SELECTED' : '') . '>Prospective Client</option>';
	$a .= '<option value="Current Client" ' .($ar[Type] == 'Current Client' ? 'SELECTED' : '') . '>Current Client</option>';
	$a .= '</select>';
return $a;
}


function Edit_Form($ar) {
$Type = Client_Type($ar);
$CSS = css();
GLOBAL $msg;
$IMAGE_DIR = IMAGE_DIR;
$state_list = state_list($ar[Client_Address_State]);
return <<< EOF
<html>
<head>
$CSS
</head>
<body>

	<h1 align="Center">Editing $ar[Client_Name]</h1>
	<form action="client_specs_action.php?ClientID=$ar[Client_Id]" method="post" name="Edit">
	<table cellspacing="2" border="0">

			<tr>
				<td colspan="2" align="center"><h2 align="center">Products and Services</h2><br /><div class="Error"> $msg </div></td></tr>

			<tr>
				<td>Client Account Number: </td>
				<td class="FormField"><b>$ar[Client_Id]</b></td></tr>

			<tr>
				<td>Client Name: </td>
				<td><input type="text" name="Client_Name" value="$ar[Client_Name]" /></td></tr>



	<tr><td colspan="2" align="center"><br />
	<input type="image" src="$IMAGE_DIR/Save.png" name="btnEditClient" value="Edit Client" />

	</form>

	</table>
EOF;
}


if($_REQUEST['ClientID']) {
	$db =& dbconnect();
	$rec = $db->GetRow("SELECT * FROM Clients WHERE Client_Id='$_REQUEST[ClientID]'");
	echo Edit_Form($rec);
	$db->Disconnect();
} else {
	echo '<br /><br /><div class="Error">ERROR: No Client Specified</div>';
}


?>

</body>
</head>