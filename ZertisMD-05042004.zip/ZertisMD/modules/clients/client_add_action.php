<?
require 'lib/patient.inc.php';

Access_Check('Add Client');
RequireLogin();

function ValidateForm() {
	if(!$_POST['Client_Name'])
		return "NO COMPANY NAME WAS PROVIDED.";
	if(!$_POST['Client_Primary_Contact'])
		return "NO PRIMARY CONTACT WAS GIVEN.";
	return '';
}

function AddClient() {
	GLOBAL $id;

	$db =& dbconnect();
	$count = $db->GetOne("SELECT COUNT(*) FROM Clients WHERE Client_Name='$_POST[Client_Name]'");
	if($count)
		return "The Company Name <b><i>$_POST[Client_Name]</i></b> is already taken.";

	$sql = "INSERT INTO Clients (Client_Id, Client_Name, Client_Phone, Client_Primary_Contact, Client_Fax, Client_Address_1,
		Client_Address_2, Client_Address_City, Client_Address_Zip, Client_Address_State)
		VALUES('', '$_POST[Client_Name]', '$_POST[Client_Phone]', '$_POST[Client_Primary_Contact]', '$_POST[Client_Fax]', '$_POST[Client_Address_1]',
		'$_POST[Client_Address_2]', '$_POST[Client_Address_City]', '$_POST[Client_Address_Zip]', '$_POST[Client_Address_State]')";

	if(!$db->Execute($sql))
		return "Could not add Client: Please contact the Administrator." . mysql_error();
	$id = $db->Insert_ID();

    $today = date("Y-m-d g:i:s A");
    $sql = "INSERT INTO admin_logs (id, user_type, user_name, action, action_date) VALUES ('$_SESSION[UserID]', '$_SESSION[SecureLevel]', '$_SESSION[Login]', 'Added Client <i><b>$_POST[Client_Name]</b></i> to database.', '$today')";
    if(!$db->Execute($sql))
        return "Could not add Log File:" . mysql_error();

	$db->Disconnect();
	$Action = 'Added Client: ' . $_POST[Client_Name];
	MakeLog("$Action", "Added Client");

	return '';
}


if(req("btnAddClient") == "Add Client") {
	$msg = ValidateForm();
	if(!$msg)
		$msg = AddClient();
	if(!$msg) {
	header("Location: client_index.php?link=client_edit.php&ClientID=$id");
	} else {
	header("Location: client_add.php?msg=$msg");
	}
}
?>