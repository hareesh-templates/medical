<?
session_start();
include('../../setup.php');
RequireLogin();


if($_REQUEST['keywords']) {

    if(is_numeric($_REQUEST['keywords'])) {
     $search_type = 'Client_Id';
    }
	else {
	 $search_type = 'name';
	}
	$keywords = $_REQUEST['keywords'];


	header ("location: search.php?keywords=$keywords&search_type=$search_type");
}
else
	header ("location: search.php");
?>