<?php
//Perform Search

session_start();
require_once('../../setup.php');
RequireLogin();
include_once('adodb/adodb-pager.inc.php');
require_once(LIB_DIR . '/classes/SmartPager.class.php');

$keywords = '';
if ( isset ($_REQUEST[keywords]))
	$keywords 	= $_REQUEST[keywords];

$search_type = '';
if (isset ($_REQUEST[search_type]))
	$search_type = $_REQUEST[search_type];

$data_fields = array(

"Client_Id" 	=> array(
		"sql" => "SELECT * from Clients WHERE Client_Phone LIKE '%%$keywords%%' OR Client_Id LIKE '%%$keywords%%' ",
		"sql_vars" => array("keywords", "search_type"),
		"default_sort" => array("Client_Id", "ASC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Products and Services", "Target" => "client_index.php?link=client_specs.php"),
								"Client_Id" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_properties.png", "Title" => "Edit this Clients Account Properties", "Target" => "client_index.php?link=client_edit.php")
						),
		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
					)
	),

"name" 	=> array(
		"sql" => "SELECT * from Clients WHERE Client_Name LIKE '%%$keywords%%' OR Client_Primary_Contact LIKE '%%$keywords%%' OR Client_Secondary_Contact LIKE '%%$keywords%%'",
		"sql_vars" => array("keywords", "search_type"),
		"default_sort" => array("Client_Id", "ASC"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Client_Name" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_edit.png", "Title" => "Products and Services", "Target" => "client_index.php?link=client_specs.php"),
								"Client_Id" 	=> array("QSVar" => "ClientID", "QSVal" => "Client_Id", "Image" => IMAGE_DIR . "/button_properties.png", "Title" => "Edit this Clients Account Properties", "Target" => "client_index.php?link=client_edit.php")
						),
		"fields" => array(
			"Account Number"	=> "Client_Id",
			"Name" 				=> "Client_Name",
			"Contact"			=> "Client_Primary_Contact",
			"Contact 2"			=> "Client_Secondary_Contact",
			"Phone" 			=> "Client_Phone"
						)
				)
);


page_header("Search");
echo '<h1>Search</h1>';

if($keywords != '' && $search_type != '') {
	$db =& dbconnect();
	$pager = new SmartPager($db, $data_fields[$search_type], &$_REQUEST);

	$pager->first = '<img src="' . IMAGE_DIR . '/Begin.png" alt="FIRST" align="middle" border="0">';
	$pager->last = '<img src="' . IMAGE_DIR . '/End.png" alt="LAST" align="middle" border="0">';
    $pager->next = '<img src="' . IMAGE_DIR . '/Right.png" alt="NEXT" align="middle" border="0">';
	$pager->prev = '<img src="' . IMAGE_DIR . '/Left.png" alt="PREV" align="middle" border="0">';
	$pager->asc_icon = '<img src="' . IMAGE_DIR . '/Down.png" alt="v" align="middle" border="0">';
	$pager->desc_icon = '<img src="' . IMAGE_DIR . '/Up.png" alt="^" align="middle" border="0">';

	echo "<h2>Searching For: $_REQUEST[search_for]</h2>";

	echo $pager->Render($rows_per_page);
	$db->Disconnect();
}
$CSS = CSS();
?>
<html>
<head>
<?=$CSS?>
</head>
<body>
<table align="center"><tr>
		<td nowrap="nowrap" align="right"><img src="graphics/qsearch.gif" alt="Search: " /> </td>
<form action="search_action.php" method="post">
		<td align="center">
		<input type="text" style="font-size: .8em; width: 190px" name="keywords" value="<?=$_REQUEST[keywords]?>" onFocus="this.value=''" />
		</td></tr>
		<tr><td colspan="2" align="center"><br /><input type="submit" value="Search" /></td></form>
</tr></table>

<?



echo page_footer();



?>
</body>
</html>