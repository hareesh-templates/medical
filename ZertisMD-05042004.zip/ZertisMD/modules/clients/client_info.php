<?

require_once('../../setup.php');
session_start();
Access_Check('All Clients');
RequireLogin();

function List_Info ($rec, $LINK, $LINK2, $LINK3, $LINK4) {
$CSS = css();

return <<< EOF
<html>
<head>
$CSS
<script Language="JavaScript">

	function add_note(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,status=0,menubar=0,resizable=0,width=550,height=125,left = 340,top = 412');");
	}
</script>

</head>
<body>

	<table border="0" width="99%" align="center" cellspacing="0" cellpadding="1">
	<tr>
		<td class="other">Client Name: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Name]
		</td>
	</tr>


	<tr>
		<td class="other">Account Number: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Id]
		</td>
	</tr>


	<tr>
		<td class="other">Client Type: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Type]
		</td>
	</tr>


	<tr>
		<td class="other">Phone: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Phone]
		</td>
	</tr>


	<tr>
		<td class="other">Primary Contact Name: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Primary_Contact]
		</td>
	</tr>


	<tr>
		<td class="other">Secondary Contact Name: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Secondary_Contact]
		</td>
	</tr>



	<tr>
		<td class="other">Fax Number: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Fax]
		</td>
	</tr>


	<tr>
		<td class="other">Address: </td>
	</tr>
	<tr>
		<td class="other2">
			$rec[Client_Address_1] <br />
			$rec[Client_Address_2] <br />
			$rec[Client_Address_City] &nbsp;$rec[Client_Address_State], &nbsp;$rec[Client_Address_Zip]
		</td>

	</tr>
		<tr>
			<td class="other" align="center"><br />
			$LINK
			<br />
			<br />
			$LINK2
			<br />
			<br />
			$LINK3
			<br />
			<br />
			$LINK4
			</td>
	</tr>

	</table>

EOF;
}



$ID = $_REQUEST[ClientID] or die("No id");

if(Access_Check('All Clients')) {
	$LINK = '<a href="client_index.php?link=client_edit.php&ClientID=';
	$LINK .= $_REQUEST[ClientID];
	$LINK .= '" target="Main2">';
	$LINK .= '<img src="' . IMAGE_DIR . 'configure.png" border="0"><br />Edit Account Info</a>';
}

if(Access_Check('Add Client')) {

	$LINK2 = '<a href="client_index.php?link=client_specs.php&ClientID=';
	$LINK2 .= $_REQUEST[ClientID];
	$LINK2 .= '" target="Main2">';
	$LINK2 .= '<img src="' . IMAGE_DIR . 'blocks.png" border="0"><br />Products and Services</a>';
}

if(Access_Check('Client Notes') == true) {

	$LINK3 = '<a href="list_notes.php?select=list&ClientID=';
	$LINK3 .= $_REQUEST[ClientID];
	$LINK3 .= '" target="rtop">';
	$LINK3 .= '<img src="' . IMAGE_DIR . 'open_book.png" border="0"><br />View Client Notes</a>';
}

	$LINK4 = "<a href=\"javascript:add_note('add_note.php?ClientID=$_REQUEST[ClientID]')\">";
	$LINK4 .= '<img src="' . IMAGE_DIR . 'new_note.png" border="0"><br />Add Note</a>';


$db =& dbconnect();

$SQL = "SELECT * FROM Clients WHERE Client_Id='$_REQUEST[ClientID]'";

$rec = $db->GetRow("$SQL");

echo List_Info($rec, $LINK, $LINK2, $LINK3, $LINK4);
$db->Disconnect();

?>

</body>
</head>