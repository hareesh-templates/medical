<?

require_once('../../setup.php');
session_start();
Access_Check('Client Notes');
RequireLogin();




$ID = $_REQUEST[ClientID] or die("No id");


function Add_Note_Form () {
if(!$_REQUEST[FINISH])
	$FIN = 'Cancel';
else
	$FIN = 'Close';

$CSS = css();
return <<< EOF
	<html>
	<head>
	<title>Add Client Note</title>
	</head>
	<body bgcolor="CCCCCC">

		<form action="add_note_action.php" method="post" name="add_note">
		<table border="0" align="center" cellspacing="4" cellpadding="0">
		<tr>
			<td align="center" valign="bottom" colspan="2">
				<input type="hidden" name="ClientID" value="$_REQUEST[ClientID]">
				<textarea  name="note" cols="60" rows="5"></textarea>
			</td>
		</tr>
		<tr>
			<td align="right" valign="bottom" nowrap="nowrap">
				<input type="Submit" name="Submit" value="Add Note"> &nbsp;
				</form>
			</td>

			<td align="right" width="60" valign="bottom">
				<form>
				<input type="button" value="$FIN" onClick="window.close()">
				</form>
			</td>
		</tr>
		</table>
	</body>
	</html>
EOF;
};

echo Add_Note_Form();

?>