<?
session_start();
include('../../setup.php');
Access_Check('Add Client');
RequireLogin();


$id = $_REQUEST["ClientID"];
//-------------------------------------------------------
function ValidateForm() {
	if(!$_POST['Client_Name'])
		return "NO COMPANY NAME WAS PROVIDED.";
	if(!$_POST['Client_Phone'])
		return "A PHONE NUMBER MUST BE PROVIDED.";
	if(!$_POST['Client_Primary_Contact'])
		return "NO PRIMARY CONTACT WAS GIVEN.";
	return '';
}
//-------------------------------------------------------
function EditClient() {
GLOBAL $id;
	$db =& dbconnect();
	$count = $db->GetOne("SELECT COUNT(*) FROM Clients WHERE Client_Name='$_POST[Client_Name]'");
	if($count > 1)
		return "The Company Name <b><i>$_POST[Client_Name]</i></b> is already taken.";

	$rs = $db->Execute("SELECT * FROM Clients WHERE Client_Id='$id'");
		if(!$rs)
	    	die($db->ErrorMsg());

	$isql = $db->GetUpdateSQL($rs, $_POST);
		if(!$isql)
			die($db->ErrorMsg());

		if(!$db->Execute($isql))
			die($db->ErrorMsg());


    $today = date("Y-m-d g:i:s A");
    $sql = "INSERT INTO admin_logs (id, user_type, user_name, action, action_date) VALUES ('$_SESSION[UserID]', '$_SESSION[SecureLevel]', '$_SESSION[Login]', 'Edited Client Records For: <i><b>$_POST[Client_Name]</b></i>.', '$today')";
    if(!$db->Execute($sql))
        return "Could not add Log File:" . mysql_error();
	
	$Action = 'Edited Client: ' . $_POST[Client_Name];
	MakeLog("$Action", "Edited Client");

	return '';
}
//-------------------------------------------------------
if(req("btnEditClient") == "Edit Client") {
	$msg = ValidateForm();
	if(!$msg)
		$msg = EditClient();
	if(!$msg) {
	header("Location: client_edit.php?ClientID=$id");
	} else {
	header("Location: client_edit.php?ClientID=$id&msg=$msg");
	}
}
?>