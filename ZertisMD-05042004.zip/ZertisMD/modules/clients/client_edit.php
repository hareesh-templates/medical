<?
session_start();
include('../../setup.php');
Access_Check('Add Client');
RequireLogin();


if($_REQUEST[msg])
	$msg =$_REQUEST['msg'];

page_header("Edit Client");


function Client_Type ($ar) {

	$a = '<select name="Type">';
	$a .= '<option value="Prospective Client" ' .($ar[Type] == 'Prospective Client' ? 'SELECTED' : '') . '>Prospective Client</option>';
	$a .= '<option value="Current Client" ' .($ar[Type] == 'Current Client' ? 'SELECTED' : '') . '>Current Client</option>';
	$a .= '</select>';
return $a;
}


function Edit_Form($ar) {
$Type = Client_Type($ar);
$CSS = css();
GLOBAL $msg;
$IMAGE_DIR = IMAGE_DIR;
$state_list = state_list($ar[Client_Address_State]);
return <<< EOF
<html>
<head>
$CSS
</head>
<body>

	<h1 align="Center">Edit Client</h1>
	<form action="client_edit_action.php?ClientID=$ar[Client_Id]" method="post" name="Edit">
	<table cellspacing="2" border="0">

			<tr>
				<td colspan="2" align="center"><h2 align="center">General</h2><br /><div class="Error"> $msg </div></td></tr>

			<tr>
				<td>Client Account Number: </td>
				<td class="FormField"><b>$ar[Client_Id]</b></td></tr>

			<tr>
				<td>Client Name: </td>
				<td><input type="text" name="Client_Name" value="$ar[Client_Name]" /></td></tr>


			<tr>
				<td>Client Type: </td>
				<td> $Type </td></tr>


			<tr>
				<td>Client Phone: </td>
				<td><input type="text" name="Client_Phone" value="$ar[Client_Phone]" /></td></tr>


			<tr>
				<td>Client Primary Contact: </td>
				<td><input type="text" size="20" maxlength="30" name="Client_Primary_Contact" value="$ar[Client_Primary_Contact]" /></td></tr>

			<tr>
				<td>Client Secondary Contact: </td>
				<td><input type="text" size="20" maxlength="30" name="Client_Secondary_Contact" value="$ar[Client_Secondary_Contact]" /></td></tr>


			<tr>
				<td>Client Fax: </td>
				<td><input type="text" size="20" maxlength="30" name="Client_Fax" value="$ar[Client_Fax]" /></td></tr>



			<tr>
				<td colspan="2" class="FormCaption"><br /><hr width="50%" /><br />Client Address<br /></td></tr>

			<tr>
				<td>Address Line 1: </td><td><input type="text" size="30" maxlength="50" name="Client_Address_1" value="$ar[Client_Address_1]" /></td></tr>

			<tr>
				<td>Address Line 2: </td><td><input type="text" size="30" maxlength="50" name="Client_Address_2" value="$ar[Client_Address_2]" /></td></tr>

			<tr>
				<td>City: </td><td><input type="text" size="20" maxlength="30" name="Client_Address_City" value="$ar[Client_Address_City]" /></td></tr>

			<tr>
				<td>Zip: </td><td><input type="text" size="12" maxlength="15" name="Client_Address_Zip" value="$ar[Client_Address_Zip]" /></td></tr>

			<tr>
				<td>State: </td><td><select name="Client_Address_State">$state_list</select></td></tr>

	<tr><td colspan="2" align="center"><br />
	<input type="image" src="$IMAGE_DIR/Save.png" name="btnEditClient" value="Edit Client" />

	</form>

	</table>
EOF;
}


if($_REQUEST['ClientID']) {
	$db =& dbconnect();
	$rec = $db->GetRow("SELECT * FROM Clients WHERE Client_Id='$_REQUEST[ClientID]'");
	echo Edit_Form($rec);
	$db->Disconnect();
} else {
	echo '<br /><br /><div class="Error">ERROR: No Client Specified</div>';
}


?>

</body>
</head>