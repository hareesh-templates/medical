<?
session_start();
include('../../setup.php');
RequireLogin();

if($_REQUEST[link])
	$Link = $_REQUEST[link];
else
	$Link = 'client_specs.php';
$smarty = GetSmarty();
$smarty->assign('LINK', $Link);
$smarty->assign('CLIENTID', $_REQUEST[ClientID]);
$smarty->display('client_index.tpl');
?>