<?
require_once('../../setup.php');
session_start();
Access_Check('Add Client');
RequireLogin();



if($_REQUEST[msg])
	$$msg =$_REQUEST[msg];

page_header("Add Client");

?>

<html>
<head>

<?=css()?>

</head>

<body>


<h1 align="Center">New Client</h1>
<form action="client_add_action.php" method="post" name="Add">
<table cellspacing="2" border="0">

		<tr>
			<td colspan="2" align="center"><h2 align="center">General</h2><br /><div class="Error"><?=$msg?></div></td></tr>

		<tr>
			<td>Client Name: </td>
			<td><input type="text" name="Client_Name" /></td></tr>

		<tr>
			<td>Client Phone: </td>
			<td><input type="text" name="Client_Phone" /></td></tr>


		<tr>
			<td>Client Primary Contact: </td>
			<td><input type="text" size="20" maxlength="30" name="Client_Primary_Contact" /></td></tr>


			<tr>
				<td>Client Fax: </td>
				<td><input type="text" size="20" maxlength="30" name="Client_Fax" /></td></tr>


		<tr>
			<td colspan="2" class="FormCaption"><br /><hr width="50%" /><br />Client Address<br /></td></tr>

		<tr>
			<td>Address Line 1: </td><td><input type="text" size="30" maxlength="50" name="Client_Address_1" /></td></tr>

		<tr>
			<td>Address Line 2: </td><td><input type="text" size="30" maxlength="50" name="Client_Address_2" /></td></tr>

		<tr>
			<td>City: </td><td><input type="text" size="20" maxlength="30" name="Client_Address_City" /></td></tr>

		<tr>
			<td>Zip: </td><td><input type="text" size="12" maxlength="15" name="Client_Address_Zip" /></td></tr>

		<tr>
			<td>State: </td><td><select name="Client_Address_State"><? echo state_list(); ?></select></td></tr>

<tr><td colspan="2" align="center"><br />
<input type="image" src="<?=IMAGE_DIR?>/Save.png" name="btnAddClient" value="Add Client" />
</form>

</table>

<?

page_footer();



?>
</body>
</html>