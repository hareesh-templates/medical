<?
require_once('../../setup.php');
session_start();
Access_Check('Client Notes');
RequireLogin();

$PID = $_REQUEST[ClientID] or die("No id");
	$db =& dbconnect();
	$sql = "SELECT Client_Name FROM Clients WHERE Client_Id ='$ClientID'";

	$record = $db->GetRow($sql) OR die(mysql_error());

$today = date("Y/m/d, H:i:s");

$SQL2 = "INSERT INTO Client_Notes (client_id, client_name, note, input_date, reminder_date, followup_date, user_input_id, user_input_name)
		VALUES ('$_REQUEST[ClientID]', '$record[Client_Name]', '$_POST[note]', '$today', '', '', '$_SESSION[UserID]', '$_SESSION[Login]')";

	if(!$db->Execute("$SQL2")) {
		echo "Could not add Note: Please contact the Administrator." . mysql_error() . $SQL2;
	}
	else {
		$Action = "Added Note for Client: " . $PNAME;
		MakeLog("$Action", "Added Note");
		header("Location: add_note.php?ClientID=" . $_REQUEST[ClientID] . "&FINISH=1");
		}

	$db->Disconnect();

?>