<?
require_once('../../setup.php');
session_start();
Access_Check('Client Notes');
RequireLogin();

$ID = $_REQUEST[NoteID] or die("No id");
$select = $_REQUEST[select];
?>

<html>
<head>

<?=css()?>

</head>

<body>

<?
$sql = "select * from Client_Notes WHERE note_id='$ID'";
	$db =& dbconnect();
	$record = $db->GetRow($sql);
	$db->Disconnect();

page_header("Viewing Note");

echo '<h1>Viewing Note for: <i>' . $record[client_name] . '</i></h1>';
?>
<br />
<a href="list_notes.php?ClientID=<?=$record[client_id]?>&select=<?=$select?>" class="return">&lt;--back to client notes</a><br />
<br />
<table border="1" cellspacing="0" cellpadding="4" width="98%" align="center" class="smarty_table">
<tr class="Menu_Head" align="center">
	<td nowrap="nowrap">
	Input Date: <b><?=$record[input_date]?></b>
	&nbsp; &nbsp; &nbsp;
	Input By: <b><?=$record[user_input_name]?></b>
	&nbsp; &nbsp; &nbsp;
	Followup Date: <b><?=$record[followup_date]?></b>
	&nbsp; &nbsp; &nbsp;
	Followup Date: <b><?=$record[reminder_date]?></b>
	</td>
</tr>

<tr class="Row0">
	<td>
	<?=$record[note]?>
	</td>
</tr>
</table>
<br />
<br />
<a href="list_notes.php?ClientID=<?=$record[client_id]?>&select=<?=$select?>" class="return">&lt;--back to client notes</a><br />
<?
page_footer();
?>



</body>
</html>