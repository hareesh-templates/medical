<?php
include_once('../../setup.php');
session_start();
Access_Check('Progress');
RequireLogin();

$data_fields = array(


"list_all" 	=> array(
		"sql" => "SELECT
					Work_Day.id,
					Work_Day.Description,
					Work_Day.Comment,
					StartTime AS Start,
					EndTime AS End,
					Users.Full_name
					FROM Work_Day
					LEFT JOIN
					Users ON (
					Users.UserID = Work_Day.UserID
					)",
		"default_sort" => array("time_added", "ASC"),
		"sql_vars" => array("select"),
		"table_links" => array(
								//Link Item          URL VAR  VAR Value     Link To
								"Description" 		=> array("QSVar" => "DID", "QSVal" => "id", "Title" => "View this Note", "Target" => "view_progress.php")

						),
		"fields" => array(
			"Name"				=> "Full_name",
			"Started" 			=> "Start",
			"Description" 		=> "Description",
			"Ended"				=> "End",
			"Comment"			=> "Comment",
		)
	)
);
page_header("View Progress");
?>
<html>
<head>
<?=CSS()?>
</head>
<body>

<h1>Listing Progress for All Users</h1>
<hr>
<div align="center">
<a href="add_progress.php">Add Progress Note</a>
</div>
<?
zertis_pager( $data_fields['list_all'], &$_REQUEST );
echo page_footer();
?>
</body>
</html>