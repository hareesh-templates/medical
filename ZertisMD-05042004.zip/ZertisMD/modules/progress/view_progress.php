<?
include_once('../../setup.php');
session_start();
Access_Check('Progress');
RequireLogin();

$DID = @$_REQUEST[DID] or die('No ID');
?>

<html>
<head>
	<?=css()?>
</head>
<body>
<?
$sql = "SELECT
		Work_Day.Description,
		Work_Day.Comment,
		StartTime AS Start,
		EndTime AS End,
		Users.Full_name
		FROM Work_Day
		LEFT JOIN
		Users ON (
		Users.UserID = Work_Day.UserID
		)
		WHERE id='$DID'
		";

$db =& dbconnect();
$record = $db->GetRow($sql);
$db->Disconnect();
page_header("Viewing Note");

echo '<h1>Viewing Note for: <i>' . $record['Full_name'] . '</i></h1>';
?>
<br />
<a href="list_progress.php" class="return">&lt;--back to progress notes</a><br />
<br />
<table border="1" cellspacing="0" cellpadding="4" width="98%" align="center" class="smarty_table">
<tr class="Menu_Head" align="center">
	<td nowrap="nowrap">
	Start Time: <b><?=$record[StartTime]?></b>
	&nbsp; &nbsp; &nbsp;
	End Time: <b><?=$record[EndTime]?></b>
	&nbsp; &nbsp; &nbsp;
	Input By: <b><?=$record[Full_name]?></b>
	</td>
</tr>

<tr class="Row0">
	<td>
	<?=$record['Description']?>
	</td>
</tr>
<tr class="Row0">
	<td>
	<?=$record['Commet']?>
	</td>
</tr>
</table>
<br />
<br />
<a href="list_progress.php" class="return">&lt;--back to progress notes</a><br />
<?php
page_footer();
?>
</body>
</html>