<?php
include_once('../../setup.php');
session_start();
Access_Check('Progress');
RequireLogin();


function ValidateForm() {
	if(!$_POST['Description'])
		return "NO DESCRIPTION WAS PROVIDED.<br /><br />";
	return '';
}

function AddProgress() {

	$db =& dbconnect();
	$sql = "INSERT INTO Work_Day
	(id, UserID, Description, StartTime, EndTime, Comment, time_added)
	VALUES
	('', '$_SESSION[UserID]', '$_POST[Description]', '$_POST[StartTime]00', '$_POST[EndTime]00', '$_POST[Comment]', NOW() )";

	if(!$db->Execute($sql))
		return "Could not add Progress Note: Please contact the Administrator." . mysql_error() . "<br /><br />";
	$id = $db->Insert_ID();


	$db->Disconnect();
	$Action = 'Added Progress Note: ' . $_POST[Description];
	MakeLog("$Action", "Progress Note");

	return '';

}




if(req("bttnSubmit") == "Submit") {
	$msg = ValidateForm();
	if(!$msg)
		$msg = AddProgress();
	if(!$msg)
		header("Location: list_progress.php");
}


function show () {
GLOBAL $msg;

$CSS = CSS();
$Start = ( isset ($_POST[StartTime]) ? $_POST[StartTime] : '00:00' );
$End = ( isset ($_POST[EndTime]) ? $_POST[EndTime] : '00:00' );
$Description = ( isset ($_POST[Description]) ? $_POST[Description] : '' );
$Comment = ( isset ($_POST[Comment]) ? $_POST[Comment] : '' );
return <<< OEF

<html>
<head>
$CSS
</head>

<body>
<br />
<br />

<h1 align="center">Add a Progress Note</h1>
<br />
<form action="add_progress.php" name="Progress" method="post">
<table style="border: 0px;" align="center">
<tr>
	<td colspan="2" class="Error">
	$msg
	</td>
</tr>
<tr>
	<td>
	Start Time
	</td>
	<td>
	<input type="text" name="StartTime" value="$Start" onClick="javascript:value=''">
	</td>
</tr>
<tr>
	<td>
	End Time
	</td>
	<td>
	<input type="text" name="EndTime" value="$End" onClick="javascript:value=''">
	</td>
</tr>

<tr>
	<td>
	Description
	</td>
	<td>
	<textarea cols="50" rows="5" name="Description">$Description</textarea>
	</td>
</tr>

<tr>
	<td>
	Comment
	</td>
	<td>
	<textarea cols="50" name="Comment">$Comment</textarea>
	</td>
</tr>
<tr>
	<td align="center" colspan="2">
	<input type="Submit" name="bttnSubmit" value="Submit">
	</td>
</tr>
</table>

</forms>
</body>
</html>
OEF;
}

echo show();

?>