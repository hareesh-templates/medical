<?php
/* Global page header and footer. 
 * DO NOT USE THIS FILE. It's use is depreciated.
 */
function page_header($title) {
	echo '<div align="center">';
}

function page_footer()	{
	echo '</div>';
}
?>