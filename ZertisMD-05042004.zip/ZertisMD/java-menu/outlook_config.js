

// ---------------------------------------------------------------------------
// Example of howto: use Outlook Like Bar
// ---------------------------------------------------------------------------


  //create OutlookBar-Object:
  //              Name
  //              x-position
  //              y-Position
  //              width
  //              height
  //              background-color
  //              page background-color (needed for OP5)
  //(screenSize object is created by 'crossbrowser.js')
  //

  var o = new createOutlookBar('Bar',0,0,screenSize.width,screenSize.height,'#DDDDFF','#FF0000') // OutlookBar
  var p

  //create first panel..
  p = new createPanel('al','Main');

  //add buttons:
  //             image name
  //             label text
  //             onClick JavaScript code
  //


  function go_there($location) {
    parent.Main.location=$location;
  }

  p.addButton('java-menu/netm.gif','Home','go_there("index_main.php")');
  p.addButton('graphics/Forward.png','Add Client','go_there("index_main.php?link=client_add.php")');
  p.addButton('graphics/Magnify.png','Search','go_there("index_main.php?link=search.php")');
  p.addButton('graphics/p.png','List Clients','go_there("index_main.php?link=list_clients.php")');
  p.addButton('java-menu/mail.gif','Mail','go_there("http://mail.zertis.net/src/login.php")');
  o.addPanel(p);

  //create second panel...
  p = new createPanel('S','Scheduling');
  p.addButton('java-menu/mail.gif','Mail 2','alert("Mail2")');
  p.addButton('java-menu/peditor.gif','Personal<BR>Editor','alert("Personal Editor")');
  p.addButton('java-menu/word.gif','Projekte','alert("Projekte")');
  p.addButton('java-menu/news.gif','Adresse','alert("Adresse")');
  p.addButton('java-menu/mail.gif','Postausgang','alert("Postausgang")');
  p.addButton('java-menu/mail.gif','Posteingang','alert("Posteingang")');
  p.addButton('java-menu/news.gif','Information aus<BR>erster Hand','alert("Infos")');
  p.addButton('java-menu/peditor.gif','Gelbe Post','alert("Gelbe Post")');
  p.addButton('java-menu/word.gif','Schreiben','alert("Schreiben")');
  o.addPanel(p);

  //create two empty panels...
  p = new createPanel('l','Leeres Panel');
  o.addPanel(p);

  p = new createPanel('l2','Leeres Panel 2');
  o.addPanel(p);

  o.draw();         //draw the Outlook Like Bar!


//-----------------------------------------------------------------------------
//functions to manage window resize
//-----------------------------------------------------------------------------
//resize OP5 (test screenSize every 100ms)

function resize_op5() {
  if (bt.op5) {
    o.showPanel(o.aktPanel);
    var s = new createPageSize();
    if ((screenSize.width!=s.width) || (screenSize.height!=s.height)) {
      screenSize=new createPageSize();
      //need setTimeout or resize on window-maximize will not work correct!
      //ben�tige das setTimeout oder das Maximieren funktioniert nicht richtig
      setTimeout("o.resize(0,0,screenSize.width,screenSize.height)",100);
    }
    setTimeout("resize_op5()",100);
  }
}

//resize IE & NS (onResize event!)
function myOnResize() {
  if (bt.ie4 || bt.ie5 || bt.ns5) {
    var s=new createPageSize();
    o.resize(0,0,s.width,s.height);
  }
  else
    if (bt.ns4) location.reload();
}

