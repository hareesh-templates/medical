
<script type="text/javascript" language="JavaScript">


function createjsDOMenu() {

  absoluteMenu1 = new jsDOMenu(70, "", "absolute");
  with (absoluteMenu1) {
    addMenuItem(new menuItem("Home", "", "?"));
    addMenuItem(new menuItem("Email", "", "http://mail.zertis.net/src/login.php"));
  }


  absoluteMenu2 = new jsDOMenu(185, "", "absolute");
  with (absoluteMenu2) {
    addMenuItem(new menuItem("Add Client", "", "?link=client_add.php"));
    addMenuItem(new menuItem("Search for a Client", "", "?link=search.php"));
    addMenuItem(new menuItem("List All Clients", "", "?link=list_clients.php"));
    addMenuItem(new menuItem("-"));
    addMenuItem(new menuItem("Add Prospective Client", "", "?link=client_add.php"));
    addMenuItem(new menuItem("Prospective Client Search", "", "?link=prospective_search.php"));
  }

  absoluteMenu3 = new jsDOMenu(185, "", "absolute");
  with (absoluteMenu3) {
    addMenuItem(new menuItem("Blank", "", "Blank"));
    addMenuItem(new menuItem("Blank", "", "Blank"));

  }


  absoluteMenu4 = new jsDOMenu(130, "", "absolute");
  with (absoluteMenu4) {
    addMenuItem(new menuItem("Your Settings", "item1", ""));
    addMenuItem(new menuItem("-"));
    addMenuItem(new menuItem(" ", "", " "));
  }



  absoluteMenu4_1 = new jsDOMenu(145, "", "absolute");
  with (absoluteMenu4_1) {
     addMenuItem(new menuItem("Change Password", "", "?link=settings.php&edit=password"));
     addMenuItem(new menuItem("Check Tasklist", "", "?link=settings.php&edit=tasks"));
     addMenuItem(new menuItem("Check Calendar", "", "?link=settings.php&edit=calendar"));
  }


  absoluteMenu5 = new jsDOMenu(200, "", "absolute");
  with (absoluteMenu5) {
    addMenuItem(new menuItem("Administrative Control Panel", "", "?link=admin.php"));
    addMenuItem(new menuItem("-"));
    addMenuItem(new menuItem("User Logs", "", "?link=usr_logs.php"));
  }


  absoluteMenu6 = new jsDOMenu(80, "", "absolute");
  with (absoluteMenu6) {
    addMenuItem(new menuItem("About", "", "javascript:Secret()"));
  }


  absoluteMenu4.items.item1.setSubMenu(absoluteMenu4_1);
;


  absoluteMenuBar = new jsDOMenuBar("absolute");
  with (absoluteMenuBar) {
    addMenuBarItem(new menuBarItem("Information", absoluteMenu1));;
    addMenuBarItem(new menuBarItem("Clients", absoluteMenu2));
    addMenuBarItem(new menuBarItem("Blank", absoluteMenu3));
    addMenuBarItem(new menuBarItem("Other", absoluteMenu4));

 <?php if($_SESSION['SecureLevel'] == '4') {
 echo '
 	addMenuBarItem(new menuBarItem("Administration", absoluteMenu5));;'; } ?>

 	addMenuBarItem(new menuBarItem("Help", absoluteMenu6));



    moveTo(360, 47);
  }
}

</script>
