/*
Default values of public properties:
allExceptFilter = new Array("A.*", 
	"BUTTON.*", 
	"IMG.*", 
	"INPUT.*", 
	"OBJECT.*", 
	"OPTION.*", 
	"SELECT.*", 
	"TEXTAREA.*");
noneExceptFilter = new Array();
menuClassName = "jsdomenudiv";
menuItemClassName = "jsdomenuitem";
menuItemClassNameOver = "jsdomenuitemover";
sepClassName = "jsdomenusep";
arrowClassName = "jsdomenuarrow";
arrowClassNameOver = "jsdomenuarrowover";
menuBorderWidth = 2;
menuBarClassName = "jsdomenubardiv";
menuBarItemClassName = "jsdomenubaritem";
menuBarItemClassNameOver = "jsdomenubaritemover";
menuBarItemClassNameClick = "jsdomenubaritemclick";
menuBarDragClassName = "jsdomenubardragdiv";
menuBarBorderWidth = 2;
*/

// Uncomment any of the following public properties to override the default value.
//var allExceptFilter = 
//var noneExceptFilter = 
//var menuClassName = 
//var menuItemClassName = 
//var menuItemClassNameOver = 
//var sepClassName = 
//var arrowClassName = 
//var arrowClassNameOver = 
//var menuBorderWidth = 
//var menuBarClassName = 
//var menuBarItemClassName = 
//var menuBarItemClassNameOver = 
//var menuBarItemClassNameClick = 
//var menuBarDragClassName = 
//var menuBarBorderWidth = 
