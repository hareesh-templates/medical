var MENU_POS0=[
// Level 0 block configuration
{
	// Item's width in pixels
	'width'      : 110,
	// Item's height in pixels
	'height'     : 22,
	// if Block Orientation is vertical
	'vertical'   : false,
	// Block outing table parameters:
	// [cellpadding, cellspacing, border]
	'table'      : [0, 0, 0],
	// Time Delay in milliseconds before subling block expands
	// after mouse pointer overs an item
	'expd_delay' : 300,
	// Style class names for the level
	'css' : {
		// Block outing table class
		'table' : ['tool_bar', 'tool_bar_hover', 'tool_bar_hover'],
		// Item inner tag style class for all item states or
		// classes for [<default state>, <hovered state>, <clicked state>]
		'inner' : ['tool_bar', 'tool_bar_hover', 'tool_bar_hover'],
		// Item outer tag style class for all item states or
		// classes for [<default state>, <hovered state>, <clicked state>]
		'outer' : ['tool_bar', '', '']
	}
},
// Level 1 block configuration
{
	'width'      : 140,
	// Vertical Offset between adjacent levels in pixels
	'block_top'  : 22,
	// Horizontal Offset between adjacent levels in pixels
	'block_left' : 0,
	'vertical'   : true,
	// block behaviour if single frame:
	// 1 - shift to the edge, 2 - flip relatively to left upper corner
	'wise_pos'   : 1,
	// Time Delay in milliseconds before menu collapses after mouse
	// pointer lefts all items
	'hide_delay' : 500,
	'css' : {
		'table' : 'background',
		'inner' : ['m0inner', '', ''],
		'outer' : ['cell', 'cell_selected', 'cell_selected']
	}
},
{
	'block_top'  : 0,
	'block_left' : 150,
}
	//Subling level configurations are inherited from level 2
// Level 2 block configuration is inherited from level 1
]
