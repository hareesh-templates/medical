<?php   
//load the database configuration first.
require_once("config.php");
require_once("function.php");
require_once("session.php");
require_once("accounts.php");
require_once("autonumbers.php");  
require_once("patients.php");  
require_once("currency.php");  
require_once("discount.php");  
require_once("invoicing.php");  
require_once("stocks.php");  
// require_once("payment.php");  
require_once("services.php");  
require_once("suplier.php");  
require_once("tax.php");    
require_once("units.php");  
require_once("validation.php");  
  

require_once("database.php");
?>