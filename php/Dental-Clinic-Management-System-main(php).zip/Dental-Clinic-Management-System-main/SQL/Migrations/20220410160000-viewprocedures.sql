-- Displays the type of procedures available

SELECT * FROM Procedure_codes; 