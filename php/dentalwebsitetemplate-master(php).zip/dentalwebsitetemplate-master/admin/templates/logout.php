<?php session_destroy(); ?>

<?php
    echo "<script>location='../../index.php'</script>";
    
?>