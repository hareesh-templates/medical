<!-- <div class="container services_container">
    <h2 class="text-center this services_header">Our Services</h2>
    <!-- //IMPORT FONT AWESOME    -->
    <!-- <div class="row">
        <div class="col">
            <div class="card one first_card all_card" style="width: 18rem;">
                <i class="fas fa-ambulance fa-3x text-center"></i>
            <div class="card-body one_body">
            <h5 class="card-title text-center service_title">Surgical Dentistry</h5>
            <h6 class="card-subtitle text-center service_desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo omnis veniam animi reiciendis quod deserunt, totam vitae quas, fugit archite</h6>
            <a href="#" class="card-link service_links">See All Services</a>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card two first_card all_card" style="width: 18rem;">
            <i class="fas fa-3x text-center fa-tooth"></i>
            <div class="card-body two_body">
            <h5 class="card-title text-center service_title">General Dentistry</h5>
            <h6 id="two_desc" class="card-subtitle text-center service_desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo omnis veniam animi reiciendis quod deserunt, totam vitae quas, fugit archite</h6>
            <a href="#" class="card-link text-center service_links">See All Services</a>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card three first_card all_card third_card" style="width: 18rem;">
            <i class="fas fa-syringe fa-3x text-center"></i>
            <div class="card-body three_body">
            <h5 class="card-title text-center service_title">Spa</h5>
            <h6 class="card-subtitle text-center service_desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo omnis veniam animi reiciendis quod deserunt, totam vitae quas, fugit archite</h6>
            <a href="#" class="card-link text-center service_links">See All Services</a>
            </div>
            </div>
            </div>
    </div>
</div> 
-->

<section class="services_container" id="services">
    <div class="services_flex1">
        <div class="services_flex1_part_one">
            
            <h2>Surgical Dentistry</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium totam iste neque, velit dolorum enim corrupti perspiciatis asperiores reprehenderit non! Ut, praesentium impedit! Pariatur voluptatum sequi dolores vel odit. Labore.</p>
       
        </div>
        <div class="services_image_one_container">
            
        </div>
    </div>


    <div class="services_grid2">
        <div class="services_image_two_container">
            
        </div>

        <div class="services_grid2_part_one">
            <h2>General Dentistry</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium totam iste neque, velit dolorum enim corrupti perspiciatis asperiores reprehenderit non! Ut, praesentium impedit! Pariatur voluptatum sequi dolores vel odit. Labore.</p>
       
        </div>

    </div>
            

       


        
    <div class="services_grid3">
        <div class="services_grid3_part_one">
        <h2>Cosmetics & Spa</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium totam iste neque, velit dolorum enim corrupti perspiciatis asperiores reprehenderit non! Ut, praesentium impedit! Pariatur voluptatum sequi dolores vel odit. Labore.</p>
        </div>
        <div class="services_image_three_container">
            
        </div>
    </div>


</section>