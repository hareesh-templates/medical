

<div class="map_flex_container">
    <div class="flex1">
    <h2> <b> Office #1 </b> </h2>

<h3> <b> Address: </b> 577 Franklinville Rd <br> South Harrison Township, New Jersey, 08076 </h3>

<a href="tel:856-661-9191"> <b> Phone: </b> +1 347-644-3702 </a>



</h4>
    </div> 


<div class="flex2">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3058.149947404807!2d-75.06517488440709!3d39.960400091189136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c6c98993d15ae9%3A0x85bf63ec9aab8f88!2sA%20Z%20Dental!5e0!3m2!1sen!2s!4v1587577478022!5m2!1sen!2s" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>


    <div class="flex3">
    <h2> <b> Office #2 </b> </h2>

    <h3> <b> Address: </b> 577 Franklinville Rd <br> South Harrison Township, New Jersey, 08076 </h3>

<a href="tel:856-661-9191"> <b> Phone: </b> +1 347-644-3702 </a>



</h4>
    </div>



  
    <div class="flex4">
    
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3065.206283446899!2d-75.06945368441063!3d39.802364400697016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c6d18d27e510ef%3A0x12d0899f91e8ee74!2sA%20Z%20Dental%20%26%20Spa!5e0!3m2!1sen!2s!4v1587573248585!5m2!1sen!2s" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>




   
</div>


