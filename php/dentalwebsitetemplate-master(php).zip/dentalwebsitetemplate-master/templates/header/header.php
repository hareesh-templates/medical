<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
    <link rel="stylesheet" href="bootstrap.min.css">

    <link rel="stylesheet" href="../../static/css/styles.css">

    <link rel="stylesheet" href="templates/header/vid.css">

    <link rel="stylesheet" href="templates/header/about.css">

   
    <link rel="stylesheet" href="twentytwenty-master/css/twentytwenty.css" type="text/css" media="screen" />


    <link rel="stylesheet" href="templates/services/services.css">

    <link rel="stylesheet" href="templates/services/test.css">

    <script src="https://kit.fontawesome.com/0047a3fc2c.js" crossorigin="anonymous"></script>

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <link rel="stylesheet" href="templates/footer/footer.css">



    <link rel="stylesheet" href="templates/header/slide.css">


    <link rel="stylesheet" href="templates/directions/map.css">
    <link rel="stylesheet" href="nav.css">
    
    <link href= "./request.css" rel= "stylesheet">
    
    <link rel="stylesheet" href="static/css/responsive.css">

    <title>Az Dental Spa</title>



    <style>
        
    </style>

</head>

<header>

      
