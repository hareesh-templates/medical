<header class="video_header">

  <div class="overlay"></div>

  <video playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">

    <source src="templates/header/vid1.mp4" type="video/mp4">

  </video>

  <div class="container h-100">

    <div class="d-flex text-center h-100">

      <div class="my-auto w-100 text-white">

        <h1 class="display-1 big_intro_text">Dental Name</h1>

        <h2 class="motto">Insert Motto Here</h2>
        <div class="button_cont" align="center"><a class="example_e" href="appointments/request/request.php" rel="nofollow noopener">
          
        Request An Appointment
      
        </a></div>

      </div>

    </div>

  </div>
  </div> 
  
</header>

 