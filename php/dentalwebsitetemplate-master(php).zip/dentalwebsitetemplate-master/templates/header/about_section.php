<!-- <section class=" container about_section_container">
    <h1 class="about_intro this text-center">Dentist in New Jersey</h1>
    <div class="flex_about_container">
        <div class="card who_card">
        <h3>Who is Dr.Az</h3>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem consectetur officia quaerat error in porro, itaque voluptatibus. Eligendi, 
            officia officiis! Aspernatur aperiam alias commodi, rerum e
            a consequatur nemo culpa velit?</p>

        </div>
        <div class="card story_card">
            <h3>Story Of Az Dental</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum rerum cumque molestias exercitationem numquam nihil vitae autem sunt minus necessitatibus
                 dolore natus, reprehenderit, commodi iure deleniti voluptatibus 
                 inventore velit recusandae.</p>
        </div>
    </div>
    <div class="image_container"></div>
</section> -->

<!-- <section class="about_container"> -->
            <!-- <h1 class="about_us_intro this">About This Project</h1>
            <div class="article1_container">
                <h6 class="who_is_dr_az">How Was it made</h6>
                <p class="dr_az_desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia atque quis nihil natus ab q
                    uisquam quod tenetur eos, odio, quibusdam d
                    olorem praesentium minima nisi, quaerat laboriosam! Totam laboriosam provident a
                    periam? This is teh end Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque optio veniam error accusamus eligendi harum nam similique unde explicabo facilis odit ipsum corporis, illo soluta facere dicta eaque doloremque aliquam?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit.

                </p>
            </div>
          
            <div class="article2_container">
                <h6 class="para2_title">How Az Dental Came To Be</h6>
                <p class="para2_desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    Voluptas quaerat suscipit corrupti? Aliquam adipisci at cupiditate,
                     totam accusantium, 
                    quis velit magni nam odio voluptatem, iste impedit quo unde 
                    exercitationem tenetur! Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit sequi magni ea nam repellatsi. Laboriosam!
                </p>
            </div>
            <img width="500px" height="400px" src="static/images/xray.jpg" class="image1" alt="Dentist in New Jersey">
            <img width="500px" height="400px" src="static/images/xray.jpg" class="image2" alt="Dentist in New Jersey">
</section> 
 -->


    

<section class="new_about_container" id="about">
    <div class="new_section1">
        <div class="intro">
            <h1 class="about_us_intro">About this project</h1>
            <p>
                This project was made using LAMP STACK technologies. It includes a 
                fully functional admin panel to which I will include username
                 and password too, so that you may see a demonstration. 
                 This project is utilizing a MySQL database for capturing and displaying data. I also integrated a 
                 booking system in which a patient can request an appointment after which the medical proffesional
                 will be notifed of this appointment attempt, and will be able to either accept or deny the appointment naturally follow up emails
                 are sent with details included for the patient to have reminders or to click and reschedule.Please go to the route /login. The admin panel username and password are as followed <br>
                 Username: haseeb_khan <br>
                 Password: 123


            </p>
        </div>
       <div class="photo">
           <img width="430px" height="430px" src="static/images/dental_image.jpg" alt="">
           <img width="430px" height="430px" src="static/images/dental_image2.jpg" alt="">
       </div>
    </div>
    <div class="new_section2">
        <h2 class="header_2"> Some Article Title  </h2>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias quia aliquam, perferendis totam deleniti quae illum, voluptatibus explicabo impedit ullam iusto nulla minima vel suscipit aperiam unde quasi voluptatum mollitia!
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Deserunt laudantium et voluptatem ut maiores quam saepe quisquam eos fugit, nesciunt expedita aliquam architecto sunt vero doloremque fuga aperiam, nobis 
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod, blanditiis similique magni nobis commodi, culpa eligendi doloribus porro consectetur iste provident impedit! Consequatur eum at facere culpa libero. Fugiat, tenetur?
        </p>

    </div>


</section>









<div class="our_work_container"> <h2 class="this">Our Work</h2> </div>
<div id="slide_flex_container">

   

<div id="container1">
 <!-- The before image is first -->
 <img src="static/images/slide_example3.jpg" />
 <!-- The after image is last -->
 <img src="static/images/slide_example4.jpg" />

</div>

<div id="container2">
<img src="static/images/slide_example3.jpg" />
 <!-- The after image is last -->
 <img src="static/images/slide_example4.jpg" />
</div>

<div id="container3">
<img src="static/images/slide_example3.jpg" />
 <!-- The after image is last -->
 <img src="static/images/slide_example4.jpg" />
</div>


</div>

<script>


</script>
