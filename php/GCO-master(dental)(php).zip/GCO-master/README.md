# GCO Smile Odonto
This is a version based on GCO that we are updating to work with PHP 5.6, contributions are welcome.
