<?php
  include 'view_config.php';
?>
      <div id="tmpDiv"></div>
      </div>
      <footer class="footer">
        <!--<div class='alert alert-success hidden-xs hidden-sm hidden-print navbar-fixed-bottom'><div class='text-right'>Clinic Management System | &copy; 2014 Baratali Ghadamalizadeh. All Right Reserved.</div></div>-->
        <div class='alert alert-success hidden-md hidden-lg hidden-print'><div class='text-right'>Clinic Management System | &copy; 2014 Baratali Ghadamalizadeh. All Right Reserved.</div></div>
      </footer>
    </div>
    <script src="<?php echo base_url() ?>content/js/main.js"></script>
    <?php if(isset($script))echo $script; ?>
  </body>
</html>