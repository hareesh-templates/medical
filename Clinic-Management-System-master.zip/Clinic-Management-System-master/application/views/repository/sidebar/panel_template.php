<div class="panel panel-default">
  <div class="panel-heading">
    <h4 class="panel-title">
      <a href="#collapseOne" data-parent="#accordion" data-toggle="collapse">
        <span class="glyphicon glyphicon-folder-close"></span> 
        PanelTitle
      </a>
    </h4>
  </div>
  <div class="panel-collapse collapse in" id="collapseOne">
    <div class="panel-body">
      <table class="table">
        <tbody>
          <tr>
            <td>
              <span class="glyphicon glyphicon-user text-primary"></span><a href="#">Link Label</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>