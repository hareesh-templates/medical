This folder stors the user documents and Health Records or any type of attachement they have.
Each user has a folder named as them userID. (limitation of file system should be checked and considered, maybe some type of grouping to come over with maximum item in folder or shortnames for name and address length limitation)
Archive is needed in case the system has lots of users.
Automatic comperssion is good to implement.
