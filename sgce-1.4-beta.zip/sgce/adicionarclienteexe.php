<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.   

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

$nasci = explode("/", $_POST["nascimento"]);
$dnasci = $nasci[0];
$mnasci = $nasci[1];
$anasci = $nasci[2];
$nascimto = "$anasci-$mnasci-$dnasci";

# SQL: Inser��o - Produto
$sqlinsere="insert into ".$dbestetica.".cadastro (	estetica,
											data,
											nascimento,
											email,
											nome,
											endereco,
											bairro,
											cep,
											cidade,
											estado,
											ddd,
											tel_residencial,
											tel_comercial,
											tel_celular,
											profissao,
											sexo,
											cor,
											estado_civil,
											filhos,
											indicacao )
					values(					'1',
											'".date("Y-m-d")."',
											'$nascimto',
											'".$_POST['email']."',
											'".$_POST['nome']."',
											'".$_POST['endereco']."',
											'".$_POST['bairro']."',
											'".$_POST['cep']."',
											'".$_POST['cidade']."',
											'".$_POST['estado']."',
											'".$_POST['ddd']."',
											'".$_POST['tel_residencial']."',
											'".$_POST['tel_comercial']."',
											'".$_POST['tel_celular']."',
											'".$_POST['profissao']."',
											'".$_POST['sexo']."',
											'".$_POST['cor']."',
											'".$_POST['estado_civil']."',
											'".$_POST['filhos']."',
											'".$_POST['indicacao']."'
										)";

# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere,$dbconn);		

if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");

$sqlcliente="select codigo from ".$dbestetica.".cadastro where nome='".$_POST['nome']."' limit 1";
$querycliente=mysql_query($sqlcliente,$dbconn);
$rowcliente=mysql_fetch_array($querycliente);
	
# Fecha Conex�o
mysql_close($dbconn);

echo "<script name=\"JavaScript\">window.open('http://$_SERVER[HTTP_HOST]$wpath/carregarcliente.php?cliente=$rowcliente[codigo]&pagina=adicionarhistorico','_self');</script>";


?>
