<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");
	
if($_POST['tratamento_medico'] && $_POST['tratamento_dentario'])
	$tratamento="M,D";
elseif($_POST['tratamento_dentario'] == "D")
	$tratamento="D";
elseif($_POST['tratamento_medico'] == "M")
	$tratamento="M";	
	
# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

# SQL: Inser��o - Produto
$sqlinsere="insert into historico_clinico (	cliente,
									lentes_contato,
									hipertensao,
									cardiaco,
									marca_passo,
									pino_placa,
									gravidez,
									epileptico,
									diabetico,
									displasia,
									hormonais,
									tireoide,
									ovarios,
									labirintite,
									corticoterapia,
									tpm,
									aids,
									ca,
									osseas,
									articulares,
									musculares,
									medicamentos,
									anticoncepcional,
									tratamentos,
									dermatoses,
									infeccoes,
									vasculopatias,
									emocional,
									fumante,
									macos,
									agua,
									glicolico,
									exposicao_sol )
					values(					'".$_SESSION['cliente']."',
											'".$_POST['lentes_contato']."',
											'".$_POST['hipertensao']."',
											'".$_POST['cardiaco']."',
											'".$_POST['marca_passo']."',
											'".$_POST['pino_placa']."',
											'".$_POST['gravidez']."',
											'".$_POST['epileptico']."',
											'".$_POST['diabetico']."',
											'".$_POST['displasia']."',
											'".$_POST['hormonais']."',
											'".$_POST['tireoide']."',
											'".$_POST['ovarios']."',
											'".$_POST['labirintite']."',
											'".$_POST['corticoterapia']."',
											'".$_POST['tpm']."',
											'".$_POST['aids']."',
											'".$_POST['ca']."',
											'".$_POST['osseas']."',
											'".$_POST['articulares']."',
											'".$_POST['musculares']."',
											'".$_POST['medicamentos']."',
											'".$_POST['anticoncepcional']."',
											'$tratamento',
											'".$_POST['dermatoses']."',
											'".$_POST['infeccoes']."',
											'".$_POST['vasculopatias']."',
											'".$_POST['emocional']."',
											'".$_POST['fumante']."',
											'".$_POST['macos']."',
											'".$_POST['agua']."',
											'".$_POST['glicolico']."',
											'".$_POST['exposicao_sol']."' )";
							

# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);

if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");

# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico2.php");

?>
