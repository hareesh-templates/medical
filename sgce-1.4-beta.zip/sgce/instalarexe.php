<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


$conteudo = '<?
# Database
$dbhost=\''.$_POST[name].'\';
$dbestetica=\''.$_POST[database].'\';
$dbuser=\''.$_POST[user].'\';
$dbpass=\''.$_POST[password].'\';
$dbconn=mysql_connect($dbhost,$dbuser,$dbpass);

# Sess�o
$idpassportcli=\''.$_POST[keysession].'\';
?>';

$handle = fopen('conf.inc.php', 'w');
fwrite($handle, $conteudo);
fclose($handle);

include("conf.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$fd = fopen('database-mysql.sql', 'rb');
$sqlcriar = fread($fd, filesize('database-mysql.sql'));
fclose($fd);

# Grava no MySQL o DB
$criar=mysql_query('$sqlcriar');

if($criar)
	exit("N�o foi poss�vel criar as tabelas MySQL");

mysql_close($dbconn);
?>

<html>
<head><TITLE>SGCE - Sistema de Gerenciamento de Cl�nica Est�tica</TITLE>
</head>
<body>
<br>
<h2>Sistema de Instala��o</h2>
Adicionar usuario/senha na tabela autenticacao
Adicionar dados da empresa

</body>
</html>
