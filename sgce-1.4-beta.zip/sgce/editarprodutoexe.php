<?

include("sessao.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

# SQL: Execu��o
$sqlupdate= "update produtos set 
				nome='$_POST[nome]',
				quantidade='$_POST[quantidade]',
				estoque='$_POST[estoque]',
				fabricante='$_POST[fabricante]',
				ddd='$_POST[ddd]',
				telefone='$_POST[telefone]',
				preco='". str_replace(",",".", $_POST['preco']) ."',
				validade='$_POST[validade]'
			where codigo='$_POST[codigo]'";
$queryupdate=mysql_query($sqlupdate);

if(!$queryupdate)
exit("N�o foi possivel atualizar o banco de dados");


# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/visualizarproduto.php");

?>
