<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

if(!empty($_POST['ostios_pele']))
$ostios_pele = implode(",", $_POST['ostios_pele']);
if(!empty($_POST['superficie']))
$superficie = implode(",", $_POST['superficie']);
if(!empty($_POST['classificacao']))
$classificacao = implode(",", $_POST['classificacao']);
if(!empty($_POST['tecidnais']))
$tecidnais = implode(",", $_POST['tecidnais']);
if(!empty($_POST['lesoes_solidas']))
$lesoes_solidas = implode(",", $_POST['lesoes_solidas']);
if(!empty($_POST['lesoes_liquidas']))
$lesoes_liquidas = implode(",", $_POST['lesoes_liquidas']);
if(!empty($_POST['estado_pele']))
$estado_pele = implode(",", $_POST['estado_pele']);
if(!empty($_POST['consistencia']))
$consistencia = implode(",", $_POST['consistencia']);
if(!empty($_POST['manchas']))
$manchas = implode(",", $_POST['manchas']);
if(!empty($_POST['corpo']))
$corpo = implode(",", $_POST['corpo']);

$sqledita="update ".$dbestetica.".ficha_estetica set
											cor_pele='".$_POST['cor_pele']."',
											ostios_pele='".$ostios_pele."',
											tonus_pele='".$_POST['tonus_pele']."',
											estado_pele='".$estado_pele."',
											superficie='".$superficie."',
											classificacao='".$classificacao."',
											tecidnais='".$tecidnais."',
											lesoes_solidas='".$lesoes_solidas."',
											lesoes_liquidas='".$lesoes_liquidas."',
											consistencia='".$consistencia."',
											manchas='".$manchas."',
											acromica='".$_POST['acromica']."',
											hipocromica='".$_POST['hipocromica']."',
											corpo='".$corpo."',
											observacoes='".$_POST['observacoes']."'
					 where cliente='$_SESSION[cliente]' limit 1";

# Execu��o: Inser��o - Produto									
$queryedita=mysql_query($sqledita,$dbconn);		

if(!$queryedita)
	exit("N�o foi possivel editar este cadastro");

# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/editarfichaestetica.php");

?>
