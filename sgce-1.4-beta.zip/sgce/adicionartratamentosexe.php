<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$_POST['total'] = str_replace(",",".", $_POST['total']);

# SQL: Inser��o - Tratamentos
$sqlinsere="insert into tratamentos_realizados (	
											tratamento,
											cliente,
											status,
											observacoes,
											total	 )
					values(					'".$_POST['tratamento']."',
											'".$_SESSION['cliente']."',
											'I',
											'".$_POST['observacoes']."',
											'".$_POST['total']."'
										)";
# Execu��o: Inser��o - Tratamentos								
$queryinsere=mysql_query($sqlinsere);	
	
# Obtem c�digo para inserir nas tabelas
$sqlcodigo="select codigo from tratamentos_realizados where cliente = " . $_SESSION['cliente'] . " order by codigo desc";
$querycodigo = mysql_query($sqlcodigo);
$rowcodigo = mysql_fetch_array($querycodigo);
$codigo = $rowcodigo['codigo'];

# Salvando data do primeiro atendimento
$sqlinsere = "insert into data_tratamento	(
											tratamento,
											data
									)
								values (		'".$codigo."',
											'".date("Y-m-d")."'
									)";
# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);	

for($i=0;$i<count($produto); $i++)
{
if(!empty($produto[$i]) && !empty($quantidade[$i]))
{
# SQL: Inser��o - Produtos
$sqlinsere="insert into produtos_utilizados (	
											data,	
											tratamento,
											estetica,
											produto,
											quantidade	 )
					values(						now(),	
											'".$codigo."',
											'1',
											'".$produto[$i]."',
											'".$quantidade[$i]."'
										)";
# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);		
}
}
header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/visualizartratamentos.php");


?>
