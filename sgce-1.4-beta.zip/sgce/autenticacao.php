<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

require("security/clean.inc.php");

if(!$_GET['codigo']) 
$codigo='1';

# Baixa conf do DB
include("conf.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

# Baixa Raz�o social para t�tulo da p�gina
$sqlpagina="select
				nomefantasia,
				endereco,
				cidade,
				estado,
				ddd,
				telefone
			from
				empresa
			where
				codigo=".$codigo."";
$querypagina=mysql_query($sqlpagina);

if(!$querypagina)
	 header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/instalar.php");

$rowpagina=mysql_fetch_array($querypagina);

session_start();

# Verifica autenticacao
if(	session_is_registered('letsafecli') 		&& 
	$_SESSION['letsafecli'] == $idpassportcli)
header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/index.php");

session_destroy();

# Fecha Conex�o
mysql_close($dbconn);

?>

<html>
<head>
<TITLE>SGCE - Sistema de Gerenciamento de Cl�nica Est�tica</TITLE>
<LINK REL="StyleSheet" HREF="layout.css" TYPE="text/css">
</head>
<body bgcolor="#A5FF7F">
<br><br><div align="center"><a class="logotipo"><?=$rowpagina['nomefantasia']?></a></div><br><br><br><br><br>

<table align="center">
<tr><TD colspan="2"><a class="logotipo" style="font-size:16px;">Autentica��o</a><br><br></TD></tr>
<tr>
<form action="autenticacaoexe.php" method="POST">
<TD><a class="autenticacao">Usu�rio:</a></TD>
<td><input name="usuario" type="text" class="form" maxlength="10" size="8"></td>
</TR>
<tr>
<TD align="left"><a class="autenticacao">Senha:</a></TD>
<td><input name="senha" type="password" class="form" maxlength="8" size="8"></td>
</tr>
<tr><TD colspan="2" align="center"><br><input type="submit" value="Autenticar"></form></TD></tr>
</table>
<br><br><br>

<div align="center"><a class="rodape"><?=$rowpagina['endereco']?> - <?=$rowpagina['cidade']?> / <?=$rowpagina['estado']?></a></div>
<br>

<div align="center"><a style="font-size:10px"> 
SGCE version <?=$version?>, Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com> <br>
SGCE comes with ABSOLUTELY NO WARRANTY;<br> 
This is free software, and you are welcome to redistribute it under certain conditions.
<br>
<br>

<a href="http://sourceforge.net"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=198010&amp;type=1" width="88" height="31" border="0" alt="SourceForge.net Logo" /></a>
	</div>
</body>
</html>
