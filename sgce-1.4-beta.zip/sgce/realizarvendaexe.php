<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");


# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

if($_POST['produtoa'] || $_POST['quantidadea'])
{
$sqlpreco = "select preco,quantidade from produtos where codigo=" . $_POST['produtoa'];
$querypreco=mysql_query($sqlpreco);
$rowpreco=mysql_fetch_array($querypreco);
$precoa=$rowpreco['preco'];
$sqledita="update produtos set quantidade='" .  ($rowpreco['quantidade'] - $_POST['quantidadea'])   ."' where codigo='$produtoa' limit 1";
$queryedita=mysql_query($sqledita);
}

if($_POST['produtob'] || $_POST['quantidadeb'])
{
$sqlpreco = "select preco,quantidade from produtos where codigo=" . $_POST['produtob'];
$querypreco=mysql_query($sqlpreco);
$rowpreco=mysql_fetch_array($querypreco);
$precob=$rowpreco['preco'];
$sqledita="update produtos set quantidade='" .  ($rowpreco['quantidade'] - $_POST['quantidadeb'])   ."' where codigo='$produtob' limit 1";
$queryedita=mysql_query($sqledita);
}

if($produtoc || $quantidadec)
{
$sqlpreco = "select preco,quantidade from produtos where codigo=" . $_POST['produtoc'];
$querypreco=mysql_query($sqlpreco);
$rowpreco=mysql_fetch_array($querypreco);
$precoc=$rowpreco['preco'];
$sqledita="update produtos set quantidade='" .  ($rowpreco['quantidade'] - $_POST['quantidadec'])   ."' where codigo='$produtoc' limit 1";
$queryedita=mysql_query($sqledita);
}

if($produtod || $quantidaded)
{
$sqlpreco = "select preco,quantidade from produtos where codigo=" . $_POST['produtod'];
$querypreco=mysql_query($sqlpreco);
$rowpreco=mysql_fetch_array($querypreco);
$precod=$rowpreco['preco'];
$sqledita="update produtos set quantidade='" .  ($rowpreco['quantidade'] - $_POST['quantidaded'])   ."' where codigo='$produtod' limit 1";
$queryedita=mysql_query($sqledita);
}


# Calcular total
$total = ($quantidadea * $precoa) + ($quantidadeb * $precob) + ($quantidadec * $precoc) + ($quantidaded * $precod);
$totala = $quantidadea * $precoa;
$totalb = $quantidadeb * $precob;
$totalc = $quantidadec * $precoc;
$totald = $quantidaded * $precod;



if($_POST['produtoa'] || $_POST['quantidadea'])
{
# SQL: Inser��o - Produto
$sqlinsere="insert into produtos_vendidos (
	cliente,
	data,
	produto,
	quantidade,
	valor	)
								values (
	'".$_SESSION['cliente']."',
	'".date("Y-m-d")."',
	'".$_POST['produtoa']."',
	'".$_POST['quantidadea']."',
	'".$totala."' 	)";
# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere,$dbconn);		
if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");
}

if($_POST['produtob'] || $_POST['quantidadeb'])
{
# SQL: Inser��o - Produto
$sqlinsere="insert into produtos_vendidos (cliente,data,produto,quantidade,valor) values('".$_SESSION['cliente']."','".date("Y-m-d")."','".$_POST['produtob']."','".$_POST['quantidadeb']."','".$totalb."' )";
# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere,$dbconn);		
if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");
}

if($_POST['produtoc'] || $_POST['quantidadec'])
{
# SQL: Inser��o - Produto
$sqlinsere="insert into produtos_vendidos (cliente,data,produto,quantidade,valor) values('".$_SESSION['cliente']."','".date("Y-m-d")."','".$_POST['produtoc']."','".$_POST['quantidadec']."','".$totalc."' )";
# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere,$dbconn);		
if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");
}

if($_POST['produtod'] || $_POST['quantidaded'])
{
# SQL: Inser��o - Produto
$sqlinsere="insert into produtos_vendidos (cliente,data,produto,quantidade,valor) values('".$_SESSION['cliente']."','".date("Y-m-d")."','".$_POST['produtod']."','".$_POST['quantidaded']."','".$totald."' )";
# Execu��o: Inser��o - Produto
$queryinsere=mysql_query($sqlinsere,$dbconn);		
if(!$queryinsere)
	exit("N�o foi possivel inserir no banco de dados");
}


# Fecha Conex�o
mysql_close($dbconn);

?>

<html>
<head>
<LINK REL="StyleSheet" HREF="layout.css" TYPE="text/css">
</head>
<body bgcolor="#A5FF7F" marginwidth="6" marginheight="40">

<p align="center"><a style="font-family: arial;font-size: 16px;font-weight: bold;color:white;">Venda efetuada com sucesso</a></p><br><br>
<a style="font-family: arial;font-size: 14px;font-weight: bold;color:white;">
O total desta venda � de R$<?=str_replace(".",",", $total)?>
</body>
</html>
