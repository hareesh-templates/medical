<?

class clean
{
function filterInput($value)
{
    return strip_tags(htmlspecialchars(addslashes(stripslashes($value))));
}
function cleanAll($post, $get)
{
    if ($post != NULL)
    {
        if (is_array($post))
        {
            foreach ($post as $name => $value)
            {
                $_POST[$name] = $value;                       
               return $this->filterInput($_POST[$name]);
            }
        }
        else
        {
            die("Invalid $_POST data");
        }
    }
   
    if ($get != NULL)
    {
        if (is_array($get))
        {       
            foreach ($get as $name => $value)
            {
                $_GET[$name] = $value;
                   
                return $this->filterInput($_GET[$name]);
            }
        }
        else
        {
            die("Invalid $_GET data");
        }
    }
}
}

$clean = new clean;
$clean->cleanAll($_POST, $_GET);

?>
