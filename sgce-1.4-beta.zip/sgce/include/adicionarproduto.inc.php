<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>
<p align="center"><a class="page_tit">Adicionando Novo Produto</a><br><br>
<form action="adicionarprodutoexe.php" method="POST">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Nome do produto: <input type="text" class="form" name="nome" size="50"><br><br>
Quantidade: <input type="text" class="form" name="quantidade" size="3"><br><br>
Estoque: <input type="text" class="form" name="estoque" size="3"><br><br>
Fabricante: <input type="text" class="form" name="fabricante" size="50"><br><br>
Telefone: DDD <input type="text" class="form" name="ddd" size="2" maxlength="2"> N�mero <input type="text" class="form" name="telefone" size="8" maxlength="8"><br><br>
Pre�o: R$ <input type="text"class="form"  name="preco" size="3"><br><br>
Validade: <input type="text" class="form" name="validade" size="2" maxlength="2"> meses.<br><br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form></a>
