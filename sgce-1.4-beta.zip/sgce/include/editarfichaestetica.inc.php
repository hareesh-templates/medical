<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=adicionarfichaestetica','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarfichaestetica");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqlfichaestetica = "select *
					from ficha_estetica
					where cliente=".$_SESSION['cliente'];
$queryfichaestetica = mysql_query($sqlfichaestetica);
$rowfichaestetica=mysql_fetch_array($queryfichaestetica);

if(!$rowfichaestetica)
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarfichaestetica.php','_self');</script>";
//header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarfichaestetica.php");

# Fecha Conex�o
	
?>

<head>
<SCRIPT LANGUAGE="JavaScript">
function select_drop(sel_name, abbr_name)
	{
	if(abbr_name!=''){
		if(sel_name.length > 0){
			var maxIndex = sel_name.length;
				for(var i=0; i<maxIndex; i++){
					if(abbr_name== sel_name.options[i].value){
						sel_name.selectedIndex = i;
						break;
					}
				}
			}
		}
	return true;    
	}
</script> 
</head>
<p align="center"><a class="page_tit">Editando Ficha Est�tica</a><br><br>
<form action="editarfichaesteticaexe.php" method="POST" name="editaficha">
<table width="100%" cellpadding="10">
<tr>
<TD align="left">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cor da Pele:
<select name="cor_pele" class="form">
<option selected="true"></option>
<option value="N">Normal</option>
<option value="A">Avermelhada</option>
<option value="P">P�lida</option>
</select>
<script language="JavaScript">
var aa=select_drop(document.editaficha.cor_pele, '<?=$rowfichaestetica['cor_pele']?>')
</script>
</TD>
<TD align="left">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">T�nus
<select name="tonus_pele" class="form">
<option selected="true"></option>
<option value="N">Normal</option>
<option value="H">Hipot�nico</option>
<script language="JavaScript">
var aa=select_drop(document.editaficha.tonus_pele, '<?=$rowfichaestetica['tonus_pele']?>')
</script>
</select>
</TD>
</tr>
</table>
<table  width="100%" cellpadding="10">
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">�stios</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Superf�cie</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Classifica��o</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Perdas Tecidnais</TD>
</tr>
<tr>
<TD align="center" valign="top">
 <select name="ostios_pele[]" size="3" multiple="multiple" class="form">
                <option value="X" 		<?if(preg_match('/X/i', $rowfichaestetica['ostios_pele'] ))
			echo "  selected=\"true\"";?>>Normais</option>
                <option value="NLDT" <?if(preg_match('/NLDT/i', $rowfichaestetica['ostios_pele'] ))
			echo "  selected=\"true\"";?>>Normal Lateral e Dilatado T</option>
                <option value="Y" <?if(preg_match('/Y/i', $rowfichaestetica['ostios_pele'] ))
			echo "  selected=\"true\"";?>>Dilatados</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="superficie[]" size="4" multiple="multiple" class="form">
                <option value="L" <?if(preg_match('/L/i', $rowfichaestetica['superficie'] ))
			echo "  selected=\"true\"";?>>Lisa</option>
                <option value="G" <?if(preg_match('/G/i', $rowfichaestetica['superficie'] ))
			echo "  selected=\"true\"";?>>Grossa</option>
                <option value="A" <?if(preg_match('/A/i', $rowfichaestetica['superficie'] ))
			echo "  selected=\"true\"";?>>�spera</option>
                <option value="F" <?if(preg_match('/F/i', $rowfichaestetica['superficie'] ))
			echo "  selected=\"true\"";?>>Fina</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="classificacao[]" size="6" multiple="multiple" class="form">
                <option value="N" <?if(preg_match('/N/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Normal</option>
                <option value="AX" <?if(preg_match('/AX/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Al�ptica</option>
                <option value="M" <?if(preg_match('/M/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Mista</option>
                <option value="AC" <?if(preg_match('/AC/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Acneica</option>
                <option value="L" <?if(preg_match('/L/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Lip�dica</option>
                <option value="G" <?if(preg_match('/G/i', $rowfichaestetica['classificacao'] ))
			echo "  selected=\"true\"";?>>Gr�u</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="tecidnais[]" size="5" multiple="multiple" class="form">
                <option value="E" <?if(preg_match('/E/i', $rowfichaestetica['tecidnais'] ))
			echo "  selected=\"true\"";?>>Escoria��es</option>
                <option value="D" <?if(preg_match('/D/i', $rowfichaestetica['tecidnais'] ))
			echo "  selected=\"true\"";?>>Descama��o</option>
                <option value="U" <?if(preg_match('/U/i', $rowfichaestetica['tecidnais'] ))
			echo "  selected=\"true\"";?>>Ulcera��o</option>
                <option value="R" <?if(preg_match('/R/i', $rowfichaestetica['tecidnais'] ))
			echo "  selected=\"true\"";?>>Rachadura Perilabial</option>
                <option value="F" <?if(preg_match('/F/i', $rowfichaestetica['tecidnais'] ))
			echo "  selected=\"true\"";?>>Fissuras</option>
                </select>
</TD>
</tr>
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Les�es S�lidas </TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Les�es L�quidas</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Estado da Pele</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es de Espessura</TD>
</tr>
<tr>
<TD align="center" valign="top">
 <select name="lesoes_solidas[]" size="5" multiple="multiple" class="form">
                <option value="CO" <?if(preg_match('/CO/i', $rowfichaestetica['lesoes_solidas'] ))
			echo "  selected=\"true\"";?>>Comed�es</option>
                <option value="N" <?if(preg_match('/N/i', $rowfichaestetica['lesoes_solidas'] ))
			echo "  selected=\"true\"";?>>N�dulos</option>
                <option value="CH" <?if(preg_match('/CH/i', $rowfichaestetica['lesoes_solidas'] ))
			echo "  selected=\"true\"";?>>Chantelasma</option>
                <option value="P" <?if(preg_match('/P/i', $rowfichaestetica['lesoes_solidas'] ))
			echo "  selected=\"true\"";?>>P�pulas</option>
                <option value="M" <?if(preg_match('/M/i', $rowfichaestetica['lesoes_solidas'] ))
			echo "  selected=\"true\"";?>>Millium</option>
		</select>
</TD>
<TD align="center" valign="top">
 <select name="lesoes_liquidas[]" size="4" multiple="multiple" class="form">
                <option value="P" <?if(preg_match('/P/i', $rowfichaestetica['lesoes_liquidas'] ))
			echo "  selected=\"true\"";?>>P�stulas</option>
                <option value="B" <?if(preg_match('/B/i', $rowfichaestetica['lesoes_liquidas'] ))
			echo "  selected=\"true\"";?>>Bolhas</option>
                <option value="A" <?if(preg_match('/A/i', $rowfichaestetica['lesoes_liquidas'] ))
			echo "  selected=\"true\"";?>>Abcessos</option>
                <option value="C" <?if(preg_match('/C/i', $rowfichaestetica['lesoes_liquidas'] ))
			echo "  selected=\"true\"";?>>Cistos</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="estado_pele[]" size="6" multiple="multiple" class="form">
                <option value="S" <?if(preg_match('/S/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Sens�vel</option>
                <option value="A" <?if(preg_match('/A/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Al�rgica</option>
                <option value="DD" <?if(preg_match('/DD/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Desidratada</option>
                <option value="DV" <?if(preg_match('/DV/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Desvitalizada</option>
                <option value="L" <?if(preg_match('/L/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Linhas</option>
                <option value="R" <?if(preg_match('/R/i', $rowfichaestetica['estado_pele'] ))
			echo "  selected=\"true\"";?>>Rugas</option>
                </select>
</TD>
 <td align="center" valign="top">
 <select name="consistencia[]" size="6" multiple="multiple" class="form">
                <option value="V" <?if(preg_match('/V/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Vibice (Estria)</option>
                <option value="CR" <?if(preg_match('/CR/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Crosta</option>
                <option value="A" <?if(preg_match('/A/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Atrofia</option>
                <option value="Q" <?if(preg_match('/Q/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Queratose</option>
                <option value="X" <?if(preg_match('/X/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Cicatriz</option>
                <option value="N" <?if(preg_match('/N/i', $rowfichaestetica['consistencia'] ))
			echo "  selected=\"true\"";?>>Nevus Verrucoso</option>
                </select>
</TD>
</tr>
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Manchas</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Corpo</TD>
</tr>
<tr>
 <td align="center" valign="top">
 <select name="manchas[]" size="14" multiple="multiple" class="form">
                <option value="A" <?if(preg_match('/A/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Eritema</option>
                <option value="B" <?if(preg_match('/B/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Ef�lides</option>
                <option value="C" <?if(preg_match('/C/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Cloasma</option>
                <option value="D" <?if(preg_match('/D/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Pet�quia</option>
                <option value="E" <?if(preg_match('/E/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Nevus Rubi</option>
                <option value="F" <?if(preg_match('/F/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Ros�cca</option>
                <option value="G" <?if(preg_match('/G/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Hipercr�micas</option>
                <option value="H" <?if(preg_match('/H/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Nevus Melanoc�tico</option>
                <option value="I" <?if(preg_match('/I/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Telangicctasias</option>
                <option value="J" <?if(preg_match('/J/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Nevus Sugestivo</option>
                <option value="K" <?if(preg_match('/K/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Assimetria</option>
                <option value="L" <?if(preg_match('/L/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Cor Uniforme</option>                
                <option value="M" <?if(preg_match('/M/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Bordas Irregulares</option>                
                <option value="N" <?if(preg_match('/N/i', $rowfichaestetica['manchas'] ))
			echo "  selected=\"true\"";?>>Di�metro Irregular</option>                
		</select>
</TD>
 <td align="center" valign="top">
 <select name="corpo[]" size="4" multiple="multiple" class="form">
                <option value="C" <?if(preg_match('/C/i', $rowfichaestetica['corpo'] ))
			echo "  selected=\"true\"";?>>Celulite</option>
                <option value="F" <?if(preg_match('/F/i', $rowfichaestetica['corpo'] ))
			echo "  selected=\"true\"";?>>Flacidez</option>
                <option value="G" <?if(preg_match('/G/i', $rowfichaestetica['corpo'] ))
			echo "  selected=\"true\"";?>>Gordura Localizada</option>
                <option value="E" <?if(preg_match('/E/i', $rowfichaestetica['corpo'] ))
			echo "  selected=\"true\"";?>>Estrias</option>
                </select>
</TD>
</tr>
</table>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Acr�mica:  <input type="text" class="form" name="acromica" size="54" maxlength="255" <?
if(!empty($rowfichaestetica['acromica']))
echo " value=\"$rowfichaestetica[acromica]\"";
?>><br><br>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Hipocr�mica:  <input type="text" class="form" name="hipocromica" size="50" maxlength="255" <?
if(!empty($rowfichaestetica['hipocromica']))
echo " value=\"$rowfichaestetica[hipocromica]\"";
?>>
<Br><Br>

<div align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es<br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"><?
if(!empty($rowfichaestetica['observacoes']))
echo $rowfichaestetica['observacoes'];
?></textarea></div>
<br><Br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form></a>
