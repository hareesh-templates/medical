</td>


<!-- MENU DIREITA -->
<td width=14% rowspan=100 valign=top>


<table align="right" width="100%">

<TR>
<td  align="center" > <a class="menu_tit">Administracao<br><br><br></TD>
</TR>

<TR>
<td  align="right" > <a href="visualizarproduto.php" class="menu_lnk" >Produtos</a><a class="menu_mas"> +<br><br></TD>

</TR>

<TR>
<td  align="right" > <a href="visualizartratamento.php" class="menu_lnk" >Tratamentos</a><a class="menu_mas"> +<br><br></TD>
</TR>

<TR>
<td  align="right" > <a href="visualizaraniversariantes.php" class="menu_lnk" >Aniversariantes</a><a class="menu_mas"> +<br><br></TD>
</TR>


<TR>
<td  align="right" > <a href="visualizarrelatorio.php" class="menu_lnk" >Relatorios</a><a class="menu_mas"> +<br><br></TD>
</TR>


<TR>
<td  align="right" > <a href="sair.php" class="menu_lnk" >Sair</a><a class="menu_mas"> >><br><br></TD>

</TR>
<tr><td><br></td></tr>
</table>



</td>
</tr>
</table>

<table width=100% bgcolor=white>
<!-- ENDERECO -->
<tr>
<td colspan=3 align=center>
<div align="center" class="rodape" style="font-size:18px"><?=$rowpagina['endereco']?> - <?=$rowpagina['cidade']?> / <?=$rowpagina['estado']?></a></div>
<a href="http://sourceforge.net"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=198010&amp;type=1" width="88" height="31" border="0" alt="SourceForge.net Logo" /></a>
</td>
</tr>

</table>

</body>
</html>
<?
# Fecha Conexão
mysql_close($dbconn);
?>
