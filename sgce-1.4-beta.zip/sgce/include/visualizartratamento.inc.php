<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>


<p align="center"><a class="page_tit">Visualizacao dos Tratamentos</a></p>

<br>

<p align="justify"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:white;">// </a><a style="font-family: arial;font-size: 12px;font-weight: bold;color:#FF1ECB;text-decoration:none" href="adicionartratamento.php" >Adicionar novo tratamento</a></p>

<br>

<table align="center" width="400" border="0" style="border-color:white;border-width:1">
<TR>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Tratamento</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Editar</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Remover</TD>
</TR>
<?

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
	
$sqltratamento = "	select codigo,nome
					from tratamentos
					where estetica='1'";
$querytratamento=mysql_query($sqltratamento);

while ($rowtratamento = mysql_fetch_assoc($querytratamento))
{
echo "
<tr>
<TD align=\"center\"><a class=\"page_rst\">".$rowtratamento['nome']."</TD>
<TD align=\"center\"><a class=\"page_rst\" href=\"editartratamento.php?tratamento=".$rowtratamento['codigo']."\" target=_self>E</a></TD>
<TD align=\"center\"><a class=\"page_rst\" href=\"removertratamento.php?tratamento=".$rowtratamento['codigo']."\"><img border=\"0\" src=\"img/deletar.gif\"></a></TD>
</tr>";
}
mysql_free_result($querytratamento);

?>
</table>

