<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=visualizartratamentos','_self');</script>";	
//header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=visualizartratamentos");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
	
$sqltratamento = "	select codigo,status,tratamento
					from tratamentos_realizados
					where cliente=" . $_SESSION['cliente'];
$querytratamento=mysql_query($sqltratamento);
$rowverifica=mysql_fetch_array($querytratamento);
if(!$rowverifica)
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionartratamentos.php','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionartratamentos.php");

?>


<p align="center"><a class="page_tit">Tratamentos</a><br><br>

<br>

<p align="justify"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:white;">// </a><a style="font-family: arial;font-size: 12px;font-weight: bold;color:#FF1ECB;text-decoration:none" href="adicionartratamentos.php" >Adicionar tratamento</a></p>

<br>

<table align="center" width="400" border="0" style="border-color:white;border-width:1">
<TR>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">&nbsp;</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Data</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Status</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Tratamento</a></TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Remover</TD>
</TR>
<?

$querytratamento=mysql_query($sqltratamento);

while ($rowtratamento = mysql_fetch_assoc($querytratamento))
{

$sqlnome = "	select nome
					from tratamentos
					where codigo=" . $rowtratamento['tratamento'];
$querynome=mysql_query($sqlnome);
$rownome=mysql_fetch_array($querynome);

$sqldata="select data from data_tratamento where tratamento = " . $rowtratamento['codigo'] ;
$querydata = mysql_query($sqldata);
$rowdata = mysql_fetch_array($querydata);

$datalimpando = explode("-", $rowdata['data']);
$d = $datalimpando[2];
$m = $datalimpando[1];
$a = $datalimpando[0];
$data = "$d/$m/$a";

echo "
<tr>
<TD align=\"center\"><a style=\"font-family: arial;font-size: 12px;font-weight: normal;color:blue;\" target=\"_self\"  href=\"editartratamentos.php?codigo=".$rowtratamento['codigo']."\"><img src=\"img/id.png\" border=\"0\"></TD>
<TD align=\"center\"><a style=\"font-family: arial;font-size: 12px;font-weight: normal;color:#000099;\">".$data."</TD><TD align=\"center\"><a style=\"font-family: arial;font-size: 12px;font-weight: normal;color:#000099;\">";
if($rowtratamento['status'] == "I")
	echo "Iniciado";
if($rowtratamento['status'] == "C")
	echo "Continuar";
if($rowtratamento['status'] == "F")
	echo "Finalizado";
echo "</TD>
<TD align=\"center\"><a style=\"font-family: arial;font-size: 12px;font-weight: normal;color:#000099;\">".$rownome['nome']."</TD>
<TD align=\"center\"><a style=\"font-family: arial;font-size: 12px;font-weight: normal;color:white;\" href=\"removertratamentos.php?codigo=".$rowtratamento['codigo']."\"><img border=\"0\" src=\"img/deletar.gif\"></a></TD>
</tr>";
}
mysql_free_result($querytratamento);

# Fecha Conex�o
?>
</table>
