<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>

<p align="center"><a class="page_tit">Visualiza��o de Aniversariantes</a></p>

<br>


<table align="center" width="400" border="0" style="border-color:white;border-width:1">
<TR>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">&nbsp;</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Cliente</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Data</TD>
</TR>
<?

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
	
$sqlcliente = "	select nome, date_format(nascimento, '%d/%m/%Y') as nasc,codigo
					from cadastro
					where estetica='1' and month(nascimento) = month(now())";
$querycliente=mysql_query($sqlcliente);

while ($rowcliente = mysql_fetch_assoc($querycliente))
{
echo "
<tr>
<TD align=\"center\"><a class=\"page_rst\" target=\"_self\"  href=\"carregarcliente.php?cliente=".$rowcliente['codigo']."&pagina=".$_GET['pagina']."\"><img src=\"img/id.png\" border=\"0\"></TD>
<TD align=\"center\"><a class=\"page_rst\">".$rowcliente['nome']."</TD>
<td align=\"center\"><a class=\"page_rst\">".$rowcliente['nasc']."</TD>
</tr>";
}
mysql_free_result($querycliente);

?>
</table>
