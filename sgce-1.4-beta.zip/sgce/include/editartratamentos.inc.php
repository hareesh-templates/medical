<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editartratamentos");

if(!$_GET['codigo'])
	exit("N�o foi repassado o c�digo do tratamento");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqltratamentos = "select *
					from tratamentos_realizados
					where codigo=".$_GET['codigo'];
$querytratamentos = mysql_query($sqltratamentos);
$rowtratamentos=mysql_fetch_array($querytratamentos);

if(!$rowtratamentos)
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/visualizartratamentos.php");
	
?>

<head>
<SCRIPT LANGUAGE="JavaScript">
function select_drop(sel_name, abbr_name)
	{
	if(abbr_name!=''){
		if(sel_name.length > 0){
			var maxIndex = sel_name.length;
				for(var i=0; i<maxIndex; i++){
					if(abbr_name== sel_name.options[i].value){
						sel_name.selectedIndex = i;
						break;
					}
				}
			}
		}
	return true;    
	}
</script> 
</head>
<p align="center"><a class="page_tit">Editando Tratamento</a><br><br>
<form action="editartratamentosexe.php" method="POST" name="editatrat">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Valor Total: R$ <input type="text" class="form" name="total" size="2" maxlength="10" value="<?=str_replace(".",",", $rowtratamentos['total'])?>">
<br><br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Status:
<select name="status" class="form">
 <option></option>
 <option value="I">Iniciado</option>
<option value="C">Continuar</option>
<option value="F">Finalizado</option>                    
</select>
<script language="JavaScript">
var aa=select_drop(document.editatrat.status, '<?=$rowtratamentos['status']?>')
</script>
<br><br>
<table cellspacing="10">
<TR>
<TD><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Data</td>
<TD><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Produto</TD>
<TD><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Quantidade</TD>
</TR>
<?
$sqlprodutos="select date_format(data,'%d/%m/%Y') as dat, produto,quantidade,codigo from produtos_utilizados where tratamento=" . $rowtratamentos['codigo'];
$queryprodutos=mysql_query($sqlprodutos);
$i = 1;

while ($rowprodutos = mysql_fetch_assoc($queryprodutos))
{
?>
<tr>
<TD><a class="form"><?=$rowprodutos['dat']?></a>
</td>
<TD>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto)) 
	if($rowprodutos['produto'] == $rowproduto['codigo']) 
		echo "<a class=form>" . $rowproduto['nome'] . "</a>"; 

mysql_free_result($queryproduto);

?>
</TD>
<TD><a class="form"><?=$rowprodutos['quantidade']?></a>
</td>
</tr>
<?
$i += 1;
}
mysql_free_result($queryprodutos);
?>
<tr>
<TD>
<select name="produto[<?=$i?>]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[<?=$i?>]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[<?=$i+1?>]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[<?=$i+1?>]" class="form" maxlength="3" size="10"></TD>
</tr>
</table>
<br><br>
<div align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es</a><br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"><?=$rowtratamentos['observacoes']?></textarea>
<input type="hidden" name="codigo" value="<?=$_GET['codigo']?>">
<br><br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form>
