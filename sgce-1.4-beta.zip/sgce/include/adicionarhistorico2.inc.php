<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>
<p align="center"><a class="page_tit">Hist�rico Cl�nico</a></p>
<form action="adicionarhistorico2exe.php" method="POST">
<table width="100%" cellpadding="10">
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Alergias?<br><br>
<textarea class="form" name="alergias" rows="5" cols="50"></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pratica Esportes?<br><br>
<textarea class="form" name="esportes" rows="5" cols="50"></textarea>	
</td>
</TR>
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pratica Dieta?<br><br>
<textarea class="form" name="dieta" rows="5" cols="50"></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Tratamentos Est�ticos?<br><br>
<textarea class="form" name="tratamentos_esteticos" rows="5" cols="50"></textarea>
</td>
</TR>
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Utiliza quais cosm�ticos?<br><br>
<textarea class="form" name="cosmeticos" rows="5" cols="50"></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">J� realizou alguma cirurgia est�tica?<br><br>
<textarea class="form" name="cirurgias_esteticas" rows="5" cols="50"></textarea>
</td>
</TR></table>

<br><br>


<table width="100%">
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cores Preferenciais<br><br>
 <select name="cores_preferenciais[]" size="7" multiple="multiple" class="form">
                <option value="G">Verde</option>
                <option value="B">Azul</option>
                <option value="Y">Amarelo</option>
                <option value="R">Vermelho</option>
                <option value="V">Verde</option>
                <option value="O">Laranja</option>
                <option value="P">Rosa</option>
                </select>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cores Irritantes<br><br>
 <select name="cores_irritantes[]" size="7" multiple="multiple" class="form">
                <option value="G">Verde</option>
                <option value="B">Azul</option>
                <option value="Y">Amarelo</option>
                <option value="R">Vermelho</option>
                <option value="V">Verde</option>
                <option value="O">Laranja</option>
                <option value="P">Rosa</option>
                </select>
</td>
</tr></table>

<br><br>
<center><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es Gerais<br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"></textarea>
</center>

<br><Br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form></a>
