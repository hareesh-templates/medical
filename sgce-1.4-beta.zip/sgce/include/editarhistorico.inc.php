<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(empty($_SESSION['cliente']))
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarhistorico");
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarhistorico','_self');</script>";

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqlhistorico = "	select *
					from historico_clinico
					where cliente=" . $_SESSION['cliente'];
$queryhistorico=mysql_query($sqlhistorico);
$rowhistorico=mysql_fetch_array($queryhistorico);

if(empty($rowhistorico))
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico.php','_self');</script>";
//header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico.php");

	
?>

<p align="center"><a class="page_tit">Editando Hist�rico Cl�nico</a><br><br>
<form action="editarhistoricoexe.php" method="POST">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">
<table align="100%"><TR>
<TD align="left">
<INPUT  type="checkbox" name="lentes_contato" value="S" class="form"
<?
if($rowhistorico['lentes_contato'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Lentes de Contato? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="gravidez" value="S" class="form"<?
if($rowhistorico['gravidez'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Gravidez? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="epileptico" value="S" class="form" <?
if($rowhistorico['epileptico'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Epilepsia?

&nbsp;&nbsp;&nbsp;&nbsp;
</TD>
<TD align="left">
<INPUT type="checkbox" name="diabetico" value="S" class="form"<?
if($rowhistorico['diabetico'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Diabetes?

</td></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="marca_passo" value="S" class="form"<?
if($rowhistorico['marca_passo'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Marca Passo? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="pino_placa" value="S" class="form"<?
if($rowhistorico['pino_placa'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pino Placa? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="hipertensao" value="S" class="form"<?
if($rowhistorico['hipertensao'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Hipertens�o? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="cardiaco" value="S" class="form"<?
if($rowhistorico['cardiaco'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Problemas Card�acos? 

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="displasia" value="S" class="form"<?
if($rowhistorico['displasia'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Displasia? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="hormonais" value="S" class="form"<?
if($rowhistorico['hormonais'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es Hormonais? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="tireoide" value="S" class="form"<?
if($rowhistorico['tireoide'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Tire�ide? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="ovarios" value="S" class="form"<?
if($rowhistorico['ovarios'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Ov�rios?

</TD>
</tr>
<tr><TD align="left">
<INPUT type="checkbox" name="labirintite" value="S" class="form"<?
if($rowhistorico['labirintite'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Labirintite? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="corticoterapia" value="S" class="form"<?
if($rowhistorico['corticoterapia'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Corticoterapia?

</TD>
<TD align="left">
<INPUT type="checkbox" name="tpm" value="S" class="form"<?
if($rowhistorico['tpm'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">T.P.M.? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="aids" value="S" class="form"<?
if($rowhistorico['aids'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Aids?

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="ca" value="S" class="form"<?
if($rowhistorico['ca'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> C.A.

</TD>
<TD align="left">
<INPUT type="checkbox" name="osseas" value="S" class="form"<?
if($rowhistorico['osseas'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es �sseas?

</TD>
<TD align="left">
<INPUT type="checkbox" name="articulares" value="S" class="form"<?
if($rowhistorico['articulares'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Articulares?

</TD>
<TD align="left">
<INPUT type="checkbox" name="musculares" value="S" class="form"<?
if($rowhistorico['musculares'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Musculares?

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="medicamentos" value="S" class="form"<?
if($rowhistorico['medicamentos'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Toma medicamentos?

</TD>
<TD align="left">
<INPUT type="checkbox" name="anticoncepcional" value="S" class="form"<?
if($rowhistorico['anticoncepcional'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Anticoncepcional?

</TD>
<TD align="left">
<INPUT type="checkbox" name="dermatoses" value="S" class="form"<?
if($rowhistorico['dermatoses'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Dermatoses?
<TD align="left">
<INPUT type="checkbox" name="infeccoes" value="S" class="form"<?
if($rowhistorico['infeccoes'] == "S")
echo " checked=\"true\" ";
?>> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Infec��es?
</TD>
</TR>
<tr>
<TD align="left"><INPUT type="checkbox" name="vasculopatias" value="S" class="form"<?
if($rowhistorico['vasculopatias'] == "S")
echo " checked=\"true\" ";
?>> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Vasculopatias?
</TD>
<TD align="left">
<INPUT type="checkbox" name="fumante" value="S" class="form"<?
if($rowhistorico['fumante'] == "S")
echo " checked=\"true\" ";
?>> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Fuma?
</TD>
<TD align="left">
<input type="text" name="macos" size="1" maxlength="1" class="form" <?
if(!empty($rowhistorico['macos']))
echo " value=\"$rowhistorico[macos]\" ";
?>>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> ma�os/dia
</TD>
<td align="left">
<input type="text" name="agua" size="1" maxlength="4" class="form" <?
if(!empty($rowhistorico['agua']))
echo " value=\"$rowhistorico[agua]\" ";
?>>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">  litros de H2O/dia
</td>
</tr>
<tr><TD align="left">
<INPUT type="checkbox" name="exposicao_sol" value="S" class="form"<?
if($rowhistorico['exposicao_sol'] == "S")
echo " checked=\"true\" ";
?>> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Exposi��o ao Sol
</TD>
<TD align="left">
<INPUT type="checkbox" name="glicolico" value="S" class="form"<?
if($rowhistorico['glicolico'] == "S")
echo " checked=\"true\" ";
?>> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">�cido Glic�lico
</TD>
</tr>
</table>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Est� em tratamento ?
<?
if(	$rowhistorico['tratamentos'] == "M,D"	)
echo "<table><TR><TD><INPUT type=\"checkbox\" name=\"tratamento_medico\" value=\"M\" class=\"form\" checked=\"true\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> M�dico</TD></TR>
<TR><TD><INPUT type=\"checkbox\" name=\"tratamento_dentario\" value=\"D\" class=\"form\" checked=\"true\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> Dent�rio</TD></TR>
</table>";
elseif($rowhistorico['tratamentos'] == "D")
echo "<table><TR><TD><INPUT type=\"checkbox\" name=\"tratamento_medico\" value=\"M\" class=\"form\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> M�dico</TD></TR>
<TR><TD><INPUT type=\"checkbox\" name=\"tratamento_dentario\" value=\"D\" class=\"form\" checked=\"true\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> Dent�rio</TD></TR>
</table>";
elseif($rowhistorico['tratamentos'] == "M")
echo "<table><TR><TD><INPUT type=\"checkbox\" name=\"tratamento_medico\" value=\"M\" class=\"form\" checked=\"true\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> M�dico</TD></TR>
<TR><TD><INPUT type=\"checkbox\" name=\"tratamento_dentario\" value=\"D\" class=\"form\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> Dent�rio</TD></TR>
</table>";
else
echo "<table><TR><TD><INPUT type=\"checkbox\" name=\"tratamento_medico\" value=\"M\" class=\"form\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> M�dico</TD></TR>
<TR><TD><INPUT type=\"checkbox\" name=\"tratamento_dentario\" value=\"D\" class=\"form\"> <a style=\"font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold\"> Dent�rio</TD></TR>
</table>";
?>

<br><Br>
<input type="hidden" name="cliente" value="<?=$_GET['cliente']?>">
<div align="center"><input type="submit" class="form" value="Pr�ximo >>"></div>
</form></a>
