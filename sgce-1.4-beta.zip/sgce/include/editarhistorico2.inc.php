<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarhistorico2");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqlhistorico = "	select *
					from historico_clinico
					where cliente=" . $_SESSION['cliente'];
$queryhistorico=mysql_query($sqlhistorico);
$rowhistorico=mysql_fetch_array($queryhistorico);

if(!$rowhistorico)
header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico.php");

# Fecha Conex�o
	
?>

<p align="center"><a class="page_tit">Editando Hist�rico Cl�nico</a><br><br>
<form action="adicionarhistorico2exe.php" method="POST">
<table width="100%" cellpadding="10">
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Alergias?<br><br>
<textarea class="form" name="alergias" rows="5" cols="50"><?
if(!empty($rowhistorico['alergias']))
echo $rowhistorico['alergias'];
?></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pratica Esportes?<br><br>
<textarea class="form" name="esportes" rows="5" cols="50"><?
if(!empty($rowhistorico['esportes']))
echo $rowhistorico['esportes'];
?></textarea>	
</td>
</TR>
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pratica Dieta?<br><br>
<textarea class="form" name="dieta" rows="5" cols="50"><?
if(!empty($rowhistorico['dieta']))
echo $rowhistorico['dieta'];
?></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Tratamentos Est�ticos?<br><br>
<textarea class="form" name="tratamentos_esteticos" rows="5" cols="50"><?
if(!empty($rowhistorico['tratamentos_esteticos']))
echo $rowhistorico['tratamentos_esteticos'];
?></textarea>
</td>
</TR>
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Utiliza quais cosm�ticos?<br><br>
<textarea class="form" name="cosmeticos" rows="5" cols="50"><?
if(!empty($rowhistorico['cosmeticos']))
echo $rowhistorico['cosmeticos'];
?></textarea>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">J� realizou alguma cirurgia est�tica?<br><br>
<textarea class="form" name="cirurgias_esteticas" rows="5" cols="50"><?
if(!empty($rowhistorico['cirurgias_esteticas']))
echo $rowhistorico['cirurgias_esteticas'];
?></textarea>
</td>
</TR></table>

<br><br>


<table width="100%">
<tr>
<TD  align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cores Preferenciais<br><br>
 <select name="cores_preferenciais[]" size="7" multiple="multiple" class="form">
                <option value="G"
		<?if(preg_match('/G/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Verde</option>
                <option value="B"
				<?if(preg_match('/B/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Azul</option>
                <option value="Y"
		<?if(preg_match('/Y/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Amarelo</option>
                <option value="R"
		<?if(preg_match('/R/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Vermelho</option>
                <option value="V"
		<?if(preg_match('/V/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Verde</option>
                <option value="O"
		<?if(preg_match('/O/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Laranja</option>
                <option value="P"
		<?if(preg_match('/P/i', $rowhistorico['cores_preferenciais'] ))
			echo "  selected=\"true\"";?>>Rosa</option>
                </select>
</TD><td valign="top" align="center">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cores Irritantes<br><br>
 <select name="cores_irritantes[]" size="7" multiple="multiple" class="form">
                <option value="G"
		<?if(preg_match('/G/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Verde</option>
                <option value="B"
		<?if(preg_match('/B/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Azul</option>
                <option value="Y"
		<?if(preg_match('/Y/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Amarelo</option>
                <option value="R"
		<?if(preg_match('/R/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Vermelho</option>
                <option value="V"
		<?if(preg_match('/V/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Verde</option>
                <option value="O"
		<?if(preg_match('/O/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Laranja</option>
                <option value="P"
		<?if(preg_match('/P/i', $rowhistorico['cores_irritantes'] ))
			echo "  selected=\"true\"";?>>Rosa</option>
                </select>
</td>
</tr></table>

<br><br>
<center><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es Gerais<br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"><?
if(!empty($rowhistorico['observacoes']))
echo $rowhistorico['observacoes'];
?></textarea>
</center>

<br><Br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form></a>
