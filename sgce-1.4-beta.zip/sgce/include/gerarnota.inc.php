<?



?>

<p align="center"><a style="font-family: arial;font-size: 16px;font-weight: bold;color:white;">Gerar Nota Fiscal</a></p><br><br>
<a style="font-family: arial;font-size: 12px;font-weight: normal;color:white;">Esta fun��o ser� desenvolvida na pr�xima vers�o do sistema.</a>
