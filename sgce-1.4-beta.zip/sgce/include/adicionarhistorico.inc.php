<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>


<p align="center"><a class="page_tit">Hist�rico Cl�nico</a><br><br>
<form action="adicionarhistoricoexe.php" method="POST">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">
<table align="100%"><TR>
<TD align="left">
<INPUT type="checkbox" name="lentes_contato" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Lentes de Contato? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="gravidez" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Gravidez? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="epileptico" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Epilepsia?

&nbsp;&nbsp;&nbsp;&nbsp;
</TD>
<TD align="left">
<INPUT type="checkbox" name="diabetico" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Diabetes?

</td></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="marca_passo" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Marca Passo? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="pino_placa" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Pino Placa? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="hipertensao" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Hipertens�o? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="cardiaco" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Problemas Card�acos? 

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="displasia" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Displasia? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="hormonais" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es Hormonais? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="tireoide" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Tire�ide? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="ovarios" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Ov�rios?

</TD>
</tr>
<tr><TD align="left">
<INPUT type="checkbox" name="labirintite" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Labirintite? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="corticoterapia" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Corticoterapia?

</TD>
<TD align="left">
<INPUT type="checkbox" name="tpm" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">T.P.M.? 

</TD>
<TD align="left">
<INPUT type="checkbox" name="aids" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Aids?

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="ca" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> C.A.

</TD>
<TD align="left">
<INPUT type="checkbox" name="osseas" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es �sseas?

</TD>
<TD align="left">
<INPUT type="checkbox" name="articulares" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Articulares?

</TD>
<TD align="left">
<INPUT type="checkbox" name="musculares" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Musculares?

</TD></tr>
<tr><TD align="left">
<INPUT type="checkbox" name="medicamentos" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Toma medicamentos?

</TD>
<TD align="left">
<INPUT type="checkbox" name="anticoncepcional" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Anticoncepcional?

</TD>
<TD align="left">
<INPUT type="checkbox" name="dermatoses" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Dermatoses?
<TD align="left">
<INPUT type="checkbox" name="infeccoes" value="S" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Infec��es?
</TD>
</TR>
<tr>
<TD align="left"><INPUT type="checkbox" name="vasculopatias" value="S" class="form"> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Vasculopatias?
</TD>
<TD align="left">
<INPUT type="checkbox" name="fumante" value="S" class="form"> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Fuma?
</TD>
<TD align="left">
<input type="text" name="macos" size="1" maxlength="1" class="form">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> ma�os/dia
</TD>
<td align="left">
<input type="text" name="agua" size="1" maxlength="4" class="form">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">  litros de H2O/dia
</td>
</tr>
<tr><TD align="left">
<INPUT type="checkbox" name="exposicao_sol" value="S" class="form"> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Exposi��o ao Sol
</TD>
<TD align="left">
<INPUT type="checkbox" name="glicolico" value="S" class="form"> 
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">�cido Glic�lico
</TD>
</tr>
</table>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Est� em tratamento ?
<table>
<table><TR><TD><INPUT type="checkbox" name="tratamento_medico" value="M" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> M�dico</TD></TR>
<TR><TD><INPUT type="checkbox" name="tratamento_dentario" value="D" class="form"> <a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold"> Dent�rio</TD></TR>
</table>


<br><Br>
<input type="hidden" name="cliente" value="<?=$_GET['cliente']?>">
<div align="center"><input type="submit" class="form" value="Pr�ximo >>"></div>
</form></a>
