<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>
<p align="center"><a class="page_tit">Adicionando Cliente</a><br><br>
<form action="adicionarclienteexe.php" method="POST">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">
Data de Nascimento: <input type="text" class="form" name="nascimento" size="10" maxlength="10"><br><br>
Nome: <input type="text" class="form" name="nome" size="20" maxlength="100">&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;
E-Mail: <input type="text" class="form" name="email" size="20" maxlength="255"><br><br>
Endere�o: <input type="text" class="form" name="endereco" maxlength="150" size="40">&nbsp;&nbsp;
Bairro: <input type="text" class="form" name="bairro" size="20" maxlength="30"><br><br>
CEP: <input type="text" class="form" name="cep" size="8" maxlength="8">&nbsp;&nbsp;&nbsp;&nbsp;
Cidade: <input type="text" class="form" name="cidade" size="20" maxlength="50">
&nbsp;&nbsp;&nbsp;&nbsp;
Estado: <select name="estado" size="1" class="form" >
                      <option value="AC">Acre</option>
                      <option value="AL">Alagoas</option>
                      <option value="AP">Amap�</option>
                      <option value="AM">Amazonas</option>
                      <option value="BA">Bahia</option>
                      <option value="CE">Cear�</option>
                      <option value="DF">Distrito Federal</option>
                      <option value="ES">Esp�rito Santo</option>
                      <option value="GO">Goias</option>
                      <option value="MA">Maranh�o</option>
                      <option value="MT">Mato Grosso</option>
                      <option value="MS">Mato Grosso do Sul</option>
                      <option value="MG">Minas Gerais</option>
                      <option value="PA">Par�</option>
                      <option value="PB">Para�ba</option>
                      <option value="PR">Paran�</option>
                      <option value="PE">Pernambuco</option>
                      <option value="PI">Piau�</option>
                      <option value="RJ">Rio de Janeiro</option>
                      <option value="RN">Rio Grande do Norte</option>
                      <option value="RS">Rio Grande do Sul</option>
                      <option value="RO">Rond�nia</option>
                      <option value="RR">Roraima</option>
                      <option value="SC">Santa Catarina</option>
                      <option value="SP" selected="true">S�o Paulo</option>
                      <option value="SE">Sergipe</option>
                      <option value="TO">Tocantins</option>
                    </select><br><Br>
Telefones
DDD <input type="text" class="form" name="ddd" size="1">
Residencial: <input type="text" class="form" name="tel_residencial" size="8">&nbsp;&nbsp;&nbsp;
Comercial: <input type="text" class="form" name="tel_comercial" size="8">&nbsp;&nbsp;&nbsp;
Celular: <input type="text" class="form" name="tel_celular" size="8"><br><br>
Profiss�o: <input type="text" class="form" name="profissao" size="30" maxlength="100"><br><br>
Sexo: 
<input type="radio" class="form" name="sexo" value="M">Masculino 
<input type="radio" class="form" name="sexo" value="F" checked="true">Feminino<br><br>
Cor de Pele: 
<input type="radio" class="form" name="cor" value="B">Branca
<input type="radio" class="form" name="cor" value="N">Negra
<input type="radio" class="form" name="cor" value="M">Morena 
<input type="radio" class="form" name="cor" value="P">Parda 
<input type="radio" class="form" name="cor" value="O">Oriental<br><br> 
Estado Civil: 
<select name="estado_civil" class="form">
<option selected="true"></option>
<option value="S">Solteira(o)</option>
<option value="C">Casada(o)</option>
<option value="V">Vi�va(o)</option>
<option value="D">Divorciada(o)</option>
</select>&nbsp;&nbsp;&nbsp;&nbsp;
Filhos: <input type="text" class="form" name="filhos" size="3"><br><br>
Indica��o: 
<select name="indicacao" class="form">
<option selected="true"></option>
<option value="L">Loja</option>
<option value="S">WebSite</option>
<option value="M">M�dica(o)</option>
<option value="A">Amiga(o)</option>
<option value="F">Folder / Cart�o</option>
</select>
<br><br>
<div align="center"><input type="submit" class="form" value="Pr�ximo >>"></div>
</form>
