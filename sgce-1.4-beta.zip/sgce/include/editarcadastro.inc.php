<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



if(empty($_SESSION['cliente'])) 
//header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarcadastro");
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=editarcadastro','_self');</script>";

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqlcadastro = "	select *
					from cadastro
					where codigo='".$_SESSION['cliente']."'";
$querycadastro=mysql_query($sqlcadastro);
$rowcadastro=mysql_fetch_array($querycadastro);


$nasci = explode("-", $rowcadastro['nascimento']);
$dnasci = $nasci[2];
$mnasci = $nasci[1];
$anasci = $nasci[0];
$nascimto = "$dnasci/$mnasci/$anasci";

?>

<SCRIPT LANGUAGE="JavaScript">
function select_drop(sel_name, abbr_name)
	{
	if(abbr_name!=''){
		if(sel_name.length > 0){
			var maxIndex = sel_name.length;
				for(var i=0; i<maxIndex; i++){
					if(abbr_name== sel_name.options[i].value){
						sel_name.selectedIndex = i;
						break;
					}
				}
			}
		}
	return true;    
	}
</script> 

<p align="center"><a class="page_tit">Editando Cadastro</a><br><br>
<form action="editarcadastroexe.php" method="POST" name="alteracadastro">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">
Data de Nascimento: <input type="text" class="form" name="nascimento" size="10" maxlength="10" value="<?=$nascimto?>"><br><br>
Nome: <input type="text" class="form" name="nome" size="20" maxlength="100"  value="<?=$rowcadastro['nome']?>">&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;
E-Mail: <input type="text" class="form" name="email" size="20" maxlength="255"  value="<?=$rowcadastro['email']?>"><br><br>
Endere�o: <input type="text" class="form" name="endereco" maxlength="150" size="50"  value="<?=$rowcadastro['endereco']?>">&nbsp;&nbsp;
Bairro: <input type="text" class="form" name="bairro" size="20" maxlength="30"  value="<?=$rowcadastro['bairro']?>"><br><br>
CEP: <input type="text" class="form" name="cep" size="8" maxlength="8"  value="<?=$rowcadastro['cep']?>">&nbsp;&nbsp;&nbsp;&nbsp;
Cidade: <input type="text" class="form" name="cidade" size="20" maxlength="50"  value="<?=$rowcadastro['cidade']?>">
&nbsp;&nbsp;&nbsp;&nbsp;
Estado: <select name="estado" size="1" class="form" >
                      <option value="AC">Acre</option>
                      <option value="AL">Alagoas</option>
                      <option value="AP">Amap�</option>
                      <option value="AM">Amazonas</option>
                      <option value="BA">Bahia</option>
                      <option value="CE">Cear�</option>
                      <option value="DF">Distrito Federal</option>
                      <option value="ES">Esp�rito Santo</option>
                      <option value="GO">Goias</option>
                      <option value="MA">Maranh�o</option>
                      <option value="MT">Mato Grosso</option>
                      <option value="MS">Mato Grosso do Sul</option>
                      <option value="MG">Minas Gerais</option>
                      <option value="PA">Par�</option>
                      <option value="PB">Para�ba</option>
                      <option value="PR">Paran�</option>
                      <option value="PE">Pernambuco</option>
                      <option value="PI">Piau�</option>
                      <option value="RJ">Rio de Janeiro</option>
                      <option value="RN">Rio Grande do Norte</option>
                      <option value="RS">Rio Grande do Sul</option>
                      <option value="RO">Rond�nia</option>
                      <option value="RR">Roraima</option>
                      <option value="SC">Santa Catarina</option>
                      <option value="SP" selected="true">S�o Paulo</option>
                      <option value="SE">Sergipe</option>
                      <option value="TO">Tocantins</option>
                    </select>
		    <script language="JavaScript">
var aa=select_drop(document.alteracadastro.estado, '<?=$rowcadastro['estado']?>')
</script>
		    <br><Br>
Telefones
DDD <input type="text" class="form" name="ddd" size="2"  value="<?=$rowcadastro['ddd']?>">
Residencial: <input type="text" class="form" name="tel_residencial" size="8"  value="<?=$rowcadastro['tel_residencial']?>">&nbsp;&nbsp;&nbsp;&nbsp;
Comercial: <input type="text" class="form" name="tel_comercial" size="8" value="<?=$rowcadastro['tel_comercial']?>">&nbsp;&nbsp;&nbsp;&nbsp;
Celular: <input type="text" class="form" name="tel_celular" size="8"  value="<?=$rowcadastro['tel_celular']?>"><br><br>
Profiss�o: <input type="text" class="form" name="profissao" size="30" maxlength="100"  value="<?=$rowcadastro['profissao']?>"><br><br>
Sexo: 
<select name="sexo" class="form">
 <option> </option>
<option value="M" selected>Masculino</option>
<option value="F">Feminino</option>                    
</select>
<script language="JavaScript">
var aa=select_drop(document.alteracadastro.sexo, '<?=$rowcadastro['sexo']?>')
</script>
		      <br><Br>
Cor de Pele: 
<select name="cor" class="form">
 <option> </option>
<option value="B">Branca</option>
<option value="N">Negra</option>                
<option value="M">Morena</option>     
<option value="P">Parda</option>     
<option value="O">Oriental</option>     
</select>
<script language="JavaScript">
var aa=select_drop(document.alteracadastro.cor, '<?=$rowcadastro['cor']?>')
</script><br><br> 
Estado Civil: 
<select name="estado_civil" class="form">
<option value="S">Solteira(o)</option>
<option value="C">Casada(o)</option>
<option value="V">Vi�va(o)</option>
<option value="D">Divorciada(o)</option>
</select>
<script language="JavaScript">
var aa=select_drop(document.alteracadastro.estado_civil, '<?=$rowcadastro['estado_civil']?>')
</script>
&nbsp;&nbsp;&nbsp;&nbsp;
Filhos: <input type="text" class="form" name="filhos" size="3"  value="<?=$rowcadastro['filhos']?>"> <br><br>
Indica��o: 
<select name="indicacao" class="form">
<option value="L">Loja</option>
<option value="S">WebSite</option>
<option value="M">M�dica(o)</option>
<option value="A">Amiga(o)</option>
<option value="F">Folder / Cart�o</option>
</select>
 <script language="JavaScript">
var aa=select_drop(document.alteracadastro.indicacao, '<?=$rowcadastro['indicacao']?>')
</script>
<br><br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form>
