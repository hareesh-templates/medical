<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



?>


<p align="center"><a class="page_tit">Ficha Est�tica</a><br><br>
<form action="adicionarfichaesteticaexe.php" method="POST">
<table width="100%" cellpadding="10">
<tr>
<TD align="left">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Cor da Pele:
<select name="cor_pele" class="form">
<option selected="true"></option>
<option value="N">Normal</option>
<option value="A">Avermelhada</option>
<option value="P">P�lida</option>
</select>
</TD>
<TD align="left">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">T�nus
<select name="tonus_pele" class="form">
<option selected="true"></option>
<option value="N">Normal</option>
<option value="H">Hipot�nico</option>
</select>
</TD>
</tr>
</table>
<table  width="100%" cellpadding="10">
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">�stios</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Superf�cie</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Classifica��o</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Perdas Tecidnais</TD>
</tr>
<tr>
<TD align="center" valign="top">
 <select name="ostios_pele[]" size="3" multiple="multiple" class="form">
                <option value="X">Normais</option>
                <option value="NLDT">Normal Lateral e Dilatado T</option>
                <option value="Y">Dilatados</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="superficie[]" size="4" multiple="multiple" class="form">
                <option value="L">Lisa</option>
                <option value="G">Grossa</option>
                <option value="A">�spera</option>
                <option value="F">Fina</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="classificacao[]" size="6" multiple="multiple" class="form">
                <option value="N">Normal</option>
                <option value="AX">Al�ptica</option>
                <option value="M">Mista</option>
                <option value="AC">Acneica</option>
                <option value="L">Lip�dica</option>
                <option value="G">Gr�u</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="tecidnais[]" size="5" multiple="multiple" class="form">
                <option value="E">Escoria��es</option>
                <option value="D">Descama��o</option>
                <option value="U">Ulcera��o</option>
                <option value="R">Rachadura Perilabial</option>
                <option value="F">Fissuras</option>
                </select>
</TD>
</tr>
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Les�es S�lidas </TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Les�es L�quidas</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Estado da Pele</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Altera��es de Espessura</TD>
</tr>
<tr>
<TD align="center" valign="top">
 <select name="lesoes_solidas[]" size="5" multiple="multiple" class="form">
                <option value="CO">Comed�es</option>
                <option value="N">N�dulos</option>
                <option value="CH">Chantelasma</option>
                <option value="P">P�pulas</option>
                <option value="M">Millium</option>
		</select>
</TD>
<TD align="center" valign="top">
 <select name="lesoes_liquidas[]" size="4" multiple="multiple" class="form">
                <option value="P">P�stulas</option>
                <option value="B">Bolhas</option>
                <option value="A">Abcessos</option>
                <option value="C">Cistos</option>
                </select>
</TD>
<TD align="center" valign="top">
 <select name="estado_pele[]" size="6" multiple="multiple" class="form">
                <option value="S">Sens�vel</option>
                <option value="A">Al�rgica</option>
                <option value="DD">Desidratada</option>
                <option value="DV">Desvitalizada</option>
                <option value="L">Linhas</option>
                <option value="R">Rugas</option>
                </select>
</TD>
 <td align="center" valign="top">
 <select name="consistencia[]" size="6" multiple="multiple" class="form">
                <option value="V">Vibice (Estria)</option>
                <option value="CR">Crosta</option>
                <option value="A">Atrofia</option>
                <option value="Q">Queratose</option>
                <option value="X">Cicatriz</option>
                <option value="N">Nevus Verrucoso</option>
                </select>
</TD>
</tr>
<tr>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Manchas</TD>
<TD align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Corpo</TD>
</tr>
<tr>
 <td align="center" valign="top">
 <select name="manchas[]" size="14" multiple="multiple" class="form">
                <option value="A">Eritema</option>
                <option value="B">Ef�lides</option>
                <option value="C">Cloasma</option>
                <option value="D">Pet�quia</option>
                <option value="E">Nevus Rubi</option>
                <option value="F">Ros�cca</option>
                <option value="G">Hipercr�micas</option>
                <option value="H">Nevus Melanoc�tico</option>
                <option value="I">Telangicctasias</option>
                <option value="J">Nevus Sugestivo</option>
                <option value="K">Assimetria</option>
                <option value="L">Cor Uniforme</option>                
                <option value="M">Bordas Irregulares</option>                
                <option value="N">Di�metro Irregular</option>                
		</select>
</TD>
 <td align="center" valign="top">
 <select name="corpo[]" size="4" multiple="multiple" class="form">
                <option value="C">Celulite</option>
                <option value="F">Flacidez</option>
                <option value="G">Gordura Localizada</option>
                <option value="E">Estrias</option>
                </select>
</TD>
</tr>
</table>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Acr�mica:  <input type="text" class="form" name="acromica" size="54" maxlength="255"><br><br>
<br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Hipocr�mica:  <input type="text" class="form" name="hipocromica" size="50" maxlength="255">
<Br><Br>

<div align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es<br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"></textarea></div>
<br><Br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
</form></a>
