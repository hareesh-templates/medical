<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

# Execução: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
        exit("Falha ao conectar ao Banco de Dados");

# Baixa Razão social para título da página
$sqlpagina="select
                                nomefantasia,
                                endereco,
                                cidade,
                                estado,
                                ddd,
                                telefone
                        from
                                empresa
                        where
                                codigo='1'";
$querypagina=mysql_query($sqlpagina);
$rowpagina=mysql_fetch_array($querypagina);

if(!mysql_select_db($dbestetica, $dbconn))
        exit("Falha ao conectar ao Banco de Dados");

//if(!empty($_GET['pagina']))
//header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/".$_GET['pagina'].".php");
//echo "<script name=\"JavaScript\">window.open('".$_GET['pagina'].".php','_self');</script>";


?>
<html>
<TITLE>SGCE - Sistema de Gerenciamento de Clínica Estética</TITLE>
<LINK REL="StyleSheet" HREF="layout.css" TYPE="text/css">

</head>
<body bgcolor="#A5FF7F" marginwidth="0" leftmargin="0" topmargin="0" marginwidth="0">


<table width=100%>

<!-- TITULO -->
<TR bgcolor=white>
<td colspan=3 height=100>

<div align="center"><a class="logotipo" href="centro.php"  style="font-size:20px"><?=$rowpagina['nomefantasia'];?></a><br></div>
<?
if(!empty($_SESSION['cliente']))
        echo "<a class=\"pgtit_clib\">Cliente:<a class=\"pgtit_cli\" href=\"descarregarcliente.php\"> " . $_SESSION['nome']."(encerrar)";
?>




</td>
</tr>



<tr>

<!-- MENU ESQUERDA -->
<td width=16% rowspan=1000 valign=top>


<table rowspan=100>
<TR>
<td  align="center" > <a class="menu_tit">Gerenciamento<br><br><br></TD>
</TR>

<TR>
<td><a class="menu_mas">+ </a><a href="editarcadastro.php" class="menu_lnk" >Cadastro</a><br><br></TD>

</TR>

<TR>
<TD><a  class="menu_mas">+ </a><a href="editarhistorico.php" class="menu_lnk" >Historico Clinico</a><br><br></TD>
</TR>

<TR>
<TD><a  class="menu_mas">+ </a><a href="editarfichaestetica.php" class="menu_lnk" >Ficha Estetica</a><br><br></TD>
</TR>

<TR>
<td><a  class="menu_mas">+ </a><a href="visualizartratamentos.php" class="menu_lnk" >Tratamentos</a><br><br></TD>

</TR>

<TR>
<td><a  class="menu_mas">+ </a><a href="visualizarprodutosvendidos.php" class="menu_lnk" >Produtos Vendidos</a><br><br></TD>
</TR>

<!--
<TR>
<td><a class="menu_mas">+ <a href="gerarnota.php" class="menu_lnk" >Notas Fiscais</a><br><br><br></TD>
</TR>
-->

<TR>
<TD align="center"><a style="font-family: arial;font-size: 16px;font-weight: bold;color:white;">|| <a class="link">Encontrar Cliente </a><a style="font-family: arial;font-size: 16px;font-weight: bold;color:white;">||</TD>
</TR>

<TR>
<TD align="center">
<form action="pesquisarcliente.php" method="POST" >
<input class="form" type="text" name="nome">
</form>
</TD>
</TR>



</table>


</td>
<!-- CENTRO -->
<td width=70% rowspan=100 valign=top bgcolor=white>
