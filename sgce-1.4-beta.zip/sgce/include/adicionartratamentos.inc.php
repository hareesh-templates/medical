<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=adicionartratamentos','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=adicionartratamentos");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
	
$sqltratamento = "	select codigo
					from tratamentos";
$querytratamento=mysql_query($sqltratamento);
$querytratamento=mysql_fetch_array($querytratamento);
if(!$querytratamento)
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionartratamento.php','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionartratamento.php");

$sqlproduto = "	select codigo
					from produtos";
$queryproduto=mysql_query($sqlproduto);
$queryproduto=mysql_fetch_array($queryproduto);
if(!$queryproduto)
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarproduto.php','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarproduto.php");
	
$sqlhistorico = "	select cliente
					from historico_clinico where cliente=" . $_SESSION['cliente'];
$queryhistorico=mysql_query($sqlhistorico);
$queryhistorico=mysql_fetch_array($queryhistorico);
if(!$queryhistorico)
echo "<script name=\"JavaScript\">window.open('http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico.php','_self');</script>";
//	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/adicionarhistorico.php");

?>

<p align="center"><a class="page_tit">Adicionando Tratamento</a></p><br><br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Selecione o tratamento que ser� realizado: </a>
<form action="adicionartratamentosexe.php" method="POST">
<select name="tratamento" size="1" class="form" >
	<option selected="true"></option>
<?

$sqltratamento = "	select codigo,nome
					from tratamentos";
$querytratamento=mysql_query($sqltratamento);

while ($rowtratamento = mysql_fetch_assoc($querytratamento))
	echo "<option value=" . $rowtratamento['codigo'] . ">" . $rowtratamento['nome'] . "</option>";
mysql_free_result($querytratamento);

?>
</select><br><Br>
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Valor Total: R$ <input type="text" class="form" name="total" size="2" maxlength="10">
<br><br>
<table cellspacing="10">
<TR>
<TD><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Produto</TD>
<TD><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Quantidade</TD>
</TR>
<?

?>
<tr>
<TD>
<select name="produto[1]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[1]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[2]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[2]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[3]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[3]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[4]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[4]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[5]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[5]" class="form" maxlength="3" size="10"></TD>
</tr>
<tr>
<TD>
<select name="produto[6]" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidade[6]" class="form" maxlength="3" size="10"></TD>
</tr>
</table>
<br><br>
<div align="center"><a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">Observa��es</a><br><br>
<textarea class="form" name="observacoes" rows="15" cols="80"></textarea>
<br><br>
<div align="center"><input type="submit" class="form" value="Salvar"></div>
