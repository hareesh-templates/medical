<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/


if(!$_SESSION['cliente'])
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/pesquisarcliente.php?pagina=visualizarprodutosvendidos");
	

?>

<p align="center"><a class="page_tit">Visualiza��o de Produtos Vendidos</a></p>

<br>


<p align="justify"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:white;">// </a><a style="font-family: arial;font-size: 12px;font-weight: bold;color:#FF1ECB;text-decoration:none" href="realizarvenda.php" >Realizar Venda</a></p>

<br>

<table align="center" width="400" border="0" style="border-color:white;border-width:1">
<TR>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Data</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Produto</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Quantidade</TD>
<TD align="center"><a style="font-family: arial;font-size: 14px;font-weight: bold;color:#FF1ECB;">Valor</TD>
</TR>
<?

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
	
$sqlcliente = "	select data,produto,quantidade,valor
					from produtos_vendidos
					where cliente=" . $_SESSION['cliente'];
$querycliente=mysql_query($sqlcliente);

while ($rowcliente = mysql_fetch_assoc($querycliente))
{
$nasci = explode("-", $rowcliente['data']);
$d = $nasci[2];
$m = $nasci[1];
$a = $nasci[0];
$data = "$d/$m/$a";

$sqlproduto = "	select nome
					from produtos
					where codigo=" . $rowcliente['produto'];
$queryproduto=mysql_query($sqlproduto);
$rowproduto=mysql_fetch_array($queryproduto);
echo "
<tr>
<TD align=\"center\"><a class=\"page_rst\">".$data."</TD>
<TD align=\"center\"><a class=\"page_rst\">".$rowproduto['nome']."</TD>
<TD align=\"center\"><a class=\"page_rst\">".$rowcliente['quantidade']."</TD>
<TD align=\"center\"><a class=\"page_rst\"> R$".str_replace(".",",", $rowcliente['valor'])."</a></TD>
</tr>";
}
mysql_free_result($querycliente);

# Fecha Conex�o
?>
</table>
