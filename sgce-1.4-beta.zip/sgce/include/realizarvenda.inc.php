<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/



# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");
?>
<p align="center"><a class="page_tit">Realizando Venda</a><br><br>
<form action="realizarvendaexe.php" method="POST">
<a style="font-family:arial;font-size:14px;color:#FF1ECB;font-weight:bold">
Selecione os produtos e a quantidade a serem vendidos<br><br>
<table cellspacing="10">
<TR>
<TD align="center"><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Produto</TD>
<TD align="center"><a style="font-family:arial;font-size:12px;color:#FF1ECB;font-weight:bold">Quantidade</TD>
</TR>
<tr>
<TD>
<select name="produtoa" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidadea" class="form" maxlength="3" size="10">
</tr>
<tr>
<TD>
<select name="produtob" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidadeb" class="form" maxlength="3" size="10">
</tr>
<tr>
<TD>
<select name="produtoc" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidadec" class="form" maxlength="3" size="10">
</tr>
<tr>
<TD>
<select name="produtod" size="1" class="form" >
	<option selected="true"></option>
<?
$sqlproduto = "	select codigo,nome
					from produtos";
$queryproduto=mysql_query($sqlproduto);
while ($rowproduto = mysql_fetch_assoc($queryproduto))
	echo "<option value=" . $rowproduto['codigo'] . ">" . $rowproduto['nome'] . "</option>";
mysql_free_result($queryproduto);

?>
</select>
</TD>
<TD><input type="text" name="quantidaded" class="form" maxlength="3" size="10">
</tr>
</table>
<br><br>
<div align="center"><input type="submit" class="form" value="Vender"></div>
</form>
