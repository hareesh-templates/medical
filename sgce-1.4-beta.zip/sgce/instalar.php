<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/
?>

<html>
<head><TITLE>SGCE - Sistema de Gerenciamento de Cl�nica Est�tica</TITLE></head>
<body><br>
<h2>Sistema de Instala��o</h2>
<p align=justify>Este sistema tem como requisito:<br>
- Apache<br>
- PHP<br>
- MySQL<br><br>
Obs.: Antes de clicar em Instalar, certifique-se que este diret�rio tem permiss�o de escrita pelo usu�rio/grupo que o Apache est� rodando. Resumindo, dever� ter 755 ou 775 dependendo da instala��o do servidor WEB.</p>
<form action="instalarexe.php" method="POST">
Digite as informa��es referente ao banco de dados MySQL:<br><br>
Nome do servidor:
<input type="text" name="name"><br>
Nome do banco de dados:
<input type="text" name="database"><br>
Nome do usu�rio:
<input type="text" name="user"><br>
Senha:
<input type="password" name="password"><br><br>
Agora digite um c�digo que servir� para validar a Sess�o do PHP:<br>
C�digo:
<input type="text" name="keysession"><br><br>
<center><input  type="submit" name="Instalar" value="Instalar"></center>
</form>
</body>
</html>
