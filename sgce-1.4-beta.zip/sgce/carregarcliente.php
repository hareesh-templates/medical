<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

if(	!$_GET['cliente']	)
	exit("N�o foi poss�vel carregar cliente");

include("sessao.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqlcliente = "	select nome
					from cadastro
					where codigo='".$_GET['cliente']."'";
$querycliente=mysql_query($sqlcliente);
$rowcliente=mysql_fetch_array($querycliente);

if(!$rowcliente)
	exit("Cliente inexistente");

$_SESSION['cliente']=$_GET['cliente'];
$_SESSION['nome']=$rowcliente['nome'];

# Fecha Conex�o
mysql_close($dbconn);

if($pagina)
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/".$pagina.".php");
else
	header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/editarcadastro.php");

?>
