<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

require("security/clean.inc.php");
require("conf.inc.php");

# Come�a Sess�o
session_start();

# Execu��o: Seleciona DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

# Consulta SQL
$sqlautenticacao="select codigo,senha,estetica,tipo_usuario from autenticacao where usuario='".$_POST['usuario']."'";
$queryautenticacao=mysql_query($sqlautenticacao);

if(!$queryautenticacao)
exit("N�o foi possivel atualizar o banco de dados");

$rowautenticacao=mysql_fetch_array($queryautenticacao);

# Verifica��o: Senha correta
if(sha1($_POST['senha']) == $rowautenticacao['senha']){

# RegistraVari�veis na sess�o
session_register('usercode');
session_register('letsafecli');
session_register('estetica');
$_SESSION['letsafecli']=$idpassportcli;
$_SESSION['usercode']=$rowautenticacao['codigo'];
$_SESSION['estetica']="1";

# Fecha conex�o MySQL
mysql_close($dbconn);

if($rowautenticacao['tipo_usuario'] == "S")
	header("Location: http://".$_SERVER['HTTP_HOST'] . $wpath . "/administracao.php");
elseif($rowautenticacao['tipo_usuario'] == "E")
	header("Location: http://".$_SERVER['HTTP_HOST'] . $wpath . "/esteticista.php");
elseif($rowautenticacao['tipo_usuario'] == "A")
	header("Location: http://".$_SERVER['HTTP_HOST'] . $wpath . "/administracao.php");
elseif($rowautenticacao['tipo_usuario'] == "E,S,A")
	header("Location: http://".$_SERVER['HTTP_HOST'] . $wpath . "/index.php");
}

else
	exit("Senha Incorreta");
?>
