<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");
	
if($_POST['tratamento_medico'] && $_POST['tratamento_dentario'])
	$tratamento="M,D";
elseif($_POST['tratamento_dentario'] == "D")
	$tratamento="D";
elseif($_POST['tratamento_medico'] == "M")
	$tratamento="M";	

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$sqledita="update historico_clinico set
									lentes_contato='".$_POST['lentes_contato']."',
									hipertensao='".$_POST['hipertensao']."',
									cardiaco='".$_POST['cardiaco']."',
									marca_passo='".$_POST['marca_passo']."',
									pino_placa='".$_POST['pino_placa']."',
									gravidez='".$_POST['gravidez']."',
									epileptico='".$_POST['epileptico']."',
									diabetico='".$_POST['diabetico']."',
									displasia='".$_POST['displasia']."',
									hormonais='".$_POST['hormonais']."',
									tireoide='".$_POST['tireoide']."',
									ovarios='".$_POST['ovarios']."',
									labirintite='".$_POST['labirintite']."',
									corticoterapia='".$_POST['corticoterapia']."',
									tpm='".$_POST['tpm']."',
									aids='".$_POST['aids']."',
									ca='".$_POST['ca']."',
									osseas='".$_POST['osseas']."',
									articulares='".$_POST['articulares']."',
									musculares='".$_POST['musculares']."',
									medicamentos='".$_POST['medicamentos']."',
									anticoncepcional='".$_POST['anticoncepcional']."',
									tratamentos='".$tratamento."',
									dermatoses='".$_POST['dermatoses']."',
									infeccoes='".$_POST['infeccoes']."',
									vasculopatias='".$_POST['vasculopatias']."',
									emocional='".$_POST['emocional']."',
									fumante='".$_POST['fumante']."',
									macos='".$_POST['macos']."',
									agua='".$_POST['agua']."',
									glicolico='".$_POST['glicolico']."',
									exposicao_sol='".$_POST['exposicao_sol']."'
					 where cliente='$_SESSION[cliente]' limit 1";

# Execu��o: Inser��o - Produto									
$queryedita=mysql_query($sqledita,$dbconn);		

if(!$queryedita)
	exit("N�o foi possivel editar este cadastro");

# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/editarhistorico2.php");

?>
