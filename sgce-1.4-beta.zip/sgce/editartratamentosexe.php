<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

# Execu��o: Executa DB
if(!mysql_select_db($dbestetica, $dbconn))
	exit("Falha ao conectar ao Banco de Dados");

$_POST['total'] = str_replace(",",".", $_POST['total']);

# SQL: Inser��o - Tratamentos
$sqlupdate= "update tratamentos_realizados set 
											status='".$_POST['status']."',
											total='".$_POST['total']."',
											observacoes='".$_POST['observacoes']."'
										where codigo='$_POST[codigo]'";
				
$queryupdate=mysql_query($sqlupdate);

if(!$queryupdate)
exit("N�o foi possivel atualizar o banco de dados1");

# Salvando data do primeiro atendimento
$sqlinsere = "insert into data_tratamento	(
											tratamento,
											data
									)
								values (		'".$_POST['codigo']."',
											'".date("Y-m-d")."'
									)";

# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);										
			
# SQL: Inser��o - Tratamentos
for($i=0;$i<count($produto);$i++)
{
if(!empty($codprod[$i]))
{
if(!empty($quantidade[$i]) && !empty($produto[$i]) )
{
$sqlupdate= "update produtos_utilizados set 
											quantidade='".$quantidade[$i]."'
										where codigo=" . $codprod[$i];
$queryupdate=mysql_query($sqlupdate);
if(!$queryupdate)
exit("N�o foi possivel atualizar o banco de dados2");
}
else
{
$sqldeletar="delete from produtos_utilizados where codigo='".$codigo[$i]."'";
$querydeletar=mysql_query($sqldeletar);
}
}
}
$a = count($produto) - 1;
if(!empty($quantidade[$a]) && !empty($produto[$a]))
{
# SQL: Inser��o - Produtos
$sqlinsere="insert into produtos_utilizados (	
											now(),	
											tratamento,
											estetica,
											produto,
											quantidade	 )
					values(					'".$codigo."',
											'1',
											'".$produto[$a]."',
											'".$quantidade[$a]."'
										)";

# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);		
}
$a += 1;
if(!empty($quantidade[$a]) && !empty($produto[$a]))
{
# SQL: Inser��o - Produtos
$sqlinsere="insert into produtos_utilizados (	
											tratamento,
											estetica,
											produto,
											quantidade	 )
					values(					'".$codigo."',
											'1',
											'".$produto[$a]."',
											'".$quantidade[$a]."'
										)";

# Execu��o: Inser��o - Produto									
$queryinsere=mysql_query($sqlinsere);	
}

# Fecha Conex�o
mysql_close($dbconn);
header("Location:http://".$_SERVER['HTTP_HOST'].$wpath."/visualizartratamentos.php");


?>
