<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

if(!empty($_POST['cores_preferenciais']))
$cores_preferenciais = implode(",", $_POST['cores_preferenciais']);
if(!empty($_POST['cores_irritantes']))
$cores_irritantes = implode(",", $_POST['cores_irritantes']);

$sqledita="update ".$dbestetica.".historico_clinico set
				alergias='".$_POST['alergias']."',
				esportes='".$_POST['esportes']."',
				dieta='".$_POST['dieta']."',
				tratamentos_esteticos='".$_POST['tratamentos_esteticos']."',
				cosmeticos='".$_POST['cosmeticos']."',
				cirurgias_esteticas='".$_POST['cirurgias_esteticas']."',
				cores_preferenciais='".$cores_preferenciais."',
				cores_irritantes='".$cores_irritantes."',
				observacoes='".$_POST['observacoes']."'
				where cliente='$_SESSION[cliente]' limit 1";
	
# Execu��o: Inser��o - Produto									
$queryedita=mysql_query($sqledita,$dbconn);		

if(!$queryedita)
	exit("N�o foi possivel adicionar hist�rico cl�nico");

# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/editarhistorico.php");



?>

