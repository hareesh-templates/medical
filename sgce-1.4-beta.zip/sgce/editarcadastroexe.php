<?
/*

SGCE - Skincare Management System
Copyright (C) 2007 Adolfo Bravo Ferreira <adolfo.ferreira at hotmail.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

*/

include("sessao.inc.php");

$nasci = explode("/", $_POST["nascimento"]);
$dnasci = $nasci[0];
$mnasci = $nasci[1];
$anasci = $nasci[2];
$nascimto = "$anasci-$mnasci-$dnasci";


# SQL: Inser��o - Produto
$sqledita="update ".$dbestetica.".cadastro set
											estetica='1',
											nascimento='$nascimto',
											email='".$_POST['email']."',
											nome='".$_POST['nome']."',
											endereco='".$_POST['endereco']."',
											bairro='".$_POST['bairro']."',
											cep='".$_POST['cep']."',
											cidade='".$_POST['cidade']."',
											estado='".$_POST['estado']."',
											ddd='".$_POST['ddd']."',
											tel_residencial='".$_POST['tel_residencial']."',
											tel_comercial='".$_POST['tel_comercial']."',
											tel_celular='".$_POST['tel_celular']."',
											profissao='".$_POST['profissao']."',
											sexo='".$_POST['sexo']."',
											cor='".$_POST['cor']."',
											estado_civil='".$_POST['estado_civil']."',
											filhos='".$_POST['filhos']."',
											indicacao='".$_POST['indicacao']."'
						where codigo='$_SESSION[cliente]' limit 1";

						
# Execu��o: Inser��o - Produto									
$queryedita=mysql_query($sqledita,$dbconn);		

if(!$queryedita)
	exit("N�o foi possivel editar este cadastro");

# Fecha Conex�o
mysql_close($dbconn);

header("Location: http://".$_SERVER['HTTP_HOST'].$wpath."/editarcadastro.php");



?>
