-- phpMyAdmin SQL Dump
-- version 2.9.2-rc1
-- http://www.phpmyadmin.net
-- 
-- Host: pr-db2
-- Generation Time: Jun 07, 2007 at 12:13 PM
-- Server version: 4.1.21
-- PHP Version: 4.3.9
-- 
-- Database: `s198010_sgce`
-- 
CREATE DATABASE `sgce` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sgce`;

-- --------------------------------------------------------

-- 
-- Table structure for table `autenticacao`
-- 

CREATE TABLE `autenticacao` (
  `codigo` varchar(10) NOT NULL default '',
  `tipo_usuario` set('E','S','A') NOT NULL default 'E',
  `estetica` char(1) NOT NULL default '',
  `usuario` varchar(10) NOT NULL default '',
  `senha` varchar(40) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Informações de Acesso';

-- 
-- Dumping data for table `autenticacao`
-- 

INSERT INTO `autenticacao` (`codigo`, `tipo_usuario`, `estetica`, `usuario`, `senha`) VALUES ('1', 'E,S,A', '1', 'demo', '89e495e7941cf9e40e6980d14a16bf023ccd4c91');

-- --------------------------------------------------------

-- 
-- Table structure for table `cadastro`
-- 

CREATE TABLE `cadastro` (
  `codigo` smallint(10) NOT NULL auto_increment,
  `estetica` smallint(1) NOT NULL default '0',
  `data` date NOT NULL default '0000-00-00',
  `nascimento` date NOT NULL default '0000-00-00',
  `email` varchar(255) NOT NULL default '',
  `nome` varchar(100) NOT NULL default '',
  `endereco` varchar(150) NOT NULL default '',
  `bairro` varchar(30) NOT NULL default '',
  `cep` varchar(8) NOT NULL default '',
  `cidade` varchar(50) NOT NULL default '',
  `estado` char(2) NOT NULL default '',
  `ddd` char(2) NOT NULL default '',
  `tel_residencial` varchar(8) NOT NULL default '',
  `tel_comercial` varchar(8) NOT NULL default '',
  `tel_celular` varchar(8) NOT NULL default '',
  `profissao` varchar(100) NOT NULL default '',
  `sexo` enum('M','F') NOT NULL default 'M',
  `cor` enum('B','N','M','P','O') NOT NULL default 'B',
  `estado_civil` enum('S','C','V','D') NOT NULL default 'S',
  `filhos` smallint(1) NOT NULL default '0',
  `indicacao` enum('L','S','M','A','F') NOT NULL default 'L',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0 COMMENT='Tabela de Cadastro' AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `cadastro`
-- 

INSERT INTO `cadastro` (`codigo`, `estetica`, `data`, `nascimento`, `email`, `nome`, `endereco`, `bairro`, `cep`, `cidade`, `estado`, `ddd`, `tel_residencial`, `tel_comercial`, `tel_celular`, `profissao`, `sexo`, `cor`, `estado_civil`, `filhos`, `indicacao`) VALUES (4, 1, '2007-06-07', '1987-06-01', 'email@provider.com', 'First Name', 'Street Address', 'Neighboor', '00000000', 'City', 'SP', '00', '12343211', '', '', 'Function', 'M', 'B', 'S', 1, 'L');

-- --------------------------------------------------------

-- 
-- Table structure for table `data_tratamento`
-- 

CREATE TABLE `data_tratamento` (
  `tratamento` smallint(10) NOT NULL default '0',
  `data` date NOT NULL default '0000-00-00',
  KEY `tratamento` (`tratamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `data_tratamento`
-- 

INSERT INTO `data_tratamento` (`tratamento`, `data`) VALUES (6, '2007-06-07');
INSERT INTO `data_tratamento` (`tratamento`, `data`) VALUES (6, '2007-06-07');
INSERT INTO `data_tratamento` (`tratamento`, `data`) VALUES (6, '2007-06-07');

-- --------------------------------------------------------

-- 
-- Table structure for table `empresa`
-- 

CREATE TABLE `empresa` (
  `codigo` smallint(1) NOT NULL auto_increment,
  `responsavel` varchar(100) NOT NULL default '',
  `nomefantasia` varchar(100) NOT NULL default '',
  `razaosocial` varchar(100) NOT NULL default '',
  `cnpj_cpf` varchar(14) NOT NULL default '',
  `endereco` varchar(150) NOT NULL default '',
  `cep` varchar(8) NOT NULL default '',
  `cidade` varchar(50) NOT NULL default '',
  `estado` char(2) NOT NULL default '',
  `ddd` char(2) NOT NULL default '',
  `telefone` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Informações sobre a Clínica' AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `empresa`
-- 

INSERT INTO `empresa` (`codigo`, `responsavel`, `nomefantasia`, `razaosocial`, `cnpj_cpf`, `endereco`, `cep`, `cidade`, `estado`, `ddd`, `telefone`) VALUES (1, 'Skincare Center', 'Skincare Center', 'Skincare Center', 'CNPJ', 'Address', '', 'City', 'St', 'Co', 'Telnumbe');

-- --------------------------------------------------------

-- 
-- Table structure for table `ficha_estetica`
-- 

CREATE TABLE `ficha_estetica` (
  `cliente` smallint(10) NOT NULL default '0',
  `cor_pele` enum('N','A','P') NOT NULL default 'N',
  `ostios_pele` set('X','NLDT','Y') NOT NULL default '',
  `tonus_pele` enum('N','H') NOT NULL default 'N',
  `estado_pele` set('S','A','DD','DV','L','R') NOT NULL default '',
  `superficie` set('L','G','A','F') NOT NULL default '',
  `classificacao` set('N','AX','M','AC','L','G') NOT NULL default '',
  `tecidnais` set('E','D','U','R','F') NOT NULL default '',
  `lesoes_solidas` set('CO','N','CH','P','M') NOT NULL default '',
  `lesoes_liquidas` set('P','B','A','C') NOT NULL default '',
  `consistencia` set('V','CR','A','Q','X','N') NOT NULL default '',
  `manchas` set('A','B','C','D','E','F','G','H','I','J','K','L','M','N') NOT NULL default '',
  `acromica` varchar(100) NOT NULL default '',
  `hipocromica` varchar(100) NOT NULL default '',
  `corpo` set('C','F','G','E') NOT NULL default '',
  `observacoes` text NOT NULL,
  PRIMARY KEY  (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Tabela da Ficha Estética';

-- 
-- Dumping data for table `ficha_estetica`
-- 

INSERT INTO `ficha_estetica` (`cliente`, `cor_pele`, `ostios_pele`, `tonus_pele`, `estado_pele`, `superficie`, `classificacao`, `tecidnais`, `lesoes_solidas`, `lesoes_liquidas`, `consistencia`, `manchas`, `acromica`, `hipocromica`, `corpo`, `observacoes`) VALUES (4, 'P', 'X,Y', 'H', 'S,DD,L', 'G,F', 'N,M,L', 'D,R', 'CO,CH,M', 'B,C', 'CR,Q,N', 'A,C,E,G,I,K,M', '', '', 'F,E', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `historico_clinico`
-- 

CREATE TABLE `historico_clinico` (
  `cliente` smallint(10) NOT NULL default '0',
  `lentes_contato` enum('S','N') NOT NULL default 'N',
  `alergias` text NOT NULL,
  `hipertensao` enum('S','N') NOT NULL default 'N',
  `cardiaco` enum('S','N') NOT NULL default 'N',
  `marca_passo` enum('S','N') NOT NULL default 'N',
  `pino_placa` enum('S','N') NOT NULL default 'N',
  `gravidez` enum('S','N') NOT NULL default 'N',
  `epileptico` enum('S','N') NOT NULL default 'N',
  `diabetico` enum('S','N') NOT NULL default 'N',
  `displasia` enum('S','N') NOT NULL default 'N',
  `hormonais` enum('S','N') NOT NULL default 'N',
  `tireoide` enum('S','N') NOT NULL default 'N',
  `ovarios` enum('S','N') NOT NULL default 'N',
  `labirintite` enum('S','N') NOT NULL default 'N',
  `corticoterapia` enum('S','N') NOT NULL default 'N',
  `tpm` enum('S','N') NOT NULL default 'N',
  `aids` enum('S','N') NOT NULL default 'N',
  `ca` enum('S','N') NOT NULL default 'N',
  `osseas` enum('S','N') NOT NULL default 'N',
  `articulares` enum('S','N') NOT NULL default 'N',
  `musculares` enum('S','N') NOT NULL default 'N',
  `medicamentos` enum('S','N') NOT NULL default 'N',
  `anticoncepcional` enum('S','N') NOT NULL default 'N',
  `tratamentos` set('M','D') NOT NULL default '',
  `dermatoses` enum('S','N') NOT NULL default 'N',
  `infeccoes` enum('S','N') NOT NULL default 'N',
  `vasculopatias` enum('S','N') NOT NULL default 'N',
  `emocional` set('E','D','A','S') NOT NULL default '',
  `aromas_preferenciais` varchar(100) NOT NULL default '',
  `aromas_irritantes` varchar(100) NOT NULL default '',
  `cores_preferenciais` set('G','B','Y','R','V','O','P') NOT NULL default '',
  `cores_irritantes` set('G','B','Y','R','V','O','P') NOT NULL default '',
  `esportes` text NOT NULL,
  `fumante` enum('S','N') NOT NULL default 'N',
  `macos` smallint(1) NOT NULL default '0',
  `dieta` text NOT NULL,
  `agua` varchar(4) NOT NULL default '',
  `tratamentos_esteticos` text NOT NULL,
  `cosmeticos` text NOT NULL,
  `glicolico` enum('S','N') NOT NULL default 'N',
  `exposicao_sol` enum('S','N') NOT NULL default 'N',
  `cirurgias_esteticas` text NOT NULL,
  `observacoes` text NOT NULL,
  PRIMARY KEY  (`cliente`),
  KEY `cliente` (`cliente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Histórico Médico';

-- 
-- Dumping data for table `historico_clinico`
-- 

INSERT INTO `historico_clinico` (`cliente`, `lentes_contato`, `alergias`, `hipertensao`, `cardiaco`, `marca_passo`, `pino_placa`, `gravidez`, `epileptico`, `diabetico`, `displasia`, `hormonais`, `tireoide`, `ovarios`, `labirintite`, `corticoterapia`, `tpm`, `aids`, `ca`, `osseas`, `articulares`, `musculares`, `medicamentos`, `anticoncepcional`, `tratamentos`, `dermatoses`, `infeccoes`, `vasculopatias`, `emocional`, `aromas_preferenciais`, `aromas_irritantes`, `cores_preferenciais`, `cores_irritantes`, `esportes`, `fumante`, `macos`, `dieta`, `agua`, `tratamentos_esteticos`, `cosmeticos`, `glicolico`, `exposicao_sol`, `cirurgias_esteticas`, `observacoes`) VALUES (0, 'S', '', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '');
INSERT INTO `historico_clinico` (`cliente`, `lentes_contato`, `alergias`, `hipertensao`, `cardiaco`, `marca_passo`, `pino_placa`, `gravidez`, `epileptico`, `diabetico`, `displasia`, `hormonais`, `tireoide`, `ovarios`, `labirintite`, `corticoterapia`, `tpm`, `aids`, `ca`, `osseas`, `articulares`, `musculares`, `medicamentos`, `anticoncepcional`, `tratamentos`, `dermatoses`, `infeccoes`, `vasculopatias`, `emocional`, `aromas_preferenciais`, `aromas_irritantes`, `cores_preferenciais`, `cores_irritantes`, `esportes`, `fumante`, `macos`, `dieta`, `agua`, `tratamentos_esteticos`, `cosmeticos`, `glicolico`, `exposicao_sol`, `cirurgias_esteticas`, `observacoes`) VALUES (3, '', 'teste alergia', 'S', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', '', 'B,R', 'B,O', 'teste es', '', 0, 'teste di', '', 'teste es', 'teste co', '', '', 'teste es', 'sss');
INSERT INTO `historico_clinico` (`cliente`, `lentes_contato`, `alergias`, `hipertensao`, `cardiaco`, `marca_passo`, `pino_placa`, `gravidez`, `epileptico`, `diabetico`, `displasia`, `hormonais`, `tireoide`, `ovarios`, `labirintite`, `corticoterapia`, `tpm`, `aids`, `ca`, `osseas`, `articulares`, `musculares`, `medicamentos`, `anticoncepcional`, `tratamentos`, `dermatoses`, `infeccoes`, `vasculopatias`, `emocional`, `aromas_preferenciais`, `aromas_irritantes`, `cores_preferenciais`, `cores_irritantes`, `esportes`, `fumante`, `macos`, `dieta`, `agua`, `tratamentos_esteticos`, `cosmeticos`, `glicolico`, `exposicao_sol`, `cirurgias_esteticas`, `observacoes`) VALUES (4, '', '', '', '', 'S', '', '', 'S', '', '', 'S', 'S', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', 'B,R', 'G,B,V,P', '', '', 0, '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `produtos`
-- 

CREATE TABLE `produtos` (
  `codigo` smallint(10) NOT NULL auto_increment,
  `estetica` smallint(1) NOT NULL default '0',
  `nome` varchar(100) NOT NULL default '',
  `quantidade` varchar(20) NOT NULL default '',
  `estoque` char(3) NOT NULL default '',
  `fabricante` varchar(50) NOT NULL default '',
  `ddd` char(2) NOT NULL default '',
  `telefone` varchar(8) NOT NULL default '',
  `preco` float(10,2) NOT NULL default '0.00',
  `validade` char(2) NOT NULL default '00',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0 COMMENT='Tabela de Produtos' AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `produtos`
-- 

INSERT INTO `produtos` (`codigo`, `estetica`, `nome`, `quantidade`, `estoque`, `fabricante`, `ddd`, `telefone`, `preco`, `validade`) VALUES (5, 1, 'Natura', '1', '1', 'Natura', '11', '0800', 111.00, '24');

-- --------------------------------------------------------

-- 
-- Table structure for table `produtos_utilizados`
-- 

CREATE TABLE `produtos_utilizados` (
  `codigo` smallint(10) NOT NULL auto_increment,
  `data` date NOT NULL default '0000-00-00',
  `tratamento` smallint(10) NOT NULL default '0',
  `estetica` smallint(1) NOT NULL default '0',
  `produto` smallint(10) NOT NULL default '0',
  `quantidade` smallint(5) NOT NULL default '0',
  PRIMARY KEY  (`codigo`),
  KEY `tratamento` (`tratamento`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Tabela de Produtos Utilizados' AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `produtos_utilizados`
-- 

INSERT INTO `produtos_utilizados` (`codigo`, `data`, `tratamento`, `estetica`, `produto`, `quantidade`) VALUES (12, '2007-06-07', 6, 1, 5, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `produtos_vendidos`
-- 

CREATE TABLE `produtos_vendidos` (
  `codigo` smallint(10) NOT NULL auto_increment,
  `cliente` smallint(10) NOT NULL default '0',
  `data` date NOT NULL default '0000-00-00',
  `produto` smallint(10) NOT NULL default '0',
  `quantidade` smallint(3) NOT NULL default '0',
  `valor` float(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Tabela de Venda de Produtos' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `produtos_vendidos`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tratamentos`
-- 

CREATE TABLE `tratamentos` (
  `codigo` smallint(10) NOT NULL auto_increment,
  `estetica` smallint(1) NOT NULL default '0',
  `nome` varchar(100) NOT NULL default '',
  `descricao` text NOT NULL,
  `secoes` smallint(2) NOT NULL default '0',
  `preco` float(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Tabela de Tratamentos' AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `tratamentos`
-- 

INSERT INTO `tratamentos` (`codigo`, `estetica`, `nome`, `descricao`, `secoes`, `preco`) VALUES (5, 1, 'Cleaning Face', '', 1, 100.00);

-- --------------------------------------------------------

-- 
-- Table structure for table `tratamentos_realizados`
-- 

CREATE TABLE `tratamentos_realizados` (
  `tratamento` smallint(10) NOT NULL default '0',
  `codigo` smallint(10) NOT NULL auto_increment,
  `cliente` smallint(10) NOT NULL default '0',
  `status` enum('I','C','F') NOT NULL default 'I',
  `observacoes` text NOT NULL,
  `total` float(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Tabela de tratamentos realizados' AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `tratamentos_realizados`
-- 

INSERT INTO `tratamentos_realizados` (`tratamento`, `codigo`, `cliente`, `status`, `observacoes`, `total`) VALUES (5, 6, 4, 'F', '', 100.00);
