<?php include("validation/header.php"); ?>

	<form id="formID" class="formular" method="post">

			<label>
				<input value="" class="validate[required] text-input" type="text" name="req" id="req" />
			</label>

		
		<input class="submit" type="submit" value="Validate &amp; Send the form!"/><hr/>
	</form>
</body>
</html>
