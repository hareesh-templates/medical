
# code compiled with jdk 6
java -cp ./test AjaxTestServer
