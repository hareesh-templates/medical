<form action="" method="get">
<table width="1000" border="1">
  <tr>
    <td colspan="2"><div align="center"><strong>Login Page</strong></div></td>
    </tr>
  <tr>
    <td width="484">User ID</td>
    <td width="500"><label for="userid"></label>
      <input type="text" name="userid"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><label for="password"></label>
      <input type="password" name="password"></td>
  </tr>
  <tr>
    <td colspan="2"><div align="center">
      <p>
        <input type="submit" name="login" id="login" value="Login"> 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <input type="submit" name="forgotpassword" value="Forgot Password">
     <hr>
     New User, <a href="register.php" >Click here.</a>
      </p>
     
    </div></td>
    </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>