<div id="copyright">
  <div class="wrapper">
    <p class="fl_left">Copyright &copy; 2011 - All Rights Reserved - <a href="#">ClinicoSight</a></p>
    <p class="fl_right">Powered By ClinicoSight</p>
    <br class="clear" />
  </div>
</div>
</body>
</html>