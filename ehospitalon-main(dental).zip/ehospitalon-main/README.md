#About for eHospitalon
eHOSPITALON a product of [WorldSoftZone.](https://worldsoftzone.com)

The best Hospital
Management
Software including Clinic, Diagnostic &amp; Imaging.
<br>
<br>
Before start using eHOSPITALON consider a general scenario of typical hospital have
different departments like Billing, Appointment, OPD, IPD, Pharmacy, Pathology,
Radiology, Blood Bank, Ambulance, Operation Theatre, Blood Bank, Accounts, Admin etc.
where we perform different patient and hospital related activities.
<br>
<br>
To one side from above we also like to provide access to our eHOSPITALON to different
users like Doctors, Accountants, Pharmacist, Radiologist, Pathologist, and Patient. For
these eHOSPITALON have 9 inherent user's roles - Super Admin, Admin, Doctor, Accountant,
Pathologist, Radiologist, Nurse, Receptionist and Patient. Effectively you can create
unlimited number of user roles for staff members.

[Request for Demo.](https://ehospitalon.com/request-for-demo.html)