<!DOCTYPE html>
<html lang="en">
<head>
<title>Search results</title>
<meta charset="utf-8">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="search/search.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body>
<div class="global">
    <div>
    <!--content-->
    <div class="container">
        <header class="margBot2">
            <div class="row">
                <article class="span10 offset1">
                    <h1><a href="index.html"><img src="img/logo.png" alt=""></a></h1>
                    <div id="menu">
                        <div class="navbar_">
                            <div class="navbar-inner">      
                                <div class="clearfix">
                                    <div class="nav-collapse nav-collapse_ collapse">
                                        <ul class="nav sf-menu clearfix">
                                	       <li><a href="index.html">About us<span></span></a>
                                                <ul>
                                                    <li><a href="#">history</a></li>
                                                    <li><a href="#">news<span></span></a>
                                                        <ul>
                                                            <li><a href="#">fresh</a></li>
                                                            <li><a href="#">archive</a></li>
                                                            <li class="triangle"></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="#">offers</a></li>
                                                    <li class="triangle"></li>
                                                </ul>
                                           </li>
                                           <li><a href="index-1.html">Services</a></li>
                                           <li><a href="index-2.html">Our dentists</a></li>
                                           <li><a href="index-3.html">Blog</a></li>
                                           <li><a href="index-4.html">Contacts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ul class="follow_icon">
                            <li><a href="#"><img src="img/follow_icon1.png" alt=""></a></li>
                            <li><a href="#"><img src="img/follow_icon2.png" alt=""></a></li>
                            <li><a href="#"><img src="img/follow_icon3.png" alt=""></a></li>
                            <li><a href="#"><img src="img/follow_icon4.png" alt=""></a></li>
                        </ul>
                    </div>
                </article>
            </div>
        </header>
    <!--content-->
    <div class="row">
       <article class="span10 offset1">
        <h4>Search result:</h4>
        <div id="search-results"></div>
      </article>                                                   
    </div>
</div>
</div>  
</div>       
<!--footer-->
<footer>
  <div class="container">
	     <div class="row">
            <section class="span12 border1">
                <div class="row">
                    <article class="span3 offset1 infobox1">
                        <h3>Your First Visit</h3>
                        <p class="description2">Consectetur adipis euiaos</p>
                        <p>Vumquam eius modi tempora incidunt, ut laboret dolore agnam aliquam quaerat voluptatemut enim ad ma veniam, suscipit labruaysa.</p>
                    </article>
                    <article class="span3 offset1 infobox2">
                        <h3>locations</h3>
                        <p class="description3">28 Jackson Blvd Ste 1020<br>Chicago<br>IL 60604-2340</p>
                        <p class="description4"><img src="img/envelope.png" alt=""><a href="#">info@demolink.org</a></p>
                    </article>
                    <article class="span4 infobox2">
                        <h3>appointment Request</h3>
                        <ul class="list2">
                            <li>
                                <img src="img/page1_icon4.png" alt="">
                                <div class="extra-wrap">
                                    <p>call toll-free</p>
                                    <p class="tel">+1<span>&bull;</span>234<span>&bull;</span>567<span>&bull;</span>8900</p>
                                </div>
                            </li>
                            <li>
                                <img src="img/page1_icon5.png" alt="">
                                <div class="extra-wrap">
                                    <a href="#">on-line form</a>
                                </div>
                            </li>
                        </ul>
                    </article>
                </div>
            </section>
            <section class="span12 border2">
                <div class="row">
                    <ul class="footerMenu">
                        <li><a href="index.html">About us</a></li>
                        <li><a href="index-1.html">services</a></li>
                        <li><a href="index-2.html">Our dentists</a></li>
                        <li><a href="index-3.html">blog</a></li>
                        <li class="point"><a href="index-4.html">contacts</a></li>
                    </ul>
                    <div class="span3 offset2 privacy"><p><span>Happy Smile</span> &copy; 2013 &bull; <a href="index-5.html">Privacy Policy</a></p></div>
                </div>
            </section>
       </div>
  </div>     
</footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script>
        if($.browser.msie && $.browser.version == 8){ 
            $('.privacy').css({'width':'100%', 'margin':'0', 'padding-top':'20px'});
            $('.slider figure').css({'margin-top':'-16px', 'width':'780px'});
            $('.slider figure img').css({'width':'780px'});
        }
        if($.browser.opera){ 
            $('#menu .navbar-inner').css({'min-height':'38px'});  
        }
</script>
</body>
</html>