/**
 * Theme Customizer enhancements for a better user experience.
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {
    $('#mastmenu .menu-item > a').click(function() {
      $('body').removeClass('site-navigation-active');
      $('.main-navigation.active').removeClass('active');
      $('.menu-toggle.active').removeClass('active');
    })

    $('a[href="#contact"]').click(function() {
        console.log('dsnjfd');
        $('html, body').animate({
            scrollTop: $("#contact").offset().top
        }, 1000);
        return false;
    })
    $('.testimonial-slider').slick({
        infinite: true,
        dots: true,
        slidesToShow: 3,
        responsive: [
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 2
              }
            },
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1
              }
            }
        ],
        slidesToScroll: 1
    }); 
} )( jQuery );
